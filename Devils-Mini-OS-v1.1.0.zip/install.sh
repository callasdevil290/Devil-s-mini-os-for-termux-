#!/usr/bin/env bash
# =============================================================================
# Devil's Mini OS Launcher - install.sh
# Version: v1.1.0 (v2026.07.01)
# License: MIT
# =============================================================================
set -e

# Colors
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
CYAN='\033[0;36m'
NC='\033[0m'

REPO_URL="https://github.com/callasdevil290/Devils-Mini-OS.git"
INSTALL_DIR="$HOME/Devils-Mini-OS"

detect_platform() {
    if [[ -n "${TERMUX_VERSION:-}" ]] || [[ -d "/data/data/com.termux/files" ]]; then
        echo "termux"
    elif [[ -f "/etc/os-release" ]]; then
        echo "linux"
    else
        echo "unknown"
    fi
}

detect_termux_source() {
    if [[ "$(detect_platform)" != "termux" ]]; then
        echo "not-termux"
        return
    fi
    # Check package manager source
    if command -v apt >/dev/null 2>&1; then
        local src
        src=$(apt-cache policy 2>/dev/null | grep -o "termux.net\|packages.termux.dev\|f-droid" | head -1)
        if [[ -n "$src" ]]; then
            echo "f-droid"
            return
        fi
    fi
    # Check for GitHub-specific markers
    if [[ -f "$PREFIX/etc/apt/sources.list.d/termux-main.list" ]]; then
        if grep -q "github" "$PREFIX/etc/apt/sources.list.d/termux-main.list" 2>/dev/null; then
            echo "github"
            return
        fi
    fi
    # Check for Play Store markers (deprecated, no longer updated)
    if [[ "$TERMUX_VERSION" == "0.118"* ]] || [[ ! -d "$PREFIX" ]]; then
        echo "play-store"
        return
    fi
    echo "unknown"
}

check_bash_version() {
    if [[ "${BASH_VERSINFO[0]}" -lt 4 ]] || [[ "${BASH_VERSINFO[0]}" -eq 4 && "${BASH_VERSINFO[1]}" -lt 3 ]]; then
        echo -e "${RED}ERROR: Bash 4.3+ required. You have ${BASH_VERSION}${NC}"
        echo "Run: pkg install bash && chsh -s bash"
        exit 1
    fi
}

print_banner() {
    echo -e "${CYAN}"
    cat << 'EOF'
  ___         _ _   _       __  __ _       _   ___  ____  
 |   \ ___ __| | | | |     |  \/  (_)_____| | / _ \/ ___| 
 | |) / -_) _` | |_| |     | |\/| | |_  /_  || (_) \___ \ 
 |___/\___\__,_|\___/      |_|  |_|_|/__/ |_| \___/|____/ 

EOF
    echo -e "${NC}"
    echo -e "${GREEN}  A mini OS for Termux — pure bash, zero dependencies${NC}"
    echo ""
}

repair_mode() {
    echo -e "${YELLOW}🔧 Repair mode: Re-linking and fixing permissions...${NC}"

    if [[ ! -d "$INSTALL_DIR" ]]; then
        echo -e "${RED}❌ Repo not found at $INSTALL_DIR${NC}"
        echo "Run without --repair to install fresh."
        exit 1
    fi

    local prefix
    prefix="${PREFIX:-/usr}"

    # Re-link main entry
    ln -sf "$INSTALL_DIR/devils-minios.sh" "$prefix/bin/devils-minios" 2>/dev/null || {
        echo -e "${YELLOW}⚠️ Could not create symlink. You may need to run: sudo ln -s $INSTALL_DIR/devils-minios.sh /usr/local/bin/devils-minios${NC}"
    }

    # Fix permissions
    chmod +x "$INSTALL_DIR/devils-minios.sh"
    chmod +x "$INSTALL_DIR/modules/"*.sh
    chmod +x "$INSTALL_DIR/install.sh"

    # Recreate config dirs
    mkdir -p "$HOME/.config/devils-minios/"{logs,cache,pids,crashes,tmp,plugins,templates}

    echo -e "${GREEN}✅ Repair complete. Run 'devils-minios' to start.${NC}"
    exit 0
}

main() {
    # Handle --repair flag
    if [[ "${1:-}" == "--repair" ]]; then
        repair_mode
    fi

    print_banner

    # Bash version check
    check_bash_version
    echo -e "${GREEN}✓ Bash version OK (${BASH_VERSION})${NC}"

    # Platform detection
    local platform
    platform=$(detect_platform)
    echo -e "${BLUE}Platform: $platform${NC}"

    # Termux source check
    if [[ "$platform" == "termux" ]]; then
        local source
        source=$(detect_termux_source)
        echo -e "${BLUE}Termux source: $source${NC}"

        if [[ "$source" == "play-store" ]]; then
            echo ""
            echo -e "${RED}╔════════════════════════════════════════════════════════════╗${NC}"
            echo -e "${RED}║  ⚠️  PLAY STORE TERMUX DETECTED                         ║${NC}"
            echo -e "${RED}║                                                            ║${NC}"
            echo -e "${RED}║  This version is deprecated and lacks full functionality.  ║${NC}"
            echo -e "${RED}║  Install from F-Droid or GitHub for the best experience.  ║${NC}"
            echo -e "${RED}║  https://f-droid.org/packages/com.termux/                  ║${NC}"
            echo -e "${RED}╚════════════════════════════════════════════════════════════╝${NC}"
            echo ""
            read -rp "Continue anyway? [y/N] " response
            if [[ ! "$response" =~ ^[Yy]$ ]]; then
                exit 1
            fi
        fi

        # Check for git
        if ! command -v git >/dev/null 2>&1; then
            echo -e "${YELLOW}git not found. Installing...${NC}"
            pkg install -y git
        fi
    elif [[ "$platform" == "linux" ]]; then
        if ! command -v git >/dev/null 2>&1; then
            echo -e "${YELLOW}git not found. Please install git first.${NC}"
            echo "  sudo apt install git   # Debian/Ubuntu"
            echo "  sudo dnf install git     # Fedora"
            echo "  sudo pacman -S git       # Arch"
            exit 1
        fi
    fi

    # Clone or update
    if [[ -d "$INSTALL_DIR/.git" ]]; then
        echo -e "${BLUE}Updating existing installation...${NC}"
        cd "$INSTALL_DIR"
        git pull --ff-only || {
            echo -e "${YELLOW}⚠️ git pull failed. Continuing with local files...${NC}"
        }
    else
        echo -e "${BLUE}Cloning repository...${NC}"
        rm -rf "$INSTALL_DIR"
        git clone "$REPO_URL" "$INSTALL_DIR"
    fi

    cd "$INSTALL_DIR"

    # Fix permissions
    chmod +x devils-minios.sh
    chmod +x modules/*.sh
    chmod +x install.sh

    # Create config directories
    mkdir -p "$HOME/.config/devils-minios/"{logs,cache,pids,crashes,tmp,plugins,templates}

    # Create symlink
    local prefix
    prefix="${PREFIX:-/usr}"

    if [[ "$platform" == "termux" ]]; then
        ln -sf "$INSTALL_DIR/devils-minios.sh" "$prefix/bin/devils-minios"
    else
        # Linux: try /usr/local/bin, fallback to ~/.local/bin
        if [[ -w "/usr/local/bin" ]]; then
            ln -sf "$INSTALL_DIR/devils-minios.sh" "/usr/local/bin/devils-minios"
        else
            mkdir -p "$HOME/.local/bin"
            ln -sf "$INSTALL_DIR/devils-minios.sh" "$HOME/.local/bin/devils-minios"
            # Add to PATH if needed
            if [[ ":$PATH:" != *":$HOME/.local/bin:"* ]]; then
                echo 'export PATH="$HOME/.local/bin:$PATH"' >> "$HOME/.bashrc"
                echo -e "${YELLOW}⚠️ Added ~/.local/bin to PATH. Run: source ~/.bashrc${NC}"
            fi
        fi
    fi

    echo ""
    echo -e "${GREEN}╔════════════════════════════════════════════════════════════╗${NC}"
    echo -e "${GREEN}║  ✅ Installation Complete!                                ║${NC}"
    echo -e "${GREEN}╚════════════════════════════════════════════════════════════╝${NC}"
    echo ""
    echo -e "${CYAN}Launch with:${NC} ${YELLOW}devils-minios${NC}"
    echo ""

    # Ask to launch now
    read -rp "Launch now? [Y/n] " launch_now
    if [[ ! "$launch_now" =~ ^[Nn]$ ]]; then
        exec "$INSTALL_DIR/devils-minios.sh"
    fi
}

main "$@"
