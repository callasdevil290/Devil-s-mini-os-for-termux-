# Devil's Mini OS Launcher

> A mini OS for Termux — proot distros, desktops, universal package manager, all in pure bash

[![License: MIT](https://img.shields.io/badge/License-MIT-yellow.svg)](https://opensource.org/licenses/MIT)
[![Platform](https://img.shields.io/badge/platform-Termux%20%7C%20Linux-blue)]()
[![Language](https://img.shields.io/badge/language-Bash%204.3%2B-green)]()

## ⚠️ Important: Install Termux from F-Droid or GitHub

**Do NOT install Termux from the Play Store** — it is deprecated and incompatible with modern Android. Use:
- [F-Droid](https://f-droid.org/packages/com.termux/)
- [GitHub Releases](https://github.com/termux/termux-app/releases)

## Features

| Feature | Description |
|---------|-------------|
| 🐧 Linux Environments | Install and manage proot distros (Ubuntu, Debian, Arch, etc.) |
| 🖥️ Desktop Environments | 48 desktops with tier system (Tier 1/2/3) |
| 📦 App Stores | Native Termux apps + Proot apps (40 curated) |
| ❄️ Nix Packages | 80,000+ packages via Nix in proot |
| 📱 Android Tools | ADB, fastboot, logcat, battery, clipboard |
| 🛠️ Workspaces | Project templates with Git integration |
| 🏥 System Doctor | Health monitoring with daemon |
| 🎨 Themes | 5 color themes + ASCII banners |
| 🔌 Plugins | Third-party extensions with whitelist security |

## Quick Start

```bash
# Install git
pkg install git

# Clone and install
git clone https://github.com/callasdevil290/Devils-Mini-OS.git
cd Devils-Mini-OS
bash install.sh
```

## Launch

```bash
devils-minios
```

## Requirements

| Requirement | Value |
|-------------|-------|
| Android | 7.0+ (API 24+) |
| Termux Source | F-Droid or GitHub |
| Bash | 4.3+ |
| Storage | 500MB minimum, 2GB recommended |
| RAM | 2GB minimum, 4GB recommended for desktops |

## Menu Options

1. 🐧 Linux Environments — Proot distro management
2. 📁 File Manager — Built-in file operations
3. 📦 Termux App Store — Native Termux packages
4. 🐧 Proot App Store — 40 curated proot apps
5. 🖥️ Desktop Environments — 48 DEs with tier system
6. ❄️ Nix Packages — Nix package manager
7. 📱 Android Tools — ADB, fastboot, termux-api
8. 🛠️ Workspace Templates — Project scaffolding
9. 🏥 System Doctor — Health monitoring
10. 📜 Log Viewer — Structured logging
11. 🎨 Customize — Themes and banners
12. ⚡ System Tools — Maintenance utilities
13. ℹ️ System Info — System information
14. 🔄 Update All — Update everything
15. 🔌 Plugin Manager — Third-party plugins
16. 📋 Recent Actions — Activity history

## Architecture

- **Pure Bash** — Zero compiled dependencies
- **Modular** — 17 separate module files
- **Platform-aware** — Detects Termux vs Linux, Android version, architecture
- **Security** — Input sanitization, plugin whitelist, no eval
- **Logging** — Dual-format (plain text + JSON) with atomic writes

## Security

- Input sanitization on all user input
- Plugin command whitelist validation
- Restricted PATH subshells for plugins
- No `eval` usage
- External storage execution blocking (Android 10+)

## License

MIT License — see [LICENSE](LICENSE)

## Contributing

Pull requests welcome! Please ensure:
- Pure bash only (no Python, Node.js, etc.)
- Follows existing code style
- Includes tests where applicable
- Documentation updated

---

Built with ❤️ and pure bash for the Termux community.
