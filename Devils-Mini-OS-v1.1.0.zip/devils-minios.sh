#!/usr/bin/env bash
# =============================================================================
# Devil's Mini OS Launcher - devils-minios.sh
# Version: v1.1.0 (v2026.07.01)
# License: MIT
# Author: callasdevil290
# Repository: https://github.com/callasdevil290/Devils-Mini-OS
# =============================================================================
set -euo pipefail

# --- Version & Metadata ---
readonly DMOL_VERSION="v1.1.0"
readonly DMOL_DATE="v2026.07.01"
readonly DMOL_REPO="https://github.com/callasdevil290/Devils-Mini-OS"

# --- Base Paths ---
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
readonly SCRIPT_DIR

# --- Trap Cleanup ---
tmp_files=()
trap_cleanup() {
    local f
    for f in "${tmp_files[@]}"; do
        [[ -f "$f" ]] && rm -f "$f"
    done
}
trap 'trap_cleanup' EXIT

# --- Bash Version Check ---
if [[ "${BASH_VERSINFO[0]}" -lt 4 ]] || [[ "${BASH_VERSINFO[0]}" -eq 4 && "${BASH_VERSINFO[1]}" -lt 3 ]]; then
    echo "ERROR: Bash 4.3+ required. You have ${BASH_VERSION}"
    echo "Run: pkg install bash && chsh -s bash"
    exit 1
fi

# --- Source Core Module ---
if [[ -f "$SCRIPT_DIR/modules/core.sh" ]]; then
    source "$SCRIPT_DIR/modules/core.sh"
else
    echo "ERROR: core.sh not found. Run: bash install.sh --repair"
    exit 1
fi

# --- CLI Flags ---
DMOL_SAFE_MODE=false
DMOL_DEBUG=false
DMOL_NO_CHECKS=false

parse_args() {
    while [[ $# -gt 0 ]]; do
        case "$1" in
            -h|--help)
                show_help
                exit 0
                ;;
            -v|--version)
                echo "Devil's Mini OS Launcher $DMOL_VERSION ($DMOL_DATE)"
                exit 0
                ;;
            --safe-mode)
                DMOL_SAFE_MODE=true
                ;;
            --debug)
                DMOL_DEBUG=true
                ;;
            --no-checks)
                DMOL_NO_CHECKS=true
                ;;
            *)
                echo "Unknown option: $1"
                show_help
                exit 1
                ;;
        esac
        shift
    done
}

show_help() {
    cat << 'EOF'
Devil's Mini OS Launcher - A mini OS for Termux

Usage: devils-minios [OPTIONS]

Options:
  -h, --help       Show this help message
  -v, --version    Show version information
  --safe-mode      Enter safe mode (crash recovery)
  --debug          Enable debug logging
  --no-checks      Skip platform compatibility checks

Environment Variables:
  DMOL_DEBUG=1     Enable debug logging
  DMOL_NO_CHECKS=1 Skip platform checks

Examples:
  devils-minios              # Normal launch
  devils-minios --safe-mode  # Enter safe mode
  DMOL_DEBUG=1 devils-minios # Debug mode

Repository: https://github.com/callasdevil290/Devils-Mini-OS
EOF
}

# --- Main Loop ---
main() {
    parse_args "$@"

    # Initialize system
    init_system

    # Check for crash flag -> safe mode
    if [[ "$DMOL_SAFE_MODE" == true ]] || [[ -f "$DMOL_CONFIG_DIR/.crash-flag" ]]; then
        safe_mode_menu
        return
    fi

    # First run check
    first_run_check

    # Main menu loop
    while true; do
        show_main_menu
        local choice
        read -rp "Enter choice: " choice
        choice=$(sanitize_input "$choice")

        case "$choice" in
            1)  source "$SCRIPT_DIR/modules/linux_env.sh"; linux_env_menu ;;
            2)  source "$SCRIPT_DIR/modules/file_mgr.sh"; file_mgr_menu ;;
            3)  source "$SCRIPT_DIR/modules/termux_apps.sh"; termux_apps_menu ;;
            4)  source "$SCRIPT_DIR/modules/proot_apps.sh"; proot_apps_menu ;;
            5)  source "$SCRIPT_DIR/modules/desktop_env.sh"; desktop_env_menu ;;
            6)  source "$SCRIPT_DIR/modules/nix_pkgs.sh"; nix_pkgs_menu ;;
            7)  source "$SCRIPT_DIR/modules/android_tools.sh"; android_tools_menu ;;
            8)  source "$SCRIPT_DIR/modules/workspace.sh"; workspace_menu ;;
            9)  source "$SCRIPT_DIR/modules/health_check.sh"; health_check_menu ;;
            10) source "$SCRIPT_DIR/modules/log_viewer.sh"; log_viewer_menu ;;
            11) source "$SCRIPT_DIR/modules/customize.sh"; customize_menu ;;
            12) source "$SCRIPT_DIR/modules/system_tools.sh"; system_tools_menu ;;
            13) source "$SCRIPT_DIR/modules/system_info.sh"; system_info_menu ;;
            14) source "$SCRIPT_DIR/modules/update_all.sh"; update_all_menu ;;
            15) source "$SCRIPT_DIR/modules/plugin_mgr.sh"; plugin_mgr_menu ;;
            16) source "$SCRIPT_DIR/modules/recent_actions.sh"; recent_actions_menu ;;
            0)  log_info "User exited launcher"; clear_screen; echo "Goodbye!"; exit 0 ;;
            *)  show_error "Invalid choice. Please enter 0-16."; press_enter ;;
        esac
    done
}

# --- Error Trap ---
trap 'log_error "Fatal error on line ${LINENO}: $?"; touch "$DMOL_CONFIG_DIR/.crash-flag" 2>/dev/null || true' ERR

main "$@"
