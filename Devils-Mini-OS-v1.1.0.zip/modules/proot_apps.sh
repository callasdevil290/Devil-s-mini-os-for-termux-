#!/usr/bin/env bash
# =============================================================================
# Devil's Mini OS Launcher - proot_apps.sh
# Version: v1.1.0
# Purpose: Install apps inside proot distros with arch + proot_limit tags
# =============================================================================

# --- Proot App Database (40 apps) ---
declare -A PROOT_APPS=(
    ["vscode"]="VS Code:Full GUI editor:180MB:dev-proot:apt install -y code:all:none"
    ["geany"]="Geany:Lightweight IDE:50MB:dev-proot:apt install -y geany:all:none"
    ["kate"]="Kate:KDE text editor:30MB:dev-proot:apt install -y kate:all:none"
    ["gedit"]="Gedit:GNOME text editor:25MB:dev-proot:apt install -y gedit:all:none"
    ["firefox"]="Firefox:Web browser:200MB:browser:apt install -y firefox-esr:all:none"
    ["chromium"]="Chromium:Open-source browser:250MB:browser:apt install -y chromium:all:none"
    ["libreoffice"]="LibreOffice:Office suite:400MB:office:apt install -y libreoffice:all:none"
    ["gimp"]="GIMP:Image editor:300MB:graphics:apt install -y gimp:all:none"
    ["inkscape"]="Inkscape:Vector graphics:150MB:graphics:apt install -y inkscape:all:none"
    ["vlc"]="VLC:Media player:100MB:media:apt install -y vlc:all:none"
    ["mpv"]="mpv:Media player:50MB:media:apt install -y mpv:all:none"
    ["telegram"]="Telegram:Messaging app:80MB:comm:apt install -y telegram-desktop:all:none"
    ["keepassxc"]="KeePassXC:Password manager:50MB:security:apt install -y keepassxc:all:none"
    ["filezilla"]="FileZilla:FTP client:40MB:net:apt install -y filezilla:all:none"
    ["retroarch"]="RetroArch:Game emulator:100MB:game:apt install -y retroarch:all:none"
    ["supertuxkart"]="SuperTuxKart:Racing game:200MB:game:apt install -y supertuxkart:all:none"
    ["python3"]="Python 3:Python interpreter:50MB:dev-lang:apt install -y python3 python3-pip:all:none"
    ["nodejs"]="Node.js:JavaScript runtime:80MB:dev-lang:apt install -y nodejs npm:all:none"
    ["golang"]="Go:Go programming language:150MB:dev-lang:apt install -y golang-go:all:none"
    ["rustc"]="Rust:Rust compiler:200MB:dev-lang:apt install -y rustc cargo:all:none"
    ["ruby"]="Ruby:Ruby interpreter:30MB:dev-lang:apt install -y ruby:all:none"
    ["php"]="PHP:PHP interpreter:20MB:dev-lang:apt install -y php:all:none"
    ["java"]="OpenJDK:Java runtime:200MB:dev-lang:apt install -y default-jdk:all:none"
    ["thunderbird"]="Thunderbird:Email client:150MB:comm:apt install -y thunderbird:all:none"
    ["pidgin"]="Pidgin:Multi-protocol chat:30MB:comm:apt install -y pidgin:all:none"
    ["wireshark"]="Wireshark:Network analyzer:200MB:net:apt install -y wireshark:all:none"
    ["nmap"]="Nmap:Network scanner:20MB:net:apt install -y nmap:all:none"
    ["netcat"]="Netcat:Network utility:5MB:net:apt install -y netcat:all:none"
    ["pcmanfm"]="PCManFM:File manager:30MB:files:apt install -y pcmanfm:all:none"
    ["nautilus"]="Nautilus:GNOME file manager:50MB:files:apt install -y nautilus:all:none"
    ["dolphin"]="Dolphin:KDE file manager:60MB:files:apt install -y dolphin:all:none"
    ["konsole"]="Konsole:KDE terminal:40MB:term:apt install -y konsole:all:none"
    ["gnome-terminal"]="GNOME Terminal:GNOME terminal:30MB:term:apt install -y gnome-terminal:all:none"
    ["xfce4-terminal"]="XFCE Terminal:XFCE terminal:20MB:term:apt install -y xfce4-terminal:all:none"
    ["audacity"]="Audacity:Audio editor:100MB:media:apt install -y audacity:all:none"
    ["obs-studio"]="OBS Studio:Streaming/recording:300MB:media:apt install -y obs-studio:all:none"
    ["blender"]="Blender:3D modeling:500MB:graphics:apt install -y blender:all:heavy-io"
    ["kdenlive"]="Kdenlive:Video editor:200MB:media:apt install -y kdenlive:all:heavy-io"
    ["android-studio"]="Android Studio:Android IDE:1000MB:dev-proot:apt install -y android-sdk:all:heavy-io"
    ["qemu"]="QEMU:Virtualization:200MB:sys:apt install -y qemu-system-x86:all:no-systemd"
)

# Categories
declare -a PROOT_CATEGORIES=(
    "Development (IDE & Editors)"
    "Development (Languages)"
    "Browsers"
    "Office & Productivity"
    "Graphics & Design"
    "Media Players"
    "Communication"
    "Security & Privacy"
    "System Utilities"
    "File Managers"
    "Terminal Emulators"
    "Networking"
    "Games"
)

proot_category_map() {
    case "$1" in
        "Development (IDE & Editors)") echo "dev-proot" ;;
        "Development (Languages)") echo "dev-lang" ;;
        "Browsers") echo "browser" ;;
        "Office & Productivity") echo "office" ;;
        "Graphics & Design") echo "graphics" ;;
        "Media Players") echo "media" ;;
        "Communication") echo "comm" ;;
        "Security & Privacy") echo "security" ;;
        "System Utilities") echo "sys" ;;
        "File Managers") echo "files" ;;
        "Terminal Emulators") echo "term" ;;
        "Networking") echo "net" ;;
        "Games") echo "game" ;;
        *) echo "$1" ;;
    esac
}

proot_apps_menu() {
    while true; do
        draw_header
        echo -e "${C_CYAN}${C_BOLD}🐧 Proot App Store (40 apps)${C_RESET}"
        echo ""

        local current_arch
        current_arch=$(detect_architecture)
        echo -e "${C_DIM}Your architecture: $current_arch${C_RESET}"
        echo ""

        echo "Categories:"
        local i=1
        for cat in "${PROOT_CATEGORIES[@]}"; do
            echo "  $i) $cat"
            ((i++))
        done
        echo ""
        echo "  a) Show all apps"
        echo "  s) Search apps"
        echo "  0) Back to Main Menu"
        echo ""

        read -rp "Enter choice: " choice
        choice=$(sanitize_input "$choice")

        case "$choice" in
            [1-9]|1[0-3])
                if validate_number "$choice" 1 13; then
                    show_proot_category "${PROOT_CATEGORIES[$((choice-1))]}"
                fi
                ;;
            a|A) show_all_proot_apps ;;
            s|S) search_proot_apps ;;
            0) return ;;
            *) show_error "Invalid choice"; press_enter ;;
        esac
    done
}

show_proot_category() {
    local category="$1"
    local cat_code
    cat_code=$(proot_category_map "$category")

    while true; do
        draw_header
        echo -e "${C_CYAN}${C_BOLD}🐧 $category${C_RESET}"
        echo ""

        local current_arch
        current_arch=$(detect_architecture)

        local apps=()
        local keys=()
        for key in "${!PROOT_APPS[@]}"; do
            local data="${PROOT_APPS[$key]}"
            local app_cat
            app_cat=$(echo "$data" | cut -d: -f4)
            if [[ "$app_cat" == "$cat_code" ]]; then
                apps+=("$data")
                keys+=("$key")
            fi
        done

        if [[ ${#apps[@]} -eq 0 ]]; then
            echo -e "${C_DIM}No apps in this category${C_RESET}"
            press_enter
            return
        fi

        local i=1
        for app in "${apps[@]}"; do
            local name desc size arch_tag limit_tag
            name=$(echo "$app" | cut -d: -f1)
            desc=$(echo "$app" | cut -d: -f2)
            size=$(echo "$app" | cut -d: -f3)
            arch_tag=$(echo "$app" | cut -d: -f6)
            limit_tag=$(echo "$app" | cut -d: -f7)

            local compat="✓"
            local compat_color="$C_GREEN"

            if [[ "$arch_tag" != "all" && "$arch_tag" != "$current_arch" ]]; then
                compat="✗ ${arch_tag} only"
                compat_color="$C_RED"
            fi

            local warning=""
            if [[ "$limit_tag" == "no-systemd" ]]; then
                warning=" [no systemd]"
            elif [[ "$limit_tag" == "heavy-io" ]]; then
                warning=" [heavy I/O]"
            elif [[ "$limit_tag" == "no-fuse" ]]; then
                warning=" [no FUSE]"
            fi

            printf "  %2d) [%s%s%s] %-20s %s (%s)%s\n" "$i" "$compat_color" "$compat" "$C_RESET" "$name" "$desc" "$size" "$warning"
            ((i++))
        done

        echo ""
        echo "Enter numbers to install (space-separated)"
        echo "  0) Back"
        echo ""

        read -rp "Select: " selections
        selections=$(sanitize_input "$selections")

        if [[ "$selections" == "0" ]]; then
            return
        fi

        local selected_keys=()
        for num in $selections; do
            if validate_number "$num" 1 "${#apps[@]}"; then
                selected_keys+=("${keys[$((num-1))]}")
            fi
        done

        if [[ ${#selected_keys[@]} -gt 0 ]]; then
            install_proot_apps "${selected_keys[@]}"
        fi
    done
}

show_all_proot_apps() {
    while true; do
        draw_header
        echo -e "${C_CYAN}${C_BOLD}🐧 All Proot Apps${C_RESET}"
        echo ""

        local current_arch
        current_arch=$(detect_architecture)

        local keys=()
        for key in "${!PROOT_APPS[@]}"; do
            keys+=("$key")
        done

        IFS=$'\n' sorted_keys=($(sort <<<"${keys[*]}")); unset IFS

        local i=1
        for key in "${sorted_keys[@]}"; do
            local data="${PROOT_APPS[$key]}"
            local name desc size arch_tag limit_tag
            name=$(echo "$data" | cut -d: -f1)
            desc=$(echo "$data" | cut -d: -f2)
            size=$(echo "$data" | cut -d: -f3)
            arch_tag=$(echo "$data" | cut -d: -f6)
            limit_tag=$(echo "$data" | cut -d: -f7)

            local compat="✓"
            local compat_color="$C_GREEN"

            if [[ "$arch_tag" != "all" && "$arch_tag" != "$current_arch" ]]; then
                compat="✗"
                compat_color="$C_RED"
            fi

            printf "  %2d) [%s%s%s] %-20s %s (%s)\n" "$i" "$compat_color" "$compat" "$C_RESET" "$name" "$desc" "$size"
            ((i++))
        done

        echo ""
        echo "Enter numbers to install (space-separated)"
        echo "  0) Back"
        echo ""

        read -rp "Select: " selections
        selections=$(sanitize_input "$selections")

        if [[ "$selections" == "0" ]]; then
            return
        fi

        local selected_keys=()
        for num in $selections; do
            if validate_number "$num" 1 "${#sorted_keys[@]}"; then
                selected_keys+=("${sorted_keys[$((num-1))]}")
            fi
        done

        if [[ ${#selected_keys[@]} -gt 0 ]]; then
            install_proot_apps "${selected_keys[@]}"
        fi
    done
}

search_proot_apps() {
    echo ""
    read -rp "Search: " query
    query=$(sanitize_input "$query")

    if [[ -z "$query" ]]; then
        show_error "Search query cannot be empty"
        press_enter
        return
    fi

    draw_header
    echo -e "${C_CYAN}${C_BOLD}🔍 Search Results: '$query'${C_RESET}"
    echo ""

    local current_arch
    current_arch=$(detect_architecture)
    local found=false
    local i=1
    local keys=()
    local matched=()

    for key in "${!PROOT_APPS[@]}"; do
        local data="${PROOT_APPS[$key]}"
        local name desc
        name=$(echo "$data" | cut -d: -f1)
        desc=$(echo "$data" | cut -d: -f2)

        if [[ "$name" == *"$query"* || "$desc" == *"$query"* || "$key" == *"$query"* ]]; then
            keys+=("$key")
            matched+=("$data")
            local compat="✓"
            [[ "$(echo "$data" | cut -d: -f6)" != "all" && "$(echo "$data" | cut -d: -f6)" != "$current_arch" ]] && compat="✗"
            printf "  %2d) [%s] %-20s %s\n" "$i" "$compat" "$name" "$desc"
            ((i++))
            found=true
        fi
    done

    if [[ "$found" == false ]]; then
        echo -e "${C_DIM}No results found${C_RESET}"
        press_enter
        return
    fi

    echo ""
    echo "Enter numbers to install (space-separated)"
    echo "  0) Back"
    echo ""

    read -rp "Select: " selections
    selections=$(sanitize_input "$selections")

    if [[ "$selections" == "0" ]]; then
        return
    fi

    local selected_keys=()
    for num in $selections; do
        if validate_number "$num" 1 "${#matched[@]}"; then
            selected_keys+=("${keys[$((num-1))]}")
        fi
    done

    if [[ ${#selected_keys[@]} -gt 0 ]]; then
        install_proot_apps "${selected_keys[@]}"
    fi
}

install_proot_apps() {
    local keys=("$@")

    if [[ ${#keys[@]} -eq 0 ]]; then
        return
    fi

    # Select target distro first
    local distros=()
    while IFS= read -r d; do
        [[ -n "$d" ]] && distros+=("$d")
    done < <(source "$SCRIPT_DIR/modules/linux_env.sh" && list_installed_distros 2>/dev/null || true)

    # Fallback: try to find distros manually
    if [[ ${#distros[@]} -eq 0 ]]; then
        local runtime_dir="${RUNTIME_DIR:-$PREFIX/var/lib}"
        if [[ -d "$runtime_dir/proot-distro/installed-rootfs" ]]; then
            for d in "$runtime_dir/proot-distro/installed-rootfs"/*/; do
                [[ -d "$d" ]] && distros+=("$(basename "$d")")
            done
        fi
        if [[ -d "$runtime_dir/proot-distro/containers" ]]; then
            for d in "$runtime_dir/proot-distro/containers"/*/; do
                local name
                name=$(basename "$d")
                local found=false
                for existing in "${distros[@]}"; do
                    [[ "$existing" == "$name" ]] && found=true
                done
                [[ "$found" == false ]] && distros+=("$name")
            done
        fi
    fi

    if [[ ${#distros[@]} -eq 0 ]]; then
        show_error "No proot distros installed. Install a distro first in Linux Environments."
        press_enter
        return
    fi

    echo ""
    echo "Target distro:"
    local i=1
    for d in "${distros[@]}"; do
        echo "  $i) $d"
        ((i++))
    done
    echo ""

    read -rp "Select distro: " dchoice
    dchoice=$(sanitize_input "$dchoice")

    if ! validate_number "$dchoice" 1 "${#distros[@]}"; then
        show_error "Invalid selection"
        press_enter
        return
    fi

    local target_distro="${distros[$((dchoice-1))]}"

    echo ""
    echo -e "${C_BLUE}Installing ${#keys[@]} app(s) in $target_distro...${C_RESET}"
    echo ""

    local failed=()
    local success=()

    for key in "${keys[@]}"; do
        local data="${PROOT_APPS[$key]}"
        local name cmd
        name=$(echo "$data" | cut -d: -f1)
        cmd=$(echo "$data" | cut -d: -f5)

        echo -e "${C_CYAN}Installing $name in $target_distro...${C_RESET}"

        # Detect package manager and adapt command
        local adapted_cmd
        adapted_cmd=$(adapt_pm_command "$target_distro" "$cmd")

        if proot-distro login "$target_distro" -- bash -c "$adapted_cmd" 2>&1; then
            echo -e "${C_GREEN}  ✓ $name installed${C_RESET}"
            success+=("$name")
            log_recent "INSTALL_PROOT_APP" "$name in $target_distro"
        else
            echo -e "${C_RED}  ✗ $name failed${C_RESET}"
            failed+=("$name")
            log_warn "Failed to install proot app: $name in $target_distro"
        fi
        echo ""
    done

    echo ""
    if [[ ${#success[@]} -gt 0 ]]; then
        show_success "Installed in $target_distro: ${success[*]}"
    fi
    if [[ ${#failed[@]} -gt 0 ]]; then
        show_error "Failed: ${failed[*]}"
    fi

    press_enter
}

# --- Package Manager Auto-Detect & Adapt ---
adapt_pm_command() {
    local distro="$1"
    local cmd="$2"

    # Detect PM in proot distro
    local pm
    pm=$(detect_proot_pm "$distro")

    case "$pm" in
        apt|apt-get)
            # cmd is already apt-based, return as-is
            echo "$cmd"
            ;;
        pacman)
            # Convert apt install to pacman -S
            echo "$cmd" | sed 's/apt install -y/pacman -S --noconfirm/g; s/apt install/pacman -S --noconfirm/g'
            ;;
        dnf)
            echo "$cmd" | sed 's/apt install -y/dnf install -y/g; s/apt install/dnf install -y/g'
            ;;
        apk)
            echo "$cmd" | sed 's/apt install -y/apk add/g; s/apt install/apk add/g'
            ;;
        zypper)
            echo "$cmd" | sed 's/apt install -y/zypper install -y/g; s/apt install/zypper install -y/g'
            ;;
        xbps)
            echo "$cmd" | sed 's/apt install -y/xbps-install -y/g; s/apt install/xbps-install -y/g'
            ;;
        emerge)
            echo "$cmd" | sed 's/apt install -y/emerge/g; s/apt install/emerge/g'
            ;;
        *)
            echo "$cmd"
            ;;
    esac
}

detect_proot_pm() {
    local distro="$1"

    # Check cached result
    local cache_file="$DMOL_CACHE_DIR/pm_${distro}.cache"
    if [[ -f "$cache_file" ]]; then
        cat "$cache_file"
        return
    fi

    # Detect by checking which binary exists in proot
    local pm="apt"

    if proot-distro login "$distro" -- bash -c "command -v apt" >/dev/null 2>&1; then
        pm="apt"
    elif proot-distro login "$distro" -- bash -c "command -v pacman" >/dev/null 2>&1; then
        pm="pacman"
    elif proot-distro login "$distro" -- bash -c "command -v dnf" >/dev/null 2>&1; then
        pm="dnf"
    elif proot-distro login "$distro" -- bash -c "command -v apk" >/dev/null 2>&1; then
        pm="apk"
    elif proot-distro login "$distro" -- bash -c "command -v zypper" >/dev/null 2>&1; then
        pm="zypper"
    elif proot-distro login "$distro" -- bash -c "command -v xbps-install" >/dev/null 2>&1; then
        pm="xbps"
    elif proot-distro login "$distro" -- bash -c "command -v emerge" >/dev/null 2>&1; then
        pm="emerge"
    fi

    # Cache result
    echo "$pm" > "$cache_file"
    echo "$pm"
}

# Unified wrappers (exported for use by other modules)
pkg_install() {
    local distro="$1"
    local packages="$2"
    local pm
    pm=$(detect_proot_pm "$distro")

    case "$pm" in
        apt|apt-get)
            proot-distro login "$distro" -- bash -c "apt update && apt install -y $packages"
            ;;
        pacman)
            proot-distro login "$distro" -- bash -c "pacman -Syu --noconfirm $packages"
            ;;
        dnf)
            proot-distro login "$distro" -- bash -c "dnf install -y $packages"
            ;;
        apk)
            proot-distro login "$distro" -- bash -c "apk add $packages"
            ;;
        zypper)
            proot-distro login "$distro" -- bash -c "zypper install -y $packages"
            ;;
        xbps)
            proot-distro login "$distro" -- bash -c "xbps-install -y $packages"
            ;;
        emerge)
            proot-distro login "$distro" -- bash -c "emerge $packages"
            ;;
        *)
            show_error "Unknown package manager in $distro"
            return 1
            ;;
    esac
}

pkg_remove() {
    local distro="$1"
    local packages="$2"
    local pm
    pm=$(detect_proot_pm "$distro")

    case "$pm" in
        apt|apt-get)
            proot-distro login "$distro" -- bash -c "apt remove -y $packages"
            ;;
        pacman)
            proot-distro login "$distro" -- bash -c "pacman -R --noconfirm $packages"
            ;;
        dnf)
            proot-distro login "$distro" -- bash -c "dnf remove -y $packages"
            ;;
        apk)
            proot-distro login "$distro" -- bash -c "apk del $packages"
            ;;
        zypper)
            proot-distro login "$distro" -- bash -c "zypper remove -y $packages"
            ;;
        xbps)
            proot-distro login "$distro" -- bash -c "xbps-remove -y $packages"
            ;;
        emerge)
            proot-distro login "$distro" -- bash -c "emerge --unmerge $packages"
            ;;
        *)
            show_error "Unknown package manager in $distro"
            return 1
            ;;
    esac
}

pkg_update() {
    local distro="$1"
    local pm
    pm=$(detect_proot_pm "$distro")

    case "$pm" in
        apt|apt-get)
            proot-distro login "$distro" -- bash -c "apt update"
            ;;
        pacman)
            proot-distro login "$distro" -- bash -c "pacman -Sy"
            ;;
        dnf)
            proot-distro login "$distro" -- bash -c "dnf check-update"
            ;;
        apk)
            proot-distro login "$distro" -- bash -c "apk update"
            ;;
        zypper)
            proot-distro login "$distro" -- bash -c "zypper refresh"
            ;;
        xbps)
            proot-distro login "$distro" -- bash -c "xbps-install -Su"
            ;;
        emerge)
            proot-distro login "$distro" -- bash -c "emerge --sync"
            ;;
        *)
            show_error "Unknown package manager in $distro"
            return 1
            ;;
    esac
}

pkg_upgrade() {
    local distro="$1"
    local pm
    pm=$(detect_proot_pm "$distro")

    case "$pm" in
        apt|apt-get)
            proot-distro login "$distro" -- bash -c "apt upgrade -y"
            ;;
        pacman)
            proot-distro login "$distro" -- bash -c "pacman -Syu --noconfirm"
            ;;
        dnf)
            proot-distro login "$distro" -- bash -c "dnf upgrade -y"
            ;;
        apk)
            proot-distro login "$distro" -- bash -c "apk upgrade"
            ;;
        zypper)
            proot-distro login "$distro" -- bash -c "zypper update -y"
            ;;
        xbps)
            proot-distro login "$distro" -- bash -c "xbps-install -Suy"
            ;;
        emerge)
            proot-distro login "$distro" -- bash -c "emerge -uDN @world"
            ;;
        *)
            show_error "Unknown package manager in $distro"
            return 1
            ;;
    esac
}

export -f adapt_pm_command detect_proot_pm pkg_install pkg_remove pkg_update pkg_upgrade
