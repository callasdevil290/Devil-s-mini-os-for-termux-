#!/usr/bin/env bash
# =============================================================================
# Devil's Mini OS Launcher - core.sh
# Version: v1.1.0
# Purpose: Foundation module — colors, headers, utils, logging, safe mode,
#          platform detection, UI rendering, session management
# =============================================================================

# --- Color Initialization ---
init_colors() {
    if [[ -t 1 ]] && command -v tput >/dev/null 2>&1; then
        ncolors=$(tput colors 2>/dev/null || echo 0)
        if [[ -n "$ncolors" && "$ncolors" -ge 8 ]]; then
            C_RED=$(tput setaf 1)
            C_GREEN=$(tput setaf 2)
            C_YELLOW=$(tput setaf 3)
            C_BLUE=$(tput setaf 4)
            C_MAGENTA=$(tput setaf 5)
            C_CYAN=$(tput setaf 6)
            C_WHITE=$(tput setaf 7)
            C_BOLD=$(tput bold)
            C_DIM=$(tput dim)
            C_RESET=$(tput sgr0)
        else
            C_RED=''; C_GREEN=''; C_YELLOW=''; C_BLUE=''
            C_MAGENTA=''; C_CYAN=''; C_WHITE=''; C_BOLD=''
            C_DIM=''; C_RESET=''
        fi
    else
        C_RED='\033[0;31m'; C_GREEN='\033[0;32m'; C_YELLOW='\033[1;33m'
        C_BLUE='\033[0;34m'; C_MAGENTA='\033[0;35m'; C_CYAN='\033[0;36m'
        C_WHITE='\033[1;37m'; C_BOLD='\033[1m'; C_DIM='\033[2m'
        C_RESET='\033[0m'
    fi
    export C_RED C_GREEN C_YELLOW C_BLUE C_MAGENTA C_CYAN C_WHITE C_BOLD C_DIM C_RESET
}

# --- Platform Detection ---
detect_platform() {
    if [[ -n "${PROOT_DISTRO_NAME:-}" ]] || [[ -n "${PROOT_DIR:-}" ]]; then
        echo "proot"
    elif [[ -n "${TERMUX_VERSION:-}" ]] || [[ -d "/data/data/com.termux/files" ]]; then
        echo "termux"
    elif [[ -f "/etc/os-release" ]]; then
        echo "linux"
    else
        echo "unknown"
    fi
}

detect_termux_source() {
    if [[ "$(detect_platform)" != "termux" ]]; then
        echo "not-termux"
        return
    fi
    if [[ -f "$PREFIX/etc/apt/sources.list.d/termux-main.list" ]]; then
        if grep -q "github" "$PREFIX/etc/apt/sources.list.d/termux-main.list" 2>/dev/null; then
            echo "github"
            return
        fi
        if grep -q "f-droid\|termux.net\|packages.termux.dev" "$PREFIX/etc/apt/sources.list.d/termux-main.list" 2>/dev/null; then
            echo "f-droid"
            return
        fi
    fi
    # Play Store detection (deprecated version markers)
    if [[ "$TERMUX_VERSION" == "0.118"* ]] || [[ ! -d "$PREFIX" ]]; then
        echo "play-store"
        return
    fi
    echo "unknown"
}

detect_android_version() {
    if [[ "$(detect_platform)" == "termux" ]]; then
        getprop ro.build.version.release 2>/dev/null || echo "0"
    else
        echo "0"
    fi
}

detect_architecture() {
    uname -m
}

detect_termux_api() {
    if command -v termux-battery-status >/dev/null 2>&1; then
        echo "available"
    else
        echo "missing"
    fi
}

has_termux_api() {
    command -v termux-battery-status >/dev/null 2>&1
}

is_proot() {
    [[ -n "${PROOT_DISTRO_NAME:-}" || -n "${PROOT_DIR:-}" ]]
}

is_exec_safe() {
    local path="$1"
    # Block external storage paths on Android 10+
    local android_ver
    android_ver=$(detect_android_version)
    if [[ "$android_ver" -ge 10 ]]; then
        if [[ "$path" == "$HOME/storage/shared"* ]] || [[ "$path" == "/sdcard"* ]] || [[ "$path" == "/storage/emulated"* ]]; then
            return 1
        fi
    fi
    return 0
}

detect_terminal_width() {
    if command -v tput >/dev/null 2>&1; then
        tput cols 2>/dev/null || echo 80
    else
        echo 80
    fi
}

# --- XDG Base Directory Compliance ---
get_config_dir() {
    if [[ "$(detect_platform)" == "termux" ]]; then
        echo "$HOME/.config/devils-minios"
    else
        echo "${XDG_CONFIG_HOME:-$HOME/.config}/devils-minios"
    fi
}

get_cache_dir() {
    if [[ "$(detect_platform)" == "termux" ]]; then
        echo "$HOME/.cache/devils-minios"
    else
        echo "${XDG_CACHE_HOME:-$HOME/.cache}/devils-minios"
    fi
}

# --- Path Initialization ---
init_paths() {
    DMOL_CONFIG_DIR=$(get_config_dir)
    DMOL_CACHE_DIR=$(get_cache_dir)
    export DMOL_CONFIG_DIR DMOL_CACHE_DIR

    mkdir -p "$DMOL_CONFIG_DIR/"{logs,cache,pids,crashes,tmp,plugins,templates}
    mkdir -p "$DMOL_CACHE_DIR/tmp"
}

# --- Battery Check (Termux only) ---
check_battery_before_heavy_op() {
    if [[ "$(detect_platform)" != "termux" ]]; then
        return 0  # Skip on Linux
    fi
    if ! has_termux_api; then
        return 0  # Skip if no API
    fi

    local battery_level
    battery_level=$(termux-battery-status 2>/dev/null | grep -o '"percentage":[0-9]*' | cut -d: -f2 || echo "50")

    if [[ -z "$battery_level" || ! "$battery_level" =~ ^[0-9]+$ ]]; then
        return 0
    fi

    if [[ "$battery_level" -lt 10 ]]; then
        echo -e "${C_RED}❌ CRITICAL: Battery at ${battery_level}%. Operation blocked to prevent data loss.${C_RESET}"
        echo "Please charge your device before continuing."
        return 1
    elif [[ "$battery_level" -lt 20 ]]; then
        echo -e "${C_YELLOW}⚠️  WARNING: Battery at ${battery_level}%. Heavy operations may fail.${C_RESET}"
        read -rp "Continue anyway? [y/N] " confirm
        [[ "$confirm" =~ ^[Yy]$ ]] || return 1
    fi
    return 0
}

# --- Logging (Dual Format + Atomic Writes) ---
log_write() {
    local level="$1"
    local msg="$2"
    local timestamp
    timestamp=$(date '+%Y-%m-%d %H:%M:%S')
    local log_dir="$DMOL_CONFIG_DIR/logs"
    mkdir -p "$log_dir"

    # Plain text — atomic append with file lock
    local tmp_file="$log_dir/.launcher.log.tmp.$$"
    printf '[%s] [%s] %s\n' "$timestamp" "$level" "$msg" >> "$tmp_file"
    (
        flock -x 200
        cat "$tmp_file" >> "$log_dir/launcher.log"
        rm -f "$tmp_file"
    ) 200>"$log_dir/.launcher.lock"

    # JSON — same pattern
    local tmp_json="$log_dir/.launcher.json.tmp.$$"
    printf '{"time":"%s","level":"%s","msg":"%s"}\n' "$timestamp" "$level" "$msg" >> "$tmp_json"
    (
        flock -x 201
        cat "$tmp_json" >> "$log_dir/launcher.json.log"
        rm -f "$tmp_json"
    ) 201>"$log_dir/.launcher.json.lock"

    # Debug output
    if [[ "${DMOL_DEBUG:-false}" == true ]] || [[ "${DMOL_DEBUG:-0}" == "1" ]]; then
        echo -e "${C_DIM}[DEBUG] [$level] $msg${C_RESET}"
    fi

    # Rotation check (best-effort)
    if [[ -f "$log_dir/launcher.log" ]]; then
        local size
        size=$(stat -c%s "$log_dir/launcher.log" 2>/dev/null || echo 0)
        if [[ "$size" -gt 1048576 ]]; then
            rotate_logs
        fi
    fi
}

log_info()  { log_write "INFO" "$1"; }
log_warn()  { log_write "WARN" "$1"; }
log_error() { log_write "ERROR" "$1"; }
log_debug() { log_write "DEBUG" "$1"; }

rotate_logs() {
    local log_dir="$DMOL_CONFIG_DIR/logs"
    local max_logs=5
    for ((i=max_logs-1; i>=1; i--)); do
        [[ -f "$log_dir/launcher.log.$i" ]] && mv "$log_dir/launcher.log.$i" "$log_dir/launcher.log.$((i+1))"
    done
    [[ -f "$log_dir/launcher.log" ]] && mv "$log_dir/launcher.log" "$log_dir/launcher.log.1"

    for ((i=max_logs-1; i>=1; i--)); do
        [[ -f "$log_dir/launcher.json.log.$i" ]] && mv "$log_dir/launcher.json.log.$i" "$log_dir/launcher.json.log.$((i+1))"
    done
    [[ -f "$log_dir/launcher.json.log" ]] && mv "$log_dir/launcher.json.log" "$log_dir/launcher.json.log.1"
}

# --- Recent Actions ---
log_recent() {
    local action="$1"
    local details="${2:-}"
    local timestamp
    timestamp=$(date '+%Y-%m-%d %H:%M:%S')
    local recent_log="$DMOL_CONFIG_DIR/recent.log"
    printf '[%s] [%s] %s\n' "$timestamp" "$action" "$details" >> "$recent_log"
    # Keep only last 20 entries
    if [[ -f "$recent_log" ]]; then
        local lines
        lines=$(wc -l < "$recent_log" 2>/dev/null || echo 0)
        if [[ "$lines" -gt 20 ]]; then
            tail -n 20 "$recent_log" > "$recent_log.tmp" && mv "$recent_log.tmp" "$recent_log"
        fi
    fi
}

# --- Input Sanitization ---
sanitize_input() {
    local input="$1"
    # Remove control characters and ANSI escapes
    input=$(echo "$input" | tr -d '\000-\010\013-\037')
    input=$(echo "$input" | sed 's/\x1b\[[0-9;]*m//g')
    echo "$input"
}

validate_number() {
    local input="$1"
    local min="${2:-0}"
    local max="${3:-999}"
    if [[ ! "$input" =~ ^[0-9]+$ ]]; then
        return 1
    fi
    if [[ "$input" -lt "$min" || "$input" -gt "$max" ]]; then
        return 1
    fi
    return 0
}

# --- UI Rendering ---
clear_screen() {
    clear 2>/dev/null || printf '\033[2J\033[H'
}

draw_header() {
    clear_screen
    local term_width
    term_width=$(detect_terminal_width)

    if [[ "$term_width" -lt 40 ]]; then
        # Minimal mode
        echo -e "${C_BOLD}Devil's Mini OS $DMOL_VERSION${C_RESET}"
        echo "----------------"
        return
    fi

    if [[ "$term_width" -lt 60 ]]; then
        # Compact mode
        echo -e "${C_BOLD}╔════════════════════════════════════╗${C_RESET}"
        echo -e "${C_BOLD}║  DEVIL'S MINI OS v$DMOL_VERSION       ║${C_RESET}"
        echo -e "${C_BOLD}╚════════════════════════════════════╝${C_RESET}"
        return
    fi

    # Full mode
    echo -e "${C_BOLD}╔════════════════════════════════════════════════════════════╗${C_RESET}"
    echo -e "${C_BOLD}║  DEVIL'S MINI OS LAUNCHER ${C_CYAN}$DMOL_VERSION${C_RESET}${C_BOLD}                  ║${C_RESET}"
    echo -e "${C_BOLD}╚════════════════════════════════════════════════════════════╝${C_RESET}"
}

show_banner() {
    local banner_file="$SCRIPT_DIR/data/banners/$(get_setting banner).txt"
    if [[ -f "$banner_file" ]]; then
        local term_width
        term_width=$(detect_terminal_width)
        if [[ "$term_width" -ge 60 ]]; then
            echo -e "${C_MAGENTA}"
            cat "$banner_file"
            echo -e "${C_RESET}"
        elif [[ "$term_width" -ge 40 ]]; then
            echo -e "${C_MAGENTA}"
            head -n 3 "$banner_file" 2>/dev/null || cat "$banner_file"
            echo -e "${C_RESET}"
        fi
    fi
}

# --- User Feedback ---
press_enter() {
    echo ""
    read -rp "Press Enter to continue..."
}

show_error() {
    echo -e "${C_RED}❌ $1${C_RESET}"
    log_error "$1"
}

show_success() {
    echo -e "${C_GREEN}✅ $1${C_RESET}"
    log_info "$1"
}

show_info() {
    echo -e "${C_BLUE}ℹ️  $1${C_RESET}"
    log_info "$1"
}

show_warning() {
    echo -e "${C_YELLOW}⚠️  $1${C_RESET}"
    log_warn "$1"
}

# --- Settings Management ---
get_setting() {
    local key="$1"
    local defaults_file="$SCRIPT_DIR/data/defaults.conf"
    local user_conf="$DMOL_CONFIG_DIR/user.conf"

    # Check user config first
    if [[ -f "$user_conf" ]]; then
        local val
        val=$(grep "^${key}=" "$user_conf" 2>/dev/null | cut -d= -f2- | head -1)
        if [[ -n "$val" ]]; then
            echo "$val"
            return
        fi
    fi

    # Fallback to defaults
    if [[ -f "$defaults_file" ]]; then
        grep "^${key}=" "$defaults_file" 2>/dev/null | cut -d= -f2- | head -1
    fi
}

set_setting() {
    local key="$1"
    local value="$2"
    local user_conf="$DMOL_CONFIG_DIR/user.conf"

    if [[ -f "$user_conf" ]]; then
        if grep -q "^${key}=" "$user_conf" 2>/dev/null; then
            sed -i "s/^${key}=.*/${key}=${value}/" "$user_conf"
        else
            echo "${key}=${value}" >> "$user_conf"
        fi
    else
        echo "${key}=${value}" > "$user_conf"
    fi
}

# --- Safe Mode ---
safe_mode_menu() {
    clear_screen
    echo -e "${C_RED}${C_BOLD}╔════════════════════════════════════════════════════════════╗${C_RESET}"
    echo -e "${C_RED}${C_BOLD}║  ⚠️  SAFE MODE — Crash Recovery                           ║${C_RESET}"
    echo -e "${C_RED}${C_BOLD}╚════════════════════════════════════════════════════════════╝${C_RESET}"
    echo ""

    if [[ -f "$DMOL_CONFIG_DIR/.crash-flag" ]]; then
        echo -e "${C_YELLOW}A crash was detected on the previous run.${C_RESET}"
        echo ""
    fi

    echo "  1) 🔄 Restart Launcher (normal mode)"
    echo "  2) 📜 View Crash Log"
    echo "  3) 🔄 Reset to Defaults"
    echo "  4) 🚪 Exit"
    echo ""

    local choice
    read -rp "Enter choice: " choice
    choice=$(sanitize_input "$choice")

    case "$choice" in
        1)
            rm -f "$DMOL_CONFIG_DIR/.crash-flag"
            log_info "Safe mode: User chose restart"
            exec "$SCRIPT_DIR/devils-minios.sh"
            ;;
        2)
            if [[ -f "$DMOL_CONFIG_DIR/crashes/crash-$(date +%Y%m%d)*.log" ]]; then
                local latest
                latest=$(ls -t "$DMOL_CONFIG_DIR/crashes/"crash-*.log 2>/dev/null | head -1)
                echo ""
                cat "$latest"
            else
                echo "No crash log found."
            fi
            press_enter
            safe_mode_menu
            ;;
        3)
            rm -f "$DMOL_CONFIG_DIR/user.conf"
            rm -f "$DMOL_CONFIG_DIR/.first-run-complete"
            rm -f "$DMOL_CONFIG_DIR/.crash-flag"
            show_success "Settings reset. Restarting..."
            sleep 1
            exec "$SCRIPT_DIR/devils-minios.sh"
            ;;
        4)
            rm -f "$DMOL_CONFIG_DIR/.crash-flag"
            exit 0
            ;;
        *)
            show_error "Invalid choice"
            press_enter
            safe_mode_menu
            ;;
    esac
}

# --- First Run ---
first_run_check() {
    if [[ -f "$DMOL_CONFIG_DIR/.first-run-complete" ]]; then
        return
    fi

    clear_screen
    local term_width
    term_width=$(detect_terminal_width)

    # Step 1: Welcome
    echo -e "${C_GREEN}${C_BOLD}"
    if [[ "$term_width" -ge 60 ]]; then
        cat << 'EOF'
  ___         _ _   _       __  __ _       _   ___  ____  
 |   \ ___ __| | | | |     |  \/  (_)_____| | / _ \/ ___| 
 | |) / -_) _` | |_| |     | |\/| | |_  /_  || (_) \___ \ 
 |___/\___\__,_|\___/      |_|  |_|_|/__/ |_| \___/|____/ 

EOF
    else
        echo "  DEVIL'S MINI OS"
    fi
    echo -e "${C_RESET}"

    echo -e "${C_CYAN}${C_BOLD}Welcome to Devil's Mini OS Launcher!${C_RESET}"
    echo ""
    echo "A mini OS for Termux — proot distros, desktops, universal"
    echo "package manager, all in pure bash."
    echo ""
    echo -e "${C_DIM}Repository: $DMOL_REPO${C_RESET}"
    echo ""
    press_enter

    # Step 1.5: Termux Source Check
    if [[ "$(detect_platform)" == "termux" ]]; then
        local source
        source=$(detect_termux_source)
        if [[ "$source" == "play-store" ]]; then
            clear_screen
            echo -e "${C_RED}${C_BOLD}╔════════════════════════════════════════════════════════════╗${C_RESET}"
            echo -e "${C_RED}${C_BOLD}║  ⚠️  PLAY STORE TERMUX DETECTED                         ║${C_RESET}"
            echo -e "${C_RED}${C_BOLD}║                                                            ║${C_RESET}"
            echo -e "${C_RED}${C_BOLD}║  This version is deprecated and lacks full functionality.  ║${C_RESET}"
            echo -e "${C_RED}${C_BOLD}║  Install from F-Droid or GitHub for the best experience.  ║${C_RESET}"
            echo -e "${C_RED}${C_BOLD}║  https://f-droid.org/packages/com.termux/                  ║${C_RESET}"
            echo -e "${C_RED}${C_BOLD}╚════════════════════════════════════════════════════════════╝${C_RESET}"
            echo ""
            read -rp "Continue anyway? [y/N] " response
            if [[ ! "$response" =~ ^[Yy]$ ]]; then
                exit 1
            fi
            press_enter
        fi

        # Step 1.6: termux-exec recommendation
        if ! command -v termux-exec >/dev/null 2>&1; then
            if [[ ! -f "$DMOL_CONFIG_DIR/.termux-exec-recommended" ]]; then
                clear_screen
                echo -e "${C_CYAN}💡 Tip: Install 'termux-exec' for better script compatibility:${C_RESET}"
                echo ""
                echo "    pkg install termux-exec"
                echo "    Then restart Termux."
                echo ""
                touch "$DMOL_CONFIG_DIR/.termux-exec-recommended"
                press_enter
            fi
        fi
    fi

    # Step 2: Proot Reality Check
    clear_screen
    echo -e "${C_YELLOW}${C_BOLD}⚠️  PROOT LIMITATIONS (Please Read)${C_RESET}"
    echo ""
    echo "Proot (the technology that runs Linux distros in Termux)"
    echo "has some fundamental limitations:"
    echo ""
    echo "  • No systemd/OpenRC — background services won't work"
    echo "  • No real root — sudo fails, mount fails, iptables fails"
    echo "  • Slower than native — ptrace overhead on every syscall"
    echo "  • No nested proot — can't run proot inside proot"
    echo "  • No FUSE, custom cgroups, or kernel modules"
    echo "  • Some apps (Docker, VMs, VPN kernel modules) are IMPOSSIBLE"
    echo ""
    echo -e "${C_DIM}These are hardware/Android limitations, not bugs in this launcher.${C_RESET}"
    echo ""
    press_enter

    # Step 3: Theme picker
    clear_screen
    echo -e "${C_CYAN}${C_BOLD}🎨 Choose a Color Theme${C_RESET}"
    echo ""
    echo "  1) Dracula (default) — Dark purple"
    echo "  2) Monokai — Dark with vibrant colors"
    echo "  3) Solarized Dark — Low contrast, eye-friendly"
    echo "  4) Nord — Arctic blue, modern"
    echo "  5) Gruvbox — Retro, distinctive"
    echo "  0) Skip (use default)"
    echo ""
    local theme_choice
    read -rp "Enter choice: " theme_choice
    theme_choice=$(sanitize_input "$theme_choice")
    case "$theme_choice" in
        1) set_setting "theme" "dracula" ;;
        2) set_setting "theme" "monokai" ;;
        3) set_setting "theme" "solarized-dark" ;;
        4) set_setting "theme" "nord" ;;
        5) set_setting "theme" "gruvbox" ;;
        *) set_setting "theme" "dracula" ;;
    esac
    apply_theme

    # Step 4: Banner picker
    clear_screen
    echo -e "${C_CYAN}${C_BOLD}🎭 Choose a Banner${C_RESET}"
    echo ""
    echo "  1) Devil (default) — Flames and horns"
    echo "  2) Minimal — Clean block letters"
    echo "  3) Retro — Old-school computer vibe"
    echo "  4) Cyber — Matrix/glitch style"
    echo "  5) Simple — Text in a box"
    echo "  0) Skip (use default)"
    echo ""
    local banner_choice
    read -rp "Enter choice: " banner_choice
    banner_choice=$(sanitize_input "$banner_choice")
    case "$banner_choice" in
        1) set_setting "banner" "devil" ;;
        2) set_setting "banner" "minimal" ;;
        3) set_setting "banner" "retro" ;;
        4) set_setting "banner" "cyber" ;;
        5) set_setting "banner" "simple" ;;
        *) set_setting "banner" "devil" ;;
    esac

    # Step 5: Quick setup
    clear_screen
    echo -e "${C_CYAN}${C_BOLD}⚡ Quick Setup${C_RESET}"
    echo ""
    echo "Recommended packages for full functionality:"
    echo ""

    if [[ "$(detect_platform)" == "termux" ]]; then
        echo "  • proot-distro (install Linux distros)"
        echo "  • termux-api (battery, clipboard, torch, etc.)"
        echo "  • git, wget, curl (basic tools)"
        echo ""
        read -rp "Install recommended packages now? [Y/n] " setup_choice
        if [[ ! "$setup_choice" =~ ^[Nn]$ ]]; then
            echo ""
            echo -e "${C_BLUE}Installing proot-distro...${C_RESET}"
            pkg install -y proot-distro 2>/dev/null && show_success "proot-distro installed" || show_warning "proot-distro install failed"

            echo -e "${C_BLUE}Installing git, wget, curl...${C_RESET}"
            pkg install -y git wget curl 2>/dev/null && show_success "Basic tools installed" || show_warning "Some tools failed to install"

            if has_termux_api; then
                show_success "termux-api is already available"
            else
                echo ""
                echo -e "${C_YELLOW}⚠️  termux-api requires a separate APK install.${C_RESET}"
                echo "Install Termux:API from the SAME source as Termux:"
                if [[ "$(detect_termux_source)" == "f-droid" ]]; then
                    echo "  https://f-droid.org/packages/com.termux.api/"
                else
                    echo "  https://github.com/termux/termux-api/releases"
                fi
            fi
        fi
    else
        echo "  • git, wget, curl (basic tools)"
        echo ""
        read -rp "Install recommended packages now? [Y/n] " setup_choice
        if [[ ! "$setup_choice" =~ ^[Nn]$ ]]; then
            if command -v apt >/dev/null 2>&1; then
                sudo apt install -y git wget curl 2>/dev/null || show_warning "Some tools failed"
            elif command -v dnf >/dev/null 2>&1; then
                sudo dnf install -y git wget curl 2>/dev/null || show_warning "Some tools failed"
            elif command -v pacman >/dev/null 2>&1; then
                sudo pacman -S --noconfirm git wget curl 2>/dev/null || show_warning "Some tools failed"
            fi
        fi
    fi

    # Mark first run complete
    touch "$DMOL_CONFIG_DIR/.first-run-complete"
    set_setting "termux_source" "$(detect_termux_source)"
    set_setting "android_version" "$(detect_android_version)"
    set_setting "architecture" "$(detect_architecture)"
    set_setting "terminal_width" "$(detect_terminal_width)"

    show_success "Setup complete! Welcome to Devil's Mini OS."
    press_enter
}

# --- Theme Application ---
apply_theme() {
    local theme_name
    theme_name=$(get_setting theme)
    local theme_file="$SCRIPT_DIR/data/themes/${theme_name}.properties"
    local ansi_file="$SCRIPT_DIR/data/themes/${theme_name}.bash"

    if [[ "$(detect_platform)" == "termux" && -f "$theme_file" ]]; then
        # Termux native: write colors.properties
        mkdir -p "$HOME/.termux"
        cp "$theme_file" "$HOME/.termux/colors.properties"
        if command -v termux-reload-settings >/dev/null 2>&1; then
            termux-reload-settings 2>/dev/null || true
        fi
    fi

    # Always load ANSI variables for current session
    if [[ -f "$ansi_file" ]]; then
        source "$ansi_file"

        # Linux: persist in shell rc
        if [[ "$(detect_platform)" == "linux" ]]; then
            local rc_file="$HOME/.bashrc"
            [[ -f "$HOME/.zshrc" ]] && rc_file="$HOME/.zshrc"

            # Remove old theme exports
            sed -i '/# Devil.s Mini OS Theme/d' "$rc_file" 2>/dev/null || true
            sed -i '/^export DMOL_/d' "$rc_file" 2>/dev/null || true

            # Add new theme exports
            {
                echo "# Devil's Mini OS Theme"
                grep '^export DMOL_' "$ansi_file" 2>/dev/null || true
            } >> "$rc_file"
        fi
    fi
}

# --- Main Menu ---
show_main_menu() {
    draw_header
    show_banner

    local term_width
    term_width=$(detect_terminal_width)

    # Platform warnings
    if [[ "$(detect_platform)" == "termux" && "$(detect_termux_source)" == "play-store" ]]; then
        echo -e "${C_YELLOW}⚠️  Play Store Termux detected. Some features limited.${C_RESET}"
        echo ""
    fi

    if [[ "$term_width" -lt 40 ]]; then
        # Minimal mode
        echo "1 Linux  2 Files  3 TermuxApps"
        echo "4 Proot  5 Desk   6 Nix"
        echo "7 Android 8 Work  9 Doctor"
        echo "10 Logs  11 Theme 12 Tools"
        echo "13 Info  14 Upd  15 Plugin"
        echo "16 Recent 0 Exit"
        return
    fi

    if [[ "$term_width" -lt 60 ]]; then
        # Compact mode
        echo -e "${C_BOLD}------------------------${C_RESET}"
        echo " 1) Linux Environments"
        echo " 2) File Manager"
        echo " 3) Termux App Store"
        echo " 4) Proot App Store"
        echo " 5) Desktop Environments"
        echo " 6) Nix Packages"
        echo " 7) Android Tools"
        echo " 8) Workspace Templates"
        echo " 9) System Doctor"
        echo "10) Log Viewer"
        echo "11) Customize"
        echo "12) System Tools"
        echo "13) System Info"
        echo "14) Update All"
        echo "15) Plugin Manager"
        echo "16) Recent Actions"
        echo ""
        echo " 0) Exit"
        echo -e "${C_BOLD}------------------------${C_RESET}"
        return
    fi

    # Full mode
    echo -e "${C_BOLD}╔════════════════════════════════════════════════════════════╗${C_RESET}"
    echo -e "${C_BOLD}║  1) 🐧  Linux Environments                                 ║${C_RESET}"
    echo -e "${C_BOLD}║  2) 📁  File Manager                                       ║${C_RESET}"
    echo -e "${C_BOLD}║  3) 📦  Termux App Store (Native)                          ║${C_RESET}"
    echo -e "${C_BOLD}║  4) 🐧  Proot App Store (40 apps)                          ║${C_RESET}"
    echo -e "${C_BOLD}║  5) 🖥️  Desktop Environments                               ║${C_RESET}"
    echo -e "${C_BOLD}║  6) ❄️  Nix Packages                                       ║${C_RESET}"
    echo -e "${C_BOLD}║  7) 📱  Android Tools                                      ║${C_RESET}"
    echo -e "${C_BOLD}║  8) 🛠️  Workspace Templates                                ║${C_RESET}"
    echo -e "${C_BOLD}║  9) 🏥  System Doctor                                      ║${C_RESET}"
    echo -e "${C_BOLD}║  10) 📜  Log Viewer                                        ║${C_RESET}"
    echo -e "${C_BOLD}║  11) 🎨  Customize                                         ║${C_RESET}"
    echo -e "${C_BOLD}║  12) ⚡  System Tools                                      ║${C_RESET}"
    echo -e "${C_BOLD}║  13) ℹ️  System Info                                       ║${C_RESET}"
    echo -e "${C_BOLD}║  14) 🔄  Update All                                        ║${C_RESET}"
    echo -e "${C_BOLD}║  15) 🔌  Plugin Manager                                    ║${C_RESET}"
    echo -e "${C_BOLD}║  16) 📋  Recent Actions                                    ║${C_RESET}"
    echo -e "${C_BOLD}║                                                            ║${C_RESET}"
    echo -e "${C_BOLD}║  0) 🚪  Exit                                               ║${C_RESET}"
    echo -e "${C_BOLD}╚════════════════════════════════════════════════════════════╝${C_RESET}"
}

# --- Plugin Security ---
PLUGIN_ALLOWED_COMMANDS=(
    "pkg" "apt" "apt-get" "pacman" "dnf" "zypper" "xbps-install" "emerge"
    "proot-distro" "git" "wget" "curl" "tar" "unzip"
    "cp" "mv" "rm" "mkdir" "chmod" "chown" "ln"
    "echo" "cat" "grep" "sed" "awk" "head" "tail" "find"
    "bash" "sh" "source" "exit" "return" "cd" "pwd"
    "termux-" "am" "pm" "screencap" "logcat" "adb" "fastboot"
    "ps" "kill" "pkill" "pgrep" "nohup" "disown"
    "df" "du" "free" "uname" "date" "clear" "tput"
    "touch" "test" "[[" "[" "true" "false" "printf"
)

validate_plugin_commands() {
    local plugin_file="$1"
    local line cmd
    local failed=0

    while IFS= read -r line; do
        # Skip empty lines and comments
        [[ -z "$line" ]] && continue
        local trimmed="${line#"${line%%[![:space:]]*}"}"
        [[ "$trimmed" =~ ^# ]] && continue

        # Extract first word (command)
        cmd=$(echo "$line" | awk '{print $1}')
        [[ -z "$cmd" ]] && continue

        # Skip bash builtins and conditionals
        [[ "$cmd" == "if" || "$cmd" == "then" || "$cmd" == "else" || "$cmd" == "elif" || "$cmd" == "fi" || "$cmd" == "for" || "$cmd" == "while" || "$cmd" == "do" || "$cmd" == "done" || "$cmd" == "case" || "$cmd" == "esac" || "$cmd" == "function" || "$cmd" == "local" || "$cmd" == "declare" || "$cmd" == "readonly" || "$cmd" == "export" ]] && continue

        local allowed=false
        for prefix in "${PLUGIN_ALLOWED_COMMANDS[@]}"; do
            if [[ "$cmd" == "$prefix" || "$cmd" == "$prefix"* ]]; then
                allowed=true
                break
            fi
        done

        if [[ "$allowed" == false ]]; then
            log_warn "Plugin validation failed: disallowed command '$cmd'"
            failed=1
        fi
    done < <(grep -v '^[[:space:]]*$' "$plugin_file")

    return "$failed"
}

run_plugin() {
    local plugin_file="$1"
    local prefix="${PREFIX:-/usr}"

    # Subshell with restricted PATH
    (
        PATH="$prefix/bin:/system/bin:/bin:/usr/bin:/usr/local/bin"
        export PATH
        # Restricted environment
        unset LD_PRELOAD
        bash "$plugin_file"
    )
}

# --- System Initialization ---
init_system() {
    init_colors
    init_paths

    log_info "Devil's Mini OS Launcher $DMOL_VERSION started"
    log_info "Platform: $(detect_platform), Arch: $(detect_architecture), Termux source: $(detect_termux_source)"

    # Apply theme if set
    if [[ -f "$DMOL_CONFIG_DIR/user.conf" ]]; then
        apply_theme
    fi

    # Update stored platform info
    set_setting "termux_source" "$(detect_termux_source)" 2>/dev/null || true
    set_setting "android_version" "$(detect_android_version)" 2>/dev/null || true
    set_setting "architecture" "$(detect_architecture)" 2>/dev/null || true
    set_setting "terminal_width" "$(detect_terminal_width)" 2>/dev/null || true
}

# --- Export all functions ---
export -f init_colors init_paths detect_platform detect_termux_source
export -f detect_android_version detect_architecture detect_termux_api
export -f has_termux_api is_proot is_exec_safe detect_terminal_width
export -f get_config_dir get_cache_dir check_battery_before_heavy_op
export -f log_write log_info log_warn log_error log_debug log_recent
export -f sanitize_input validate_number clear_screen draw_header
export -f show_banner press_enter show_error show_success show_info show_warning
export -f get_setting set_setting safe_mode_menu first_run_check
export -f apply_theme show_main_menu validate_plugin_commands run_plugin
export -f init_system rotate_logs
