#!/usr/bin/env bash
# =============================================================================
# Devil's Mini OS Launcher - termux_apps.sh
# Version: v1.1.0
# Purpose: Native Termux app installation with source awareness
# =============================================================================

# --- App Database (Native Termux) ---
declare -A TERMUX_APPS=(
    ["git"]="git:Version control:5MB:dev:pkg install -y git:all"
    ["neovim"]="neovim:Modern Vim editor:15MB:dev:pkg install -y neovim:all"
    ["nodejs"]="Node.js:JavaScript runtime:50MB:dev:pkg install -y nodejs:all"
    ["python"]="Python:Python 3 interpreter:25MB:dev:pkg install -y python:all"
    ["rust"]="Rust:Rust programming language:200MB:dev:pkg install -y rust:all"
    ["golang"]="Go:Go programming language:150MB:dev:pkg install -y golang:all"
    ["ruby"]="Ruby:Ruby programming language:30MB:dev:pkg install -y ruby:all"
    ["code-server"]="VS Code Server:Browser-based VS Code:100MB:dev:pkg install -y code-server:all"
    ["firefox"]="Firefox:Web browser:80MB:browser:pkg install -y firefox:all"
    ["chromium"]="Chromium:Open-source browser:120MB:browser:pkg install -y chromium:all"
    ["lynx"]="Lynx:Text-based browser:2MB:browser:pkg install -y lynx:all"
    ["w3m"]="w3m:Text-based browser:3MB:browser:pkg install -y w3m:all"
    ["xfce4"]="XFCE4:Lightweight desktop:80MB:desktop:pkg install -y xfce4:all"
    ["lxqt"]="LXQt:Lightweight Qt desktop:60MB:desktop:pkg install -y lxqt:all"
    ["tigervnc"]="TigerVNC:VNC server:15MB:desktop:pkg install -y tigervnc:all"
    ["htop"]="htop:Interactive process viewer:2MB:cli:pkg install -y htop:all"
    ["tmux"]="tmux:Terminal multiplexer:5MB:cli:pkg install -y tmux:all"
    ["ranger"]="ranger:TUI file manager:5MB:cli:pkg install -y ranger:all"
    ["fzf"]="fzf:Fuzzy finder:3MB:cli:pkg install -y fzf:all"
    ["ripgrep"]="ripgrep:Fast grep alternative:3MB:cli:pkg install -y ripgrep:all"
    ["bat"]="bat:Syntax-highlighting cat:5MB:cli:pkg install -y bat:all"
    ["exa"]="exa:Modern ls replacement:3MB:cli:pkg install -y exa:all"
    ["neofetch"]="neofetch:System info display:2MB:cli:pkg install -y neofetch:all"
    ["termux-x11"]="Termux:X11:X11 server:20MB:system:pkg install -y termux-x11-nightly:all"
    ["pulseaudio"]="PulseAudio:Sound server:10MB:system:pkg install -y pulseaudio:all"
    ["termux-api"]="Termux:API:API client:5MB:system:pkg install -y termux-api:all"
    ["proot-distro"]="proot-distro:Linux distro installer:5MB:system:pkg install -y proot-distro:all"
    ["nmap"]="nmap:Network scanner:15MB:security:pkg install -y nmap:all"
    ["openssl"]="OpenSSL:SSL/TLS toolkit:10MB:security:pkg install -y openssl:all"
    ["gnupg"]="GnuPG:Encryption tools:10MB:security:pkg install -y gnupg:all"
    ["hashcat"]="hashcat:Password cracker:50MB:security:pkg install -y hashcat:all"
    ["hydra"]="Hydra:Password brute-forcer:20MB:security:pkg install -y hydra:all"
    ["mpv"]="mpv:Media player:30MB:media:pkg install -y mpv:all"
    ["ffmpeg"]="FFmpeg:Media converter:50MB:media:pkg install -y ffmpeg:all"
    ["imagemagick"]="ImageMagick:Image processor:20MB:media:pkg install -y imagemagick:all"
    ["cmus"]="cmus:Music player:10MB:media:pkg install -y cmus:all"
    ["nethack"]="NetHack:Classic roguelike:5MB:game:pkg install -y nethack:all"
    ["crawl"]="Dungeon Crawl:Roguelike:15MB:game:pkg install -y crawl:all"
    ["zangband"]="Zangband:Roguelike:5MB:game:pkg install -y zangband:all"
    ["bastet"]="Bastet:Tetris clone:2MB:game:pkg install -y bastet:all"
)

# Categories
declare -a TERMUX_CATEGORIES=(
    "Development"
    "Browsers"
    "Desktop Environments"
    "CLI Tools"
    "System"
    "Security"
    "Media"
    "Networking"
    "Games"
)

# Category mapping
category_map() {
    case "$1" in
        "Development") echo "dev" ;;
        "Browsers") echo "browser" ;;
        "Desktop Environments") echo "desktop" ;;
        "CLI Tools") echo "cli" ;;
        "System") echo "system" ;;
        "Security") echo "security" ;;
        "Media") echo "media" ;;
        "Networking") echo "network" ;;
        "Games") echo "game" ;;
        *) echo "$1" ;;
    esac
}

termux_apps_menu() {
    while true; do
        draw_header
        echo -e "${C_CYAN}${C_BOLD}📦 Termux App Store (Native)${C_RESET}"
        echo ""

        # Source warning
        if [[ "$(detect_platform)" == "termux" && "$(detect_termux_source)" == "play-store" ]]; then
            echo -e "${C_YELLOW}⚠️  Play Store Termux — package availability limited${C_RESET}"
            echo ""
        fi

        echo "Categories:"
        local i=1
        for cat in "${TERMUX_CATEGORIES[@]}"; do
            echo "  $i) $cat"
            ((i++))
        done
        echo ""
        echo "  a) Show all apps"
        echo "  s) Search apps"
        echo "  0) Back to Main Menu"
        echo ""

        read -rp "Enter choice: " choice
        choice=$(sanitize_input "$choice")

        case "$choice" in
            [1-9])
                if validate_number "$choice" 1 9; then
                    show_category_apps "${TERMUX_CATEGORIES[$((choice-1))]}"
                fi
                ;;
            a|A) show_all_apps ;;
            s|S) search_termux_apps ;;
            0) return ;;
            *) show_error "Invalid choice"; press_enter ;;
        esac
    done
}

show_category_apps() {
    local category="$1"
    local cat_code
    cat_code=$(category_map "$category")

    while true; do
        draw_header
        echo -e "${C_CYAN}${C_BOLD}📦 $category${C_RESET}"
        echo ""

        local apps=()
        local keys=()
        for key in "${!TERMUX_APPS[@]}"; do
            local data="${TERMUX_APPS[$key]}"
            local app_cat
            app_cat=$(echo "$data" | cut -d: -f4)
            if [[ "$app_cat" == "$cat_code" ]]; then
                apps+=("$data")
                keys+=("$key")
            fi
        done

        if [[ ${#apps[@]} -eq 0 ]]; then
            echo -e "${C_DIM}No apps in this category${C_RESET}"
            press_enter
            return
        fi

        local i=1
        for app in "${apps[@]}"; do
            local name desc size
            name=$(echo "$app" | cut -d: -f1)
            desc=$(echo "$app" | cut -d: -f2)
            size=$(echo "$app" | cut -d: -f3)

            # Check if installed
            local installed=" "
            if command -v "$name" >/dev/null 2>&1 || [[ -d "$PREFIX/share/$name" ]] || [[ -f "$PREFIX/bin/$name" ]]; then
                installed="✓"
            fi

            printf "  %2d) [%s] %-20s %s (%s)\n" "$i" "$installed" "$name" "$desc" "$size"
            ((i++))
        done

        echo ""
        echo "Enter numbers to install (space-separated, e.g., '1 3 5')"
        echo "  0) Back"
        echo ""

        read -rp "Select: " selections
        selections=$(sanitize_input "$selections")

        if [[ "$selections" == "0" ]]; then
            return
        fi

        # Parse selections
        local selected_keys=()
        for num in $selections; do
            if validate_number "$num" 1 "${#apps[@]}"; then
                selected_keys+=("${keys[$((num-1))]}")
            fi
        done

        if [[ ${#selected_keys[@]} -gt 0 ]]; then
            install_termux_apps "${selected_keys[@]}"
        fi
    done
}

show_all_apps() {
    while true; do
        draw_header
        echo -e "${C_CYAN}${C_BOLD}📦 All Termux Apps${C_RESET}"
        echo ""

        local keys=()
        for key in "${!TERMUX_APPS[@]}"; do
            keys+=("$key")
        done

        # Sort keys
        IFS=$'\n' sorted_keys=($(sort <<<"${keys[*]}")); unset IFS

        local i=1
        for key in "${sorted_keys[@]}"; do
            local data="${TERMUX_APPS[$key]}"
            local name desc size
            name=$(echo "$data" | cut -d: -f1)
            desc=$(echo "$data" | cut -d: -f2)
            size=$(echo "$data" | cut -d: -f3)

            local installed=" "
            if command -v "$name" >/dev/null 2>&1 || [[ -d "$PREFIX/share/$name" ]] || [[ -f "$PREFIX/bin/$name" ]]; then
                installed="✓"
            fi

            printf "  %2d) [%s] %-20s %s (%s)\n" "$i" "$installed" "$name" "$desc" "$size"
            ((i++))
        done

        echo ""
        echo "Enter numbers to install (space-separated)"
        echo "  0) Back"
        echo ""

        read -rp "Select: " selections
        selections=$(sanitize_input "$selections")

        if [[ "$selections" == "0" ]]; then
            return
        fi

        local selected_keys=()
        for num in $selections; do
            if validate_number "$num" 1 "${#sorted_keys[@]}"; then
                selected_keys+=("${sorted_keys[$((num-1))]}")
            fi
        done

        if [[ ${#selected_keys[@]} -gt 0 ]]; then
            install_termux_apps "${selected_keys[@]}"
        fi
    done
}

search_termux_apps() {
    echo ""
    read -rp "Search: " query
    query=$(sanitize_input "$query")

    if [[ -z "$query" ]]; then
        show_error "Search query cannot be empty"
        press_enter
        return
    fi

    draw_header
    echo -e "${C_CYAN}${C_BOLD}🔍 Search Results: '$query'${C_RESET}"
    echo ""

    local found=false
    local i=1
    local keys=()
    local matched=()

    for key in "${!TERMUX_APPS[@]}"; do
        local data="${TERMUX_APPS[$key]}"
        local name desc
        name=$(echo "$data" | cut -d: -f1)
        desc=$(echo "$data" | cut -d: -f2)

        if [[ "$name" == *"$query"* || "$desc" == *"$query"* || "$key" == *"$query"* ]]; then
            keys+=("$key")
            matched+=("$data")
            printf "  %2d) %-20s %s\n" "$i" "$name" "$desc"
            ((i++))
            found=true
        fi
    done

    if [[ "$found" == false ]]; then
        echo -e "${C_DIM}No results found${C_RESET}"
        press_enter
        return
    fi

    echo ""
    echo "Enter numbers to install (space-separated)"
    echo "  0) Back"
    echo ""

    read -rp "Select: " selections
    selections=$(sanitize_input "$selections")

    if [[ "$selections" == "0" ]]; then
        return
    fi

    local selected_keys=()
    for num in $selections; do
        if validate_number "$num" 1 "${#matched[@]}"; then
            selected_keys+=("${keys[$((num-1))]}")
        fi
    done

    if [[ ${#selected_keys[@]} -gt 0 ]]; then
        install_termux_apps "${selected_keys[@]}"
    fi
}

install_termux_apps() {
    local keys=("$@")

    if [[ ${#keys[@]} -eq 0 ]]; then
        return
    fi

    echo ""
    echo -e "${C_BLUE}Installing ${#keys[@]} app(s)...${C_RESET}"
    echo ""

    # Check if pkg is available
    if ! command -v pkg >/dev/null 2>&1; then
        show_error "pkg command not found. Are you in Termux?"
        press_enter
        return
    fi

    # Update package list first
    echo -e "${C_DIM}Updating package list...${C_RESET}"
    pkg update -y 2>&1 | tail -5 || true
    echo ""

    local failed=()
    local success=()

    for key in "${keys[@]}"; do
        local data="${TERMUX_APPS[$key]}"
        local name cmd
        name=$(echo "$data" | cut -d: -f1)
        cmd=$(echo "$data" | cut -d: -f5)

        echo -e "${C_CYAN}Installing $name...${C_RESET}"

        if eval "$cmd" 2>&1; then
            echo -e "${C_GREEN}  ✓ $name installed${C_RESET}"
            success+=("$name")
            log_recent "INSTALL_TERMUX_APP" "$name"
        else
            echo -e "${C_RED}  ✗ $name failed${C_RESET}"
            failed+=("$name")
            log_warn "Failed to install Termux app: $name"
        fi
        echo ""
    done

    echo ""
    if [[ ${#success[@]} -gt 0 ]]; then
        show_success "Installed: ${success[*]}"
    fi
    if [[ ${#failed[@]} -gt 0 ]]; then
        show_error "Failed: ${failed[*]}"
    fi

    press_enter
}
