#!/usr/bin/env bash
# =============================================================================
# Devil's Mini OS Launcher - customize.sh
# Version: v1.1.0
# Purpose: Appearance customization with dual-mode themes
# =============================================================================

customize_menu() {
    while true; do
        draw_header
        echo -e "${C_CYAN}${C_BOLD}🎨 Customize${C_RESET}"
        echo ""
        echo "  1) Color Themes"
        echo "  2) Banner"
        echo "  3) Create Custom Banner"
        echo "  0) Back to Main Menu"
        echo ""

        read -rp "Enter choice: " choice
        choice=$(sanitize_input "$choice")

        case "$choice" in
            1) theme_menu ;;
            2) banner_menu ;;
            3) create_custom_banner ;;
            0) return ;;
            *) show_error "Invalid choice"; press_enter ;;
        esac
    done
}

theme_menu() {
    while true; do
        draw_header
        echo -e "${C_CYAN}${C_BOLD}🎨 Color Themes${C_RESET}"
        echo ""
        echo "  1) Dracula (default)"
        echo "  2) Monokai"
        echo "  3) Solarized Dark"
        echo "  4) Nord"
        echo "  5) Gruvbox"
        echo "  0) Back"
        echo ""

        read -rp "Select theme: " choice
        choice=$(sanitize_input "$choice")

        case "$choice" in
            1) set_setting "theme" "dracula"; apply_theme; show_success "Dracula theme applied"; press_enter; return ;;
            2) set_setting "theme" "monokai"; apply_theme; show_success "Monokai theme applied"; press_enter; return ;;
            3) set_setting "theme" "solarized-dark"; apply_theme; show_success "Solarized Dark theme applied"; press_enter; return ;;
            4) set_setting "theme" "nord"; apply_theme; show_success "Nord theme applied"; press_enter; return ;;
            5) set_setting "theme" "gruvbox"; apply_theme; show_success "Gruvbox theme applied"; press_enter; return ;;
            0) return ;;
            *) show_error "Invalid choice"; press_enter ;;
        esac
    done
}

banner_menu() {
    while true; do
        draw_header
        echo -e "${C_CYAN}${C_BOLD}🎭 Banner${C_RESET}"
        echo ""
        echo "  1) Devil (default)"
        echo "  2) Minimal"
        echo "  3) Retro"
        echo "  4) Cyber"
        echo "  5) Simple"
        echo "  0) Back"
        echo ""

        read -rp "Select banner: " choice
        choice=$(sanitize_input "$choice")

        case "$choice" in
            1) set_setting "banner" "devil"; show_success "Devil banner set"; press_enter; return ;;
            2) set_setting "banner" "minimal"; show_success "Minimal banner set"; press_enter; return ;;
            3) set_setting "banner" "retro"; show_success "Retro banner set"; press_enter; return ;;
            4) set_setting "banner" "cyber"; show_success "Cyber banner set"; press_enter; return ;;
            5) set_setting "banner" "simple"; show_success "Simple banner set"; press_enter; return ;;
            0) return ;;
            *) show_error "Invalid choice"; press_enter ;;
        esac
    done
}

create_custom_banner() {
    draw_header
    echo -e "${C_CYAN}${C_BOLD}📝 Create Custom Banner${C_RESET}"
    echo ""
    echo "Paste your ASCII art below (max 20 lines, 60 chars wide):"
    echo "Press Ctrl+D when done:"
    echo ""

    local custom_file="$DMOL_CONFIG_DIR/custom-banner.txt"
    > "$custom_file"

    local line_count=0
    while IFS= read -r line && [[ $line_count -lt 20 ]]; do
        echo "$line" >> "$custom_file"
        ((line_count++))
    done

    if [[ -s "$custom_file" ]]; then
        set_setting "banner" "custom"
        cp "$custom_file" "$SCRIPT_DIR/data/banners/custom.txt"
        show_success "Custom banner created!"
    else
        show_error "No content provided"
    fi
    press_enter
}
