#!/usr/bin/env bash
# =============================================================================
# Devil's Mini OS Launcher - health_check.sh
# Version: v1.1.0
# Purpose: System Doctor with proot awareness and wake-lock integration
# =============================================================================

HEALTH_INTERVAL="${HEALTH_INTERVAL:-1800}"

health_check_menu() {
    while true; do
        draw_header
        echo -e "${C_CYAN}${C_BOLD}🏥 System Doctor${C_RESET}"
        echo ""
        echo "  1) Run Health Check Now"
        echo "  2) Start Health Daemon"
        echo "  3) Stop Health Daemon"
        echo "  4) Daemon Status"
        echo "  5) View Health History"
        echo "  0) Back to Main Menu"
        echo ""

        read -rp "Enter choice: " choice
        choice=$(sanitize_input "$choice")

        case "$choice" in
            1) run_health_check; press_enter ;;
            2) start_health_daemon; press_enter ;;
            3) stop_health_daemon; press_enter ;;
            4) daemon_status; press_enter ;;
            5) view_health_history; press_enter ;;
            0) return ;;
            *) show_error "Invalid choice"; press_enter ;;
        esac
    done
}

run_health_check() {
    draw_header
    echo -e "${C_CYAN}${C_BOLD}🔍 Health Check${C_RESET}"
    echo ""

    local issues=0
    local warnings=0

    # Disk usage
    echo -e "${C_BLUE}Disk Usage:${C_RESET}"
    df -h "$HOME" 2>/dev/null | awk 'NR==2 {printf "  %s used of %s (%s free)\n", $3, $2, $4}'
    local disk_pct
    disk_pct=$(df "$HOME" 2>/dev/null | awk 'NR==2 {gsub(/%/,""); print $5}')
    if [[ -n "$disk_pct" && "$disk_pct" -gt 90 ]]; then
        echo -e "  ${C_RED}⚠️  CRITICAL: Disk usage > 90%${C_RESET}"
        ((issues++))
    elif [[ -n "$disk_pct" && "$disk_pct" -gt 80 ]]; then
        echo -e "  ${C_YELLOW}⚠️  WARNING: Disk usage > 80%${C_RESET}"
        ((warnings++))
    fi
    echo ""

    # Memory
    echo -e "${C_BLUE}Memory:${C_RESET}"
    if command -v free >/dev/null 2>&1; then
        free -h 2>/dev/null | awk 'NR==2 {printf "  Used: %s / %s\n", $3, $2}'
        local mem_pct
        mem_pct=$(free 2>/dev/null | awk 'NR==2 {printf "%.0f", $3/$2 * 100}')
        if [[ -n "$mem_pct" && "$mem_pct" -gt 85 ]]; then
            echo -e "  ${C_YELLOW}⚠️  WARNING: Memory usage > 85%${C_RESET}"
            ((warnings++))
        fi
    fi
    echo ""

    # Proot check
    echo -e "${C_BLUE}Proot Status:${C_RESET}"
    if command -v proot-distro >/dev/null 2>&1; then
        local pd_version
        pd_version=$(source "$SCRIPT_DIR/modules/linux_env.sh" && detect_proot_distro_version 2>/dev/null || echo "installed")
        echo -e "  ${C_GREEN}✓ proot-distro: $pd_version${C_RESET}"

        local distros=()
        while IFS= read -r d; do
            [[ -n "$d" ]] && distros+=("$d")
        done < <(source "$SCRIPT_DIR/modules/linux_env.sh" && list_installed_distros 2>/dev/null || true)

        if [[ ${#distros[@]} -gt 0 ]]; then
            echo -e "  ${C_GREEN}✓ Installed distros: ${#distros[@]}${C_RESET}"
        else
            echo -e "  ${C_YELLOW}⚠️  No distros installed${C_RESET}"
            ((warnings++))
        fi
    else
        echo -e "  ${C_YELLOW}⚠️  proot-distro not installed${C_RESET}"
        ((warnings++))
    fi
    echo ""

    # Termux source check
    if [[ "$(detect_platform)" == "termux" ]]; then
        echo -e "${C_BLUE}Termux Source:${C_RESET}"
        local source
        source=$(detect_termux_source)
        if [[ "$source" == "play-store" ]]; then
            echo -e "  ${C_RED}⚠️  Play Store Termux detected (deprecated)${C_RESET}"
            ((warnings++))
        elif [[ "$source" == "f-droid" || "$source" == "github" ]]; then
            echo -e "  ${C_GREEN}✓ $source (recommended)${C_RESET}"
        else
            echo -e "  ${C_YELLOW}? Unknown source${C_RESET}"
        fi
        echo ""
    fi

    # Android version
    if [[ "$(detect_platform)" == "termux" ]]; then
        echo -e "${C_BLUE}Android Version:${C_RESET}"
        local android_ver
        android_ver=$(detect_android_version)
        echo -e "  Android $android_ver"
        if [[ "$android_ver" -ge 10 ]]; then
            echo -e "  ${C_YELLOW}⚠️  External storage is noexec (Android 10+)${C_RESET}"
        fi
        if [[ "$android_ver" -ge 12 ]]; then
            echo -e "  ${C_YELLOW}⚠️  Background services may be killed (Android 12+)${C_RESET}"
        fi
        echo ""
    fi

    # Summary
    echo -e "${C_BOLD}=== Summary ===${C_RESET}"
    if [[ $issues -gt 0 ]]; then
        echo -e "${C_RED}❌ $issues critical issue(s) found${C_RESET}"
    elif [[ $warnings -gt 0 ]]; then
        echo -e "${C_YELLOW}⚠️  $warnings warning(s) found${C_RESET}"
    else
        echo -e "${C_GREEN}✅ System healthy${C_RESET}"
    fi

    # Save to history
    local timestamp
    timestamp=$(date '+%Y-%m-%d %H:%M:%S')
    echo "[$timestamp] Issues: $issues, Warnings: $warnings" >> "$DMOL_CONFIG_DIR/health.log"

    log_recent "HEALTH_CHECK" "Issues: $issues, Warnings: $warnings"
}

start_health_daemon() {
    local pid_file="$DMOL_CONFIG_DIR/pids/health_daemon.pid"

    if [[ -f "$pid_file" ]] && kill -0 "$(cat "$pid_file")" 2>/dev/null; then
        show_warning "Health daemon already running (PID: $(cat "$pid_file"))"
        return
    fi

    # Acquire wake lock if available (Termux only)
    if command -v termux-wake-lock >/dev/null 2>&1; then
        termux-wake-lock 2>/dev/null || true
        log_info "Health daemon: Acquired wake lock"
    fi

    # Start daemon
    (
        while true; do
            (
                source "$SCRIPT_DIR/modules/core.sh" 2>/dev/null || true
                run_health_check > /dev/null 2>&1
            )
            sleep "$HEALTH_INTERVAL"
        done
    ) & disown

    local pid=$!
    echo $pid > "$pid_file"

    show_success "Health daemon started (PID: $pid, interval: ${HEALTH_INTERVAL}s)"
    log_info "Health daemon started with PID $pid"

    # Android 12+ warning
    local android_ver
    android_ver=$(detect_android_version)
    if [[ "$android_ver" -ge 12 ]]; then
        show_warning "Android 12+ may kill background processes. Consider running 'termux-wake-lock' manually."
    fi
}

stop_health_daemon() {
    local pid_file="$DMOL_CONFIG_DIR/pids/health_daemon.pid"

    if [[ -f "$pid_file" ]]; then
        local pid
        pid=$(cat "$pid_file")
        if kill "$pid" 2>/dev/null; then
            rm -f "$pid_file"
            command -v termux-wake-unlock >/dev/null 2>&1 && termux-wake-unlock 2>/dev/null || true
            show_success "Health daemon stopped"
            log_info "Health daemon stopped"
        else
            rm -f "$pid_file"
            show_warning "Daemon was not running"
        fi
    else
        show_warning "No daemon PID file found"
    fi
}

daemon_status() {
    local pid_file="$DMOL_CONFIG_DIR/pids/health_daemon.pid"

    if [[ -f "$pid_file" ]]; then
        local pid
        pid=$(cat "$pid_file")
        if kill -0 "$pid" 2>/dev/null; then
            echo -e "${C_GREEN}✅ Health daemon running (PID: $pid)${C_RESET}"
            echo -e "${C_DIM}Interval: ${HEALTH_INTERVAL}s${C_RESET}"
        else
            echo -e "${C_RED}❌ Daemon PID file exists but process not running${C_RESET}"
        fi
    else
        echo -e "${C_YELLOW}⚠️  Health daemon not running${C_RESET}"
    fi
}

view_health_history() {
    draw_header
    echo -e "${C_CYAN}${C_BOLD}📜 Health Check History${C_RESET}"
    echo ""

    if [[ -f "$DMOL_CONFIG_DIR/health.log" ]]; then
        tail -n 20 "$DMOL_CONFIG_DIR/health.log"
    else
        echo -e "${C_DIM}No health history available${C_RESET}"
    fi

    echo ""
    press_enter
}
