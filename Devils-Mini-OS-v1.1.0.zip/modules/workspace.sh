#!/usr/bin/env bash
# =============================================================================
# Devil's Mini OS Launcher - workspace.sh
# Version: v1.1.0
# Purpose: Workspace/Project Templates with $HOME enforcement
# =============================================================================

WORKSPACE_DIR="$HOME/.config/devils-minios/templates"

workspace_menu() {
    while true; do
        draw_header
        echo -e "${C_CYAN}${C_BOLD}🛠️ Workspace Templates${C_RESET}"
        echo ""
        echo "  1) Create from Template"
        echo "  2) List Templates"
        echo "  3) Create Custom Template"
        echo "  4) Git Init Project"
        echo "  5) GitHub Repo (requires gh CLI)"
        echo "  0) Back to Main Menu"
        echo ""

        read -rp "Enter choice: " choice
        choice=$(sanitize_input "$choice")

        case "$choice" in
            1) create_from_template ;;
            2) list_templates ;;
            3) create_custom_template ;;
            4) git_init_project ;;
            5) github_repo ;;
            0) return ;;
            *) show_error "Invalid choice"; press_enter ;;
        esac
    done
}

init_workspace() {
    mkdir -p "$WORKSPACE_DIR"
    [[ -d "$WORKSPACE_DIR/python" ]] || create_python_template
    [[ -d "$WORKSPACE_DIR/nodejs" ]] || create_nodejs_template
    [[ -d "$WORKSPACE_DIR/web" ]] || create_web_template
    [[ -d "$WORKSPACE_DIR/cpp" ]] || create_cpp_template
    [[ -d "$WORKSPACE_DIR/bash" ]] || create_bash_template
}

create_python_template() {
    mkdir -p "$WORKSPACE_DIR/python"
    cat > "$WORKSPACE_DIR/python/main.py" << 'EOF'
#!/usr/bin/env python3
"""Main module."""

def main():
    """Entry point."""
    print("Hello from Devil's Mini OS!")

if __name__ == "__main__":
    main()
EOF
    cat > "$WORKSPACE_DIR/python/requirements.txt" << 'EOF'
# Add your dependencies here
EOF
    cat > "$WORKSPACE_DIR/python/.gitignore" << 'EOF'
__pycache__/
*.pyc
*.pyo
.env
venv/
EOF
}

create_nodejs_template() {
    mkdir -p "$WORKSPACE_DIR/nodejs"
    cat > "$WORKSPACE_DIR/nodejs/package.json" << 'EOF'
{
  "name": "my-project",
  "version": "1.0.0",
  "description": "Created with Devil's Mini OS",
  "main": "index.js",
  "scripts": {
    "start": "node index.js"
  }
}
EOF
    cat > "$WORKSPACE_DIR/nodejs/index.js" << 'EOF'
#!/usr/bin/env node
console.log("Hello from Devil's Mini OS!");
EOF
    cat > "$WORKSPACE_DIR/nodejs/.gitignore" << 'EOF'
node_modules/
.env
npm-debug.log*
EOF
}

create_web_template() {
    mkdir -p "$WORKSPACE_DIR/web"
    cat > "$WORKSPACE_DIR/web/index.html" << 'EOF'
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Devil's Mini OS Project</title>
    <style>
        body { font-family: sans-serif; max-width: 800px; margin: 0 auto; padding: 20px; }
    </style>
</head>
<body>
    <h1>Hello from Devil's Mini OS!</h1>
</body>
</html>
EOF
    cat > "$WORKSPACE_DIR/web/.gitignore" << 'EOF'
.DS_Store
EOF
}

create_cpp_template() {
    mkdir -p "$WORKSPACE_DIR/cpp"
    cat > "$WORKSPACE_DIR/cpp/main.cpp" << 'EOF'
#include <iostream>

int main() {
    std::cout << "Hello from Devil's Mini OS!" << std::endl;
    return 0;
}
EOF
    cat > "$WORKSPACE_DIR/cpp/Makefile" << 'EOF'
CXX = g++
CXXFLAGS = -Wall -std=c++17

all: main

main: main.cpp
	$(CXX) $(CXXFLAGS) -o main main.cpp

clean:
	rm -f main

.PHONY: all clean
EOF
    cat > "$WORKSPACE_DIR/cpp/.gitignore" << 'EOF'
*.o
main
EOF
}

create_bash_template() {
    mkdir -p "$WORKSPACE_DIR/bash"
    cat > "$WORKSPACE_DIR/bash/script.sh" << 'EOF'
#!/usr/bin/env bash
# =============================================================================
# Script created with Devil's Mini OS
# =============================================================================
set -euo pipefail

echo "Hello from Devil's Mini OS!"
EOF
    chmod +x "$WORKSPACE_DIR/bash/script.sh"
    cat > "$WORKSPACE_DIR/bash/.gitignore" << 'EOF'
*.log
EOF
}

create_from_template() {
    draw_header
    echo -e "${C_CYAN}${C_BOLD}📁 Create from Template${C_RESET}"
    echo ""

    init_workspace

    local templates=()
    for d in "$WORKSPACE_DIR"/*/; do
        [[ -d "$d" ]] && templates+=("$(basename "$d")")
    done

    if [[ ${#templates[@]} -eq 0 ]]; then
        show_error "No templates found"
        press_enter
        return
    fi

    local i=1
    for t in "${templates[@]}"; do
        echo "  $i) $t"
        ((i++))
    done
    echo "  0) Cancel"
    echo ""

    read -rp "Select template: " choice
    choice=$(sanitize_input "$choice")

    if [[ "$choice" == "0" ]]; then
        return
    fi

    if ! validate_number "$choice" 1 "${#templates[@]}"; then
        show_error "Invalid selection"
        press_enter
        return
    fi

    local selected="${templates[$((choice-1))]}"

    echo ""
    read -rp "Project name: " project_name
    project_name=$(sanitize_input "$project_name")

    if [[ -z "$project_name" ]]; then
        show_error "Project name cannot be empty"
        press_enter
        return
    fi

    # $HOME enforcement
    read -rp "Destination path (default: $HOME/$project_name): " dest_path
    dest_path=$(sanitize_input "$dest_path")
    dest_path="${dest_path:-$HOME/$project_name}"
    dest_path="${dest_path/#\~/$HOME}"

    # Block external storage
    if ! is_exec_safe "$dest_path"; then
        show_warning "External storage cannot execute scripts. Using $HOME/workspace/$project_name instead."
        dest_path="$HOME/workspace/$project_name"
    fi

    if [[ -e "$dest_path" ]]; then
        show_error "Path already exists: $dest_path"
        press_enter
        return
    fi

    mkdir -p "$(dirname "$dest_path")"
    cp -r "$WORKSPACE_DIR/$selected" "$dest_path"

    show_success "Created $project_name from $selected template"
    log_recent "CREATE_PROJECT" "$project_name from $selected"
    press_enter
}

list_templates() {
    draw_header
    echo -e "${C_CYAN}${C_BOLD}📋 Available Templates${C_RESET}"
    echo ""

    init_workspace

    for d in "$WORKSPACE_DIR"/*/; do
        [[ -d "$d" ]] && echo "  • $(basename "$d")"
    done

    echo ""
    press_enter
}

create_custom_template() {
    draw_header
    echo -e "${C_CYAN}${C_BOLD}📝 Create Custom Template${C_RESET}"
    echo ""

    read -rp "Template name: " name
    name=$(sanitize_input "$name")

    if [[ -z "$name" ]]; then
        show_error "Name cannot be empty"
        press_enter
        return
    fi

    mkdir -p "$WORKSPACE_DIR/$name"

    echo ""
    echo "Create files in $WORKSPACE_DIR/$name"
    echo "Use your editor to add files, then return here."
    echo ""
    press_enter

    show_success "Template '$name' created"
    log_recent "CREATE_TEMPLATE" "$name"
    press_enter
}

git_init_project() {
    echo ""
    read -rp "Project path (default: current directory): " path
    path=$(sanitize_input "$path")
    path="${path:-.}"
    path="${path/#\~/$HOME}"

    if [[ ! -d "$path" ]]; then
        show_error "Directory not found: $path"
        press_enter
        return
    fi

    if command -v git >/dev/null 2>&1; then
        cd "$path" && git init 2>/dev/null && show_success "Git repository initialized" || show_error "Git init failed"
    else
        show_error "Git not installed"
    fi
    press_enter
}

github_repo() {
    if ! command -v gh >/dev/null 2>&1; then
        show_error "GitHub CLI (gh) not installed. Install it first."
        press_enter
        return
    fi

    echo ""
    read -rp "Repository name: " repo_name
    repo_name=$(sanitize_input "$repo_name")

    if [[ -z "$repo_name" ]]; then
        show_error "Repository name cannot be empty"
        press_enter
        return
    fi

    read -rp "Make public? [Y/n]: " public
    local visibility="--public"
    [[ "$public" =~ ^[Nn]$ ]] && visibility="--private"

    gh repo create "$repo_name" $visibility 2>/dev/null && show_success "Repository created: github.com/$repo_name" || show_error "Failed to create repository"
    log_recent "GITHUB_REPO" "$repo_name"
    press_enter
}
