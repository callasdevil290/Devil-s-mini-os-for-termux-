#!/usr/bin/env bash
# =============================================================================
# Devil's Mini OS Launcher - nix_pkgs.sh
# Version: v1.1.0
# Purpose: Nix package manager integration with disk + battery checks
# =============================================================================

nix_pkgs_menu() {
    while true; do
        draw_header
        echo -e "${C_CYAN}${C_BOLD}❄️ Nix Packages${C_RESET}"
        echo ""

        echo -e "${C_YELLOW}⚠️  Nix requires proot distro and ~2GB disk space${C_RESET}"
        echo ""

        echo "  1) Install Nix in proot distro"
        echo "  2) Search packages"
        echo "  3) Install single package"
        echo "  4) Install batch packages"
        echo "  5) Show installed packages"
        echo "  6) Remove package"
        echo "  0) Back to Main Menu"
        echo ""

        read -rp "Enter choice: " choice
        choice=$(sanitize_input "$choice")

        case "$choice" in
            1) install_nix ;;
            2) search_nix ;;
            3) install_single_nix ;;
            4) install_batch_nix ;;
            5) show_installed_nix ;;
            6) remove_nix_pkg ;;
            0) return ;;
            *) show_error "Invalid choice"; press_enter ;;
        esac
    done
}

install_nix() {
    # Select target distro
    local distros=()
    while IFS= read -r d; do
        [[ -n "$d" ]] && distros+=("$d")
    done < <(source "$SCRIPT_DIR/modules/linux_env.sh" && list_installed_distros 2>/dev/null || true)

    # Fallback
    if [[ ${#distros[@]} -eq 0 ]]; then
        local runtime_dir="${RUNTIME_DIR:-$PREFIX/var/lib}"
        if [[ -d "$runtime_dir/proot-distro/installed-rootfs" ]]; then
            for d in "$runtime_dir/proot-distro/installed-rootfs"/*/; do
                [[ -d "$d" ]] && distros+=("$(basename "$d")")
            done
        fi
        if [[ -d "$runtime_dir/proot-distro/containers" ]]; then
            for d in "$runtime_dir/proot-distro/containers"/*/; do
                local name
                name=$(basename "$d")
                local found=false
                for existing in "${distros[@]}"; do
                    [[ "$existing" == "$name" ]] && found=true
                done
                [[ "$found" == false ]] && distros+=("$name")
            done
        fi
    fi

    if [[ ${#distros[@]} -eq 0 ]]; then
        show_error "No proot distros installed. Install one first."
        press_enter
        return
    fi

    draw_header
    echo -e "${C_CYAN}${C_BOLD}❄️ Install Nix${C_RESET}"
    echo ""
    echo "Select target distro:"
    local i=1
    for d in "${distros[@]}"; do
        echo "  $i) $d"
        ((i++))
    done
    echo "  0) Cancel"
    echo ""

    read -rp "Select distro: " dchoice
    dchoice=$(sanitize_input "$dchoice")

    if [[ "$dchoice" == "0" ]]; then
        return
    fi

    if ! validate_number "$dchoice" 1 "${#distros[@]}"; then
        show_error "Invalid selection"
        press_enter
        return
    fi

    local target_distro="${distros[$((dchoice-1))]}"

    # Heavy I/O warning
    echo ""
    echo -e "${C_YELLOW}╔════════════════════════════════════════════════════════════╗${C_RESET}"
    echo -e "${C_YELLOW}║  ⚠️  NIX INSTALLATION WARNING                             ║${C_RESET}"
    echo -e "${C_YELLOW}║                                                            ║${C_RESET}"
    echo -e "${C_YELLOW}║  Nix requires ~2GB download and heavy I/O.              ║${C_RESET}"
    echo -e "${C_YELLOW}║  In proot, this can take 30-60 minutes on mid-range.    ║${C_RESET}"
    echo -e "${C_YELLOW}║  Device may become unresponsive during install.         ║${C_RESET}"
    echo -e "${C_YELLOW}╚════════════════════════════════════════════════════════════╝${C_RESET}"
    echo ""
    read -rp "Continue? This will take a while. [y/N] " confirm
    [[ "$confirm" =~ ^[Yy]$ ]] || return

    # Disk space check (need 3GB free)
    local free_space
    free_space=$(df -m "$HOME" | awk 'NR==2 {print $4}')
    if [[ -z "$free_space" || ! "$free_space" =~ ^[0-9]+$ ]]; then
        free_space=9999
    fi
    if [[ "$free_space" -lt 3072 ]]; then
        echo -e "${C_RED}❌ Need 3GB free space. You have ${free_space}MB.${C_RESET}"
        press_enter
        return
    fi

    # Battery check
    if ! check_battery_before_heavy_op; then
        press_enter
        return
    fi

    log_info "Installing Nix in proot distro: $target_distro"
    echo ""
    echo -e "${C_BLUE}Installing Nix in $target_distro...${C_RESET}"
    echo -e "${C_DIM}This will take 30-60 minutes. Do not interrupt.${C_RESET}"
    echo ""

    # Run with ionice if available
    if command -v ionice >/dev/null 2>&1; then
        ionice -c 3 proot-distro login "$target_distro" -- sh -c "
            curl -L https://nixos.org/nix/install | sh
        " 2>&1 || {
            show_error "Nix installation failed"
            press_enter
            return
        }
    else
        proot-distro login "$target_distro" -- sh -c "
            curl -L https://nixos.org/nix/install | sh
        " 2>&1 || {
            show_error "Nix installation failed"
            press_enter
            return
        }
    fi

    show_success "Nix installed in $target_distro!"
    log_recent "INSTALL_NIX" "$target_distro"
    echo ""
    echo -e "${C_CYAN}To use Nix, run:${C_RESET}"
    echo "  proot-distro login $target_distro"
    echo "  . ~/.nix-profile/etc/profile.d/nix.sh"
    echo "  nix --version"
    press_enter
}

search_nix() {
    local distros=()
    while IFS= read -r d; do
        [[ -n "$d" ]] && distros+=("$d")
    done < <(source "$SCRIPT_DIR/modules/linux_env.sh" && list_installed_distros 2>/dev/null || true)

    if [[ ${#distros[@]} -eq 0 ]]; then
        show_error "No proot distros installed."
        press_enter
        return
    fi

    echo ""
    echo "Select distro with Nix:"
    local i=1
    for d in "${distros[@]}"; do
        echo "  $i) $d"
        ((i++))
    done
    echo ""

    read -rp "Select: " dchoice
    dchoice=$(sanitize_input "$dchoice")

    if ! validate_number "$dchoice" 1 "${#distros[@]}"; then
        show_error "Invalid selection"
        press_enter
        return
    fi

    local target_distro="${distros[$((dchoice-1))]}"

    echo ""
    read -rp "Search for package: " query
    query=$(sanitize_input "$query")

    if [[ -z "$query" ]]; then
        show_error "Search query cannot be empty"
        press_enter
        return
    fi

    echo ""
    echo -e "${C_BLUE}Searching in $target_distro...${C_RESET}"
    proot-distro login "$target_distro" -- bash -c "
        . ~/.nix-profile/etc/profile.d/nix.sh 2>/dev/null
        nix search nixpkgs $query 2>&1 | head -20
    "

    press_enter
}

install_single_nix() {
    local distros=()
    while IFS= read -r d; do
        [[ -n "$d" ]] && distros+=("$d")
    done < <(source "$SCRIPT_DIR/modules/linux_env.sh" && list_installed_distros 2>/dev/null || true)

    if [[ ${#distros[@]} -eq 0 ]]; then
        show_error "No proot distros installed."
        press_enter
        return
    fi

    echo ""
    echo "Select distro with Nix:"
    local i=1
    for d in "${distros[@]}"; do
        echo "  $i) $d"
        ((i++))
    done
    echo ""

    read -rp "Select: " dchoice
    dchoice=$(sanitize_input "$dchoice")

    if ! validate_number "$dchoice" 1 "${#distros[@]}"; then
        show_error "Invalid selection"
        press_enter
        return
    fi

    local target_distro="${distros[$((dchoice-1))]}"

    echo ""
    read -rp "Package name to install: " pkg
    pkg=$(sanitize_input "$pkg")

    if [[ -z "$pkg" ]]; then
        show_error "Package name cannot be empty"
        press_enter
        return
    fi

    echo ""
    echo -e "${C_BLUE}Installing $pkg in $target_distro...${C_RESET}"
    proot-distro login "$target_distro" -- bash -c "
        . ~/.nix-profile/etc/profile.d/nix.sh 2>/dev/null
        nix-env -iA nixpkgs.$pkg 2>&1
    " || {
        show_error "Installation failed"
        press_enter
        return
    }

    show_success "$pkg installed!"
    log_recent "INSTALL_NIX_PKG" "$pkg in $target_distro"
    press_enter
}

install_batch_nix() {
    local distros=()
    while IFS= read -r d; do
        [[ -n "$d" ]] && distros+=("$d")
    done < <(source "$SCRIPT_DIR/modules/linux_env.sh" && list_installed_distros 2>/dev/null || true)

    if [[ ${#distros[@]} -eq 0 ]]; then
        show_error "No proot distros installed."
        press_enter
        return
    fi

    echo ""
    echo "Select distro with Nix:"
    local i=1
    for d in "${distros[@]}"; do
        echo "  $i) $d"
        ((i++))
    done
    echo ""

    read -rp "Select: " dchoice
    dchoice=$(sanitize_input "$dchoice")

    if ! validate_number "$dchoice" 1 "${#distros[@]}"; then
        show_error "Invalid selection"
        press_enter
        return
    fi

    local target_distro="${distros[$((dchoice-1))]}"

    echo ""
    read -rp "Enter package names (space-separated): " pkgs
    pkgs=$(sanitize_input "$pkgs")

    if [[ -z "$pkgs" ]]; then
        show_error "Package names cannot be empty"
        press_enter
        return
    fi

    echo ""
    echo -e "${C_BLUE}Installing packages in $target_distro...${C_RESET}"
    proot-distro login "$target_distro" -- bash -c "
        . ~/.nix-profile/etc/profile.d/nix.sh 2>/dev/null
        nix-env -iA nixpkgs.{$(echo $pkgs | tr ' ' ',')} 2>&1
    " || {
        show_error "Installation failed"
        press_enter
        return
    }

    show_success "Packages installed!"
    log_recent "INSTALL_NIX_BATCH" "$pkgs in $target_distro"
    press_enter
}

show_installed_nix() {
    local distros=()
    while IFS= read -r d; do
        [[ -n "$d" ]] && distros+=("$d")
    done < <(source "$SCRIPT_DIR/modules/linux_env.sh" && list_installed_distros 2>/dev/null || true)

    if [[ ${#distros[@]} -eq 0 ]]; then
        show_error "No proot distros installed."
        press_enter
        return
    fi

    echo ""
    echo "Select distro:"
    local i=1
    for d in "${distros[@]}"; do
        echo "  $i) $d"
        ((i++))
    done
    echo ""

    read -rp "Select: " dchoice
    dchoice=$(sanitize_input "$dchoice")

    if ! validate_number "$dchoice" 1 "${#distros[@]}"; then
        show_error "Invalid selection"
        press_enter
        return
    fi

    local target_distro="${distros[$((dchoice-1))]}"

    echo ""
    echo -e "${C_BLUE}Installed Nix packages in $target_distro:${C_RESET}"
    proot-distro login "$target_distro" -- bash -c "
        . ~/.nix-profile/etc/profile.d/nix.sh 2>/dev/null
        nix-env -q 2>&1
    "

    press_enter
}

remove_nix_pkg() {
    local distros=()
    while IFS= read -r d; do
        [[ -n "$d" ]] && distros+=("$d")
    done < <(source "$SCRIPT_DIR/modules/linux_env.sh" && list_installed_distros 2>/dev/null || true)

    if [[ ${#distros[@]} -eq 0 ]]; then
        show_error "No proot distros installed."
        press_enter
        return
    fi

    echo ""
    echo "Select distro:"
    local i=1
    for d in "${distros[@]}"; do
        echo "  $i) $d"
        ((i++))
    done
    echo ""

    read -rp "Select: " dchoice
    dchoice=$(sanitize_input "$dchoice")

    if ! validate_number "$dchoice" 1 "${#distros[@]}"; then
        show_error "Invalid selection"
        press_enter
        return
    fi

    local target_distro="${distros[$((dchoice-1))]}"

    echo ""
    read -rp "Package name to remove: " pkg
    pkg=$(sanitize_input "$pkg")

    if [[ -z "$pkg" ]]; then
        show_error "Package name cannot be empty"
        press_enter
        return
    fi

    echo ""
    echo -e "${C_BLUE}Removing $pkg from $target_distro...${C_RESET}"
    proot-distro login "$target_distro" -- bash -c "
        . ~/.nix-profile/etc/profile.d/nix.sh 2>/dev/null
        nix-env -e $pkg 2>&1
    " || {
        show_error "Removal failed"
        press_enter
        return
    }

    show_success "$pkg removed!"
    log_recent "REMOVE_NIX_PKG" "$pkg from $target_distro"
    press_enter
}
