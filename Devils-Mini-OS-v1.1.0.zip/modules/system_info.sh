#!/usr/bin/env bash
# =============================================================================
# Devil's Mini OS Launcher - system_info.sh
# Version: v1.1.0
# Purpose: Display comprehensive system information
# =============================================================================

system_info_menu() {
    draw_header
    echo -e "${C_CYAN}${C_BOLD}ℹ️ System Information${C_RESET}"
    echo ""

    # Device info
    echo -e "${C_BOLD}── Device ──${C_RESET}"
    if [[ "$(detect_platform)" == "termux" ]]; then
        echo -e "  Model:        $(getprop ro.product.model 2>/dev/null || echo 'N/A')"
        echo -e "  Manufacturer: $(getprop ro.product.manufacturer 2>/dev/null || echo 'N/A')"
        echo -e "  Android:      $(detect_android_version)"
        echo -e "  Termux:       ${TERMUX_VERSION:-N/A}"
        echo -e "  Termux Source: $(detect_termux_source)"
        echo -e "  Termux:API:   $(detect_termux_api)"
    else
        echo -e "  OS:           $(grep PRETTY_NAME /etc/os-release 2>/dev/null | cut -d= -f2 | tr -d '"' || echo 'Linux')"
    fi
    echo ""

    # Hardware
    echo -e "${C_BOLD}── Hardware ──${C_RESET}"
    echo -e "  Architecture: $(detect_architecture)"
    echo -e "  Kernel:       $(uname -r)"
    echo -e "  Terminal:     $(detect_terminal_width) columns"
    echo ""

    # Resources
    echo -e "${C_BOLD}── Resources ──${C_RESET}"
    if command -v free >/dev/null 2>&1; then
        free -h 2>/dev/null | awk 'NR==2 {printf "  Memory:       %s used / %s total\n", $3, $2}'
    fi
    df -h "$HOME" 2>/dev/null | awk 'NR==2 {printf "  Storage:      %s used / %s total (%s free)\n", $3, $2, $4}'
    echo ""

    # Proot status
    echo -e "${C_BOLD}── Proot Status ──${C_RESET}"
    if command -v proot-distro >/dev/null 2>&1; then
        local pd_version
        pd_version=$(source "$SCRIPT_DIR/modules/linux_env.sh" && detect_proot_distro_version 2>/dev/null || echo "unknown")
        echo -e "  proot-distro: $pd_version"

        local distros=()
        while IFS= read -r d; do
            [[ -n "$d" ]] && distros+=("$d")
        done < <(source "$SCRIPT_DIR/modules/linux_env.sh" && list_installed_distros 2>/dev/null || true)

        if [[ ${#distros[@]} -gt 0 ]]; then
            echo -e "  Installed:    ${#distros[@]} distro(s)"
            for d in "${distros[@]}"; do
                local size
                size=$(source "$SCRIPT_DIR/modules/linux_env.sh" && get_distro_rootfs_path "$d" 2>/dev/null)
                if [[ -n "$size" && -d "$size" ]]; then
                    size=$(du -sh "$size" 2>/dev/null | cut -f1 || echo "unknown")
                    echo -e "    • $d ($size)"
                else
                    echo -e "    • $d"
                fi
            done
        else
            echo -e "  Installed:    None"
        fi
    else
        echo -e "  proot-distro: Not installed"
    fi
    echo ""

    # Health status
    echo -e "${C_BOLD}── Health Status ──${C_RESET}"
    local disk_pct
    disk_pct=$(df "$HOME" 2>/dev/null | awk 'NR==2 {gsub(/%/,""); print $5}')
    if [[ -n "$disk_pct" && "$disk_pct" -gt 90 ]]; then
        echo -e "  ${C_RED}CRITICAL: Disk ${disk_pct}% full${C_RESET}"
    elif [[ -n "$disk_pct" && "$disk_pct" -gt 80 ]]; then
        echo -e "  ${C_YELLOW}WARNING: Disk ${disk_pct}% full${C_RESET}"
    else
        echo -e "  ${C_GREEN}GOOD${C_RESET}"
    fi
    echo ""

    # Launcher info
    echo -e "${C_BOLD}── Devil's Mini OS ──${C_RESET}"
    echo -e "  Version:      $DMOL_VERSION ($DMOL_DATE)"
    echo -e "  Config:       $DMOL_CONFIG_DIR"
    echo -e "  Logs:         $DMOL_CONFIG_DIR/logs"
    echo ""

    log_recent "VIEW_SYSTEM_INFO" ""
    press_enter
}
