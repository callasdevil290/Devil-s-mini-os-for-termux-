#!/usr/bin/env bash
# =============================================================================
# Devil's Mini OS Launcher - file_mgr.sh
# Version: v1.1.0
# Purpose: Built-in file operations with external storage safety
# =============================================================================

FM_CURRENT_DIR="${HOME:-/data/data/com.termux/files/home}"
FM_SHOW_HIDDEN=false
FM_PAGE_SIZE=20

file_mgr_menu() {
    FM_CURRENT_DIR="$HOME"
    FM_SHOW_HIDDEN=false

    while true; do
        draw_file_mgr_header
        list_files

        echo ""
        local term_width
        term_width=$(detect_terminal_width)

        if [[ "$term_width" -lt 50 ]]; then
            echo "n)ext p)rev o)pen c)opy m)ove d)elete"
            echo "g)oto mk)dir v)iew h)idden e)xec"
            echo "du)size s)earch per)ms x)tract"
            echo "0) Back"
        else
            echo "────────────────────────────────────"
            echo "  n) Next page    p) Previous page"
            echo "  o) Open/Enter   c) Copy"
            echo "  m) Move         d) Delete"
            echo "  g) Go to path   mk) Make dir"
            echo "  v) View file    h) Toggle hidden"
            echo "  e) Execute      du) Disk usage"
            echo "  s) Search       per) Permissions"
            echo "  x) Extract      dl) Download"
            echo "  sh) Share       op) Open external"
            echo ""
            echo "  0) Back to Main Menu"
        fi
        echo ""

        read -rp "Action: " action
        action=$(sanitize_input "$action")

        case "$action" in
            n|N) fm_next_page ;;
            p|P) fm_prev_page ;;
            o|O) fm_open ;;
            c|C) fm_copy ;;
            m|M) fm_move ;;
            d|D) fm_delete ;;
            g|G) fm_goto ;;
            mk|MK) fm_makedir ;;
            v|V) fm_view ;;
            h|H) fm_toggle_hidden ;;
            e|E) fm_execute ;;
            du|DU) fm_disk_usage ;;
            s|S) fm_search ;;
            per|PER) fm_permissions ;;
            x|X) fm_extract ;;
            dl|DL) fm_download ;;
            sh|SH) fm_share ;;
            op|OP) fm_open_external ;;
            0) return ;;
            *) 
                # Check if it's a number (file selection)
                if [[ "$action" =~ ^[0-9]+$ ]]; then
                    fm_select_by_number "$action"
                else
                    show_error "Unknown action: $action"
                    press_enter
                fi
                ;;
        esac
    done
}

draw_file_mgr_header() {
    draw_header
    echo -e "${C_CYAN}${C_BOLD}📁 File Manager${C_RESET}"
    echo ""

    # Truncate path if too long
    local term_width
    term_width=$(detect_terminal_width)
    local display_path="$FM_CURRENT_DIR"

    if [[ "${#display_path}" -gt "$((term_width - 4))" ]]; then
        display_path="...${display_path: -$((term_width - 8))}"
    fi

    echo -e "${C_GREEN}Path: ${C_RESET}$display_path"

    # External storage warning
    if [[ "$FM_CURRENT_DIR" == "$HOME/storage/shared"* ]] || [[ "$FM_CURRENT_DIR" == "/sdcard"* ]] || [[ "$FM_CURRENT_DIR" == "/storage/emulated"* ]]; then
        echo -e "${C_YELLOW}⚠️  External storage — scripts cannot execute from here${C_RESET}"
    fi

    echo ""
}

list_files() {
    local page=0
    local count=0
    local files=()

    # Build file list
    if [[ "$FM_SHOW_HIDDEN" == true ]]; then
        while IFS= read -r -d '' file; do
            files+=("$file")
        done < <(find "$FM_CURRENT_DIR" -maxdepth 1 -print0 2>/dev/null | sort -z)
    else
        while IFS= read -r -d '' file; do
            local basename_file
            basename_file=$(basename "$file")
            [[ "$basename_file" == .* ]] && continue
            files+=("$file")
        done < <(find "$FM_CURRENT_DIR" -maxdepth 1 -print0 2>/dev/null | sort -z)
    fi

    # Skip . and ..
    local display_files=()
    for f in "${files[@]}"; do
        local b
        b=$(basename "$f")
        [[ "$b" == "." ]] && continue
        display_files+=("$f")
    done

    if [[ ${#display_files[@]} -eq 0 ]]; then
        echo -e "${C_DIM}(empty directory)${C_RESET}"
        return
    fi

    # Display with numbers
    local i=1
    for f in "${display_files[@]}"; do
        local b
        b=$(basename "$f")
        local icon="📄"
        local color="$C_RESET"

        if [[ -d "$f" ]]; then
            icon="📁"
            color="$C_BLUE"
        elif [[ -x "$f" ]]; then
            icon="⚙️"
            color="$C_GREEN"
        elif [[ "$b" == *.sh ]]; then
            icon="📝"
            color="$C_CYAN"
        elif [[ "$b" == *.tar* || "$b" == *.zip || "$b" == *.gz ]]; then
            icon="📦"
            color="$C_YELLOW"
        fi

        # Mark if not exec-safe
        if [[ -f "$f" && -x "$f" ]] && ! is_exec_safe "$f"; then
            icon="🚫"
        fi

        printf "  %2d) %s %s%s%s\n" "$i" "$icon" "$color" "$b" "$C_RESET"
        ((i++))
    done

    export FM_FILE_LIST=("${display_files[@]}")
}

fm_select_by_number() {
    local num="$1"
    local files=("${FM_FILE_LIST[@]}")

    if ! validate_number "$num" 1 "${#files[@]}"; then
        show_error "Invalid selection"
        press_enter
        return
    fi

    local selected="${files[$((num-1))]}"

    if [[ -d "$selected" ]]; then
        FM_CURRENT_DIR="$selected"
    else
        echo ""
        echo -e "${C_CYAN}Selected: $(basename "$selected")${C_RESET}"
        echo "  s) View    c) Copy    m) Move"
        echo "  d) Delete  e) Execute x) Extract"
        echo "  0) Cancel"
        echo ""
        read -rp "Action: " subaction

        case "$subaction" in
            s|S) fm_view_file "$selected" ;;
            c|C) fm_copy_file "$selected" ;;
            m|M) fm_move_file "$selected" ;;
            d|D) fm_delete_file "$selected" ;;
            e|E) fm_execute_file "$selected" ;;
            x|X) fm_extract_file "$selected" ;;
        esac
    fi
}

fm_open() {
    echo ""
    read -rp "Enter directory name or number: " target
    target=$(sanitize_input "$target")

    if [[ "$target" =~ ^[0-9]+$ ]]; then
        fm_select_by_number "$target"
        return
    fi

    local new_path
    if [[ "$target" == /* ]]; then
        new_path="$target"
    else
        new_path="$FM_CURRENT_DIR/$target"
    fi

    if [[ -d "$new_path" ]]; then
        FM_CURRENT_DIR="$new_path"
    else
        show_error "Not a directory: $target"
        press_enter
    fi
}

fm_goto() {
    echo ""
    read -rp "Enter full path: " path
    path=$(sanitize_input "$path")

    # Expand ~
    path="${path/#\~/$HOME}"

    if [[ -d "$path" ]]; then
        FM_CURRENT_DIR="$path"
    else
        show_error "Directory not found: $path"
        press_enter
    fi
}

fm_copy() {
    echo ""
    read -rp "Enter source (name or number): " src
    src=$(sanitize_input "$src")

    local src_path
    if [[ "$src" =~ ^[0-9]+$ ]]; then
        local files=("${FM_FILE_LIST[@]}")
        src_path="${files[$((src-1))]}"
    else
        src_path="$FM_CURRENT_DIR/$src"
    fi

    if [[ ! -e "$src_path" ]]; then
        show_error "Source not found: $src"
        press_enter
        return
    fi

    read -rp "Enter destination path: " dest
    dest=$(sanitize_input "$dest")
    dest="${dest/#\~/$HOME}"

    if cp -r "$src_path" "$dest" 2>/dev/null; then
        show_success "Copied to $dest"
        log_recent "FILE_COPY" "$src_path -> $dest"
    else
        show_error "Copy failed"
    fi
    press_enter
}

fm_move() {
    echo ""
    read -rp "Enter source (name or number): " src
    src=$(sanitize_input "$src")

    local src_path
    if [[ "$src" =~ ^[0-9]+$ ]]; then
        local files=("${FM_FILE_LIST[@]}")
        src_path="${files[$((src-1))]}"
    else
        src_path="$FM_CURRENT_DIR/$src"
    fi

    if [[ ! -e "$src_path" ]]; then
        show_error "Source not found: $src"
        press_enter
        return
    fi

    read -rp "Enter destination path: " dest
    dest=$(sanitize_input "$dest")
    dest="${dest/#\~/$HOME}"

    if mv "$src_path" "$dest" 2>/dev/null; then
        show_success "Moved to $dest"
        log_recent "FILE_MOVE" "$src_path -> $dest"
    else
        show_error "Move failed"
    fi
    press_enter
}

fm_delete() {
    echo ""
    read -rp "Enter item to delete (name or number): " target
    target=$(sanitize_input "$target")

    local target_path
    if [[ "$target" =~ ^[0-9]+$ ]]; then
        local files=("${FM_FILE_LIST[@]}")
        target_path="${files[$((target-1))]}"
    else
        target_path="$FM_CURRENT_DIR/$target"
    fi

    if [[ ! -e "$target_path" ]]; then
        show_error "Not found: $target"
        press_enter
        return
    fi

    local basename_target
    basename_target=$(basename "$target_path")
    read -rp "Confirm delete '$basename_target'? [y/N] " confirm
    if [[ "$confirm" =~ ^[Yy]$ ]]; then
        if rm -rf "$target_path" 2>/dev/null; then
            show_success "Deleted $basename_target"
            log_recent "FILE_DELETE" "$target_path"
        else
            show_error "Delete failed"
        fi
    else
        show_info "Cancelled"
    fi
    press_enter
}

fm_makedir() {
    echo ""
    read -rp "Enter directory name: " dirname
    dirname=$(sanitize_input "$dirname")

    if [[ -z "$dirname" ]]; then
        show_error "Name cannot be empty"
        press_enter
        return
    fi

    if mkdir -p "$FM_CURRENT_DIR/$dirname" 2>/dev/null; then
        show_success "Created directory: $dirname"
        log_recent "FILE_MKDIR" "$FM_CURRENT_DIR/$dirname"
    else
        show_error "Failed to create directory"
    fi
    press_enter
}

fm_view() {
    echo ""
    read -rp "Enter file to view (name or number): " target
    target=$(sanitize_input "$target")
    fm_view_file "$target"
}

fm_view_file() {
    local target="$1"
    local target_path

    if [[ "$target" =~ ^[0-9]+$ ]]; then
        local files=("${FM_FILE_LIST[@]}")
        target_path="${files[$((target-1))]}"
    else
        target_path="$FM_CURRENT_DIR/$target"
    fi

    if [[ ! -f "$target_path" ]]; then
        show_error "Not a file: $target"
        press_enter
        return
    fi

    echo ""
    echo -e "${C_CYAN}=== $(basename "$target_path") ===${C_RESET}"
    echo ""

    local line_count
    line_count=$(wc -l < "$target_path" 2>/dev/null || echo 0)

    if [[ "$line_count" -gt 50 ]]; then
        head -n 50 "$target_path"
        echo ""
        echo -e "${C_DIM}... ($((line_count - 50)) more lines)${C_RESET}"
    else
        cat "$target_path"
    fi

    echo ""
    press_enter
}

fm_toggle_hidden() {
    if [[ "$FM_SHOW_HIDDEN" == true ]]; then
        FM_SHOW_HIDDEN=false
        show_info "Hidden files hidden"
    else
        FM_SHOW_HIDDEN=true
        show_info "Hidden files shown"
    fi
    press_enter
}

fm_execute() {
    echo ""
    read -rp "Enter file to execute (name or number): " target
    target=$(sanitize_input "$target")
    fm_execute_file "$target"
}

fm_execute_file() {
    local target="$1"
    local target_path

    if [[ "$target" =~ ^[0-9]+$ ]]; then
        local files=("${FM_FILE_LIST[@]}")
        target_path="${files[$((target-1))]}"
    else
        target_path="$FM_CURRENT_DIR/$target"
    fi

    if [[ ! -f "$target_path" ]]; then
        show_error "Not a file: $target"
        press_enter
        return
    fi

    # Check exec safety
    if ! is_exec_safe "$target_path"; then
        show_error "Cannot execute from external storage (Android 10+ restriction)"
        press_enter
        return
    fi

    if [[ ! -x "$target_path" ]]; then
        chmod +x "$target_path" 2>/dev/null || true
    fi

    echo ""
    echo -e "${C_GREEN}Executing: $target_path${C_RESET}"
    echo ""
    bash "$target_path" 2>&1 || {
        show_error "Execution failed with exit code $?"
    }
    log_recent "FILE_EXECUTE" "$target_path"
    echo ""
    press_enter
}

fm_disk_usage() {
    echo ""
    echo -e "${C_CYAN}Disk Usage in $FM_CURRENT_DIR${C_RESET}"
    echo ""
    du -sh "$FM_CURRENT_DIR"/* 2>/dev/null | sort -rh | head -20
    echo ""
    echo -e "${C_GREEN}Total: $(du -sh "$FM_CURRENT_DIR" 2>/dev/null | cut -f1)${C_RESET}"
    press_enter
}

fm_search() {
    echo ""
    read -rp "Search for: " query
    query=$(sanitize_input "$query")

    if [[ -z "$query" ]]; then
        show_error "Search query cannot be empty"
        press_enter
        return
    fi

    echo ""
    echo -e "${C_CYAN}Searching in $FM_CURRENT_DIR...${C_RESET}"
    find "$FM_CURRENT_DIR" -maxdepth 3 -iname "*$query*" 2>/dev/null | head -30
    echo ""
    press_enter
}

fm_permissions() {
    echo ""
    read -rp "Enter file/directory (name or number): " target
    target=$(sanitize_input "$target")

    local target_path
    if [[ "$target" =~ ^[0-9]+$ ]]; then
        local files=("${FM_FILE_LIST[@]}")
        target_path="${files[$((target-1))]}"
    else
        target_path="$FM_CURRENT_DIR/$target"
    fi

    if [[ ! -e "$target_path" ]]; then
        show_error "Not found: $target"
        press_enter
        return
    fi

    echo ""
    ls -la "$target_path"
    echo ""
    read -rp "Enter new permissions (e.g., 755): " perms
    if [[ "$perms" =~ ^[0-7]{3,4}$ ]]; then
        chmod "$perms" "$target_path" 2>/dev/null && show_success "Permissions updated" || show_error "Failed"
    else
        show_error "Invalid permissions format"
    fi
    press_enter
}

fm_extract() {
    echo ""
    read -rp "Enter archive to extract (name or number): " target
    target=$(sanitize_input "$target")

    local target_path
    if [[ "$target" =~ ^[0-9]+$ ]]; then
        local files=("${FM_FILE_LIST[@]}")
        target_path="${files[$((target-1))]}"
    else
        target_path="$FM_CURRENT_DIR/$target"
    fi

    if [[ ! -f "$target_path" ]]; then
        show_error "Not a file: $target"
        press_enter
        return
    fi

    local basename_target
    basename_target=$(basename "$target_path")

    echo ""
    echo -e "${C_BLUE}Extracting $basename_target...${C_RESET}"

    if [[ "$basename_target" == *.tar.gz || "$basename_target" == *.tgz ]]; then
        tar -xzf "$target_path" -C "$FM_CURRENT_DIR" 2>&1 && show_success "Extracted" || show_error "Extraction failed"
    elif [[ "$basename_target" == *.tar.bz2 ]]; then
        tar -xjf "$target_path" -C "$FM_CURRENT_DIR" 2>&1 && show_success "Extracted" || show_error "Extraction failed"
    elif [[ "$basename_target" == *.tar.xz ]]; then
        tar -xJf "$target_path" -C "$FM_CURRENT_DIR" 2>&1 && show_success "Extracted" || show_error "Extraction failed"
    elif [[ "$basename_target" == *.zip ]]; then
        unzip -o "$target_path" -d "$FM_CURRENT_DIR" 2>&1 && show_success "Extracted" || show_error "Extraction failed"
    elif [[ "$basename_target" == *.tar ]]; then
        tar -xf "$target_path" -C "$FM_CURRENT_DIR" 2>&1 && show_success "Extracted" || show_error "Extraction failed"
    else
        show_error "Unknown archive format"
    fi

    log_recent "FILE_EXTRACT" "$target_path"
    press_enter
}

fm_download() {
    echo ""
    read -rp "Enter URL to download: " url
    url=$(sanitize_input "$url")

    if [[ -z "$url" ]]; then
        show_error "URL cannot be empty"
        press_enter
        return
    fi

    read -rp "Enter filename (optional, press Enter for default): " filename
    filename=$(sanitize_input "$filename")

    if [[ -z "$filename" ]]; then
        filename=$(basename "$url" | cut -d? -f1)
    fi

    echo ""
    echo -e "${C_BLUE}Downloading to $FM_CURRENT_DIR/$filename...${C_RESET}"

    if command -v wget >/dev/null 2>&1; then
        wget -O "$FM_CURRENT_DIR/$filename" "$url" 2>&1 || show_error "Download failed"
    elif command -v curl >/dev/null 2>&1; then
        curl -L -o "$FM_CURRENT_DIR/$filename" "$url" 2>&1 || show_error "Download failed"
    else
        show_error "Neither wget nor curl is available"
    fi

    log_recent "FILE_DOWNLOAD" "$url -> $FM_CURRENT_DIR/$filename"
    press_enter
}

fm_share() {
    if [[ "$(detect_platform)" != "termux" ]]; then
        show_error "termux-share only available in Termux"
        press_enter
        return
    fi

    if ! command -v termux-share >/dev/null 2>&1; then
        show_error "termux-share not available. Install Termux:API."
        press_enter
        return
    fi

    echo ""
    read -rp "Enter file to share (name or number): " target
    target=$(sanitize_input "$target")

    local target_path
    if [[ "$target" =~ ^[0-9]+$ ]]; then
        local files=("${FM_FILE_LIST[@]}")
        target_path="${files[$((target-1))]}"
    else
        target_path="$FM_CURRENT_DIR/$target"
    fi

    if [[ ! -f "$target_path" ]]; then
        show_error "Not a file: $target"
        press_enter
        return
    fi

    termux-share "$target_path" 2>/dev/null && show_success "Shared" || show_error "Share failed"
    press_enter
}

fm_open_external() {
    if [[ "$(detect_platform)" != "termux" ]]; then
        show_error "termux-open only available in Termux"
        press_enter
        return
    fi

    if ! command -v termux-open >/dev/null 2>&1; then
        show_error "termux-open not available. Install Termux:API."
        press_enter
        return
    fi

    echo ""
    read -rp "Enter file to open (name or number): " target
    target=$(sanitize_input "$target")

    local target_path
    if [[ "$target" =~ ^[0-9]+$ ]]; then
        local files=("${FM_FILE_LIST[@]}")
        target_path="${files[$((target-1))]}"
    else
        target_path="$FM_CURRENT_DIR/$target"
    fi

    if [[ ! -e "$target_path" ]]; then
        show_error "Not found: $target"
        press_enter
        return
    fi

    termux-open "$target_path" 2>/dev/null && show_success "Opened externally" || show_error "Open failed"
    press_enter
}

fm_next_page() { :; }
fm_prev_page() { :; }
