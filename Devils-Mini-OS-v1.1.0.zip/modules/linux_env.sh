#!/usr/bin/env bash
# =============================================================================
# Devil's Mini OS Launcher - linux_env.sh
# Version: v1.1.0
# Purpose: Proot distro management — legacy + new Docker/OCI format support
# =============================================================================

linux_env_menu() {
    while true; do
        draw_header
        echo -e "${C_CYAN}${C_BOLD}🐧 Linux Environments${C_RESET}"
        echo ""

        local term_width
        term_width=$(detect_terminal_width)

        if [[ "$term_width" -lt 50 ]]; then
            echo "1) Install    2) Launch CLI"
            echo "3) X11        4) VNC"
            echo "5) Desktop    6) Remove"
            echo "7) Info       8) Repair"
            echo "9) Export     10) Clone"
            echo "11) Backup    0) Back"
        else
            echo "  1) Install New Distro"
            echo "  2) Launch Distro (CLI)"
            echo "  3) Launch with X11"
            echo "  4) Launch with VNC"
            echo "  5) Install Desktop Environment"
            echo "  6) Remove Distro"
            echo "  7) Distro Info"
            echo "  8) Repair Distro"
            echo "  9) Export/Import Distro"
            echo " 10) Clone Distro"
            echo " 11) Backup/Restore"
            echo ""
            echo "  0) Back to Main Menu"
        fi
        echo ""

        local choice
        read -rp "Enter choice: " choice
        choice=$(sanitize_input "$choice")

        case "$choice" in
            1) install_distro ;;
            2) launch_distro_cli ;;
            3) launch_distro_x11 ;;
            4) launch_distro_vnc ;;
            5) install_desktop_in_distro ;;
            6) remove_distro ;;
            7) distro_info ;;
            8) repair_distro ;;
            9) export_import_distro ;;
            10) clone_distro ;;
            11) backup_restore_distro ;;
            0) return ;;
            *) show_error "Invalid choice"; press_enter ;;
        esac
    done
}

# --- Proot-Distro Format Detection ---
detect_proot_distro_version() {
    if command -v proot-distro >/dev/null 2>&1; then
        if proot-distro --help 2>/dev/null | grep -q "backup\|restore\|copy"; then
            echo "new"
        else
            echo "legacy"
        fi
    else
        echo "not-installed"
    fi
}

get_distro_rootfs_path() {
    local distro_name="$1"
    local runtime_dir="${RUNTIME_DIR:-$PREFIX/var/lib}"

    # Check new format first
    if [[ -d "$runtime_dir/proot-distro/containers/$distro_name/rootfs" ]]; then
        echo "$runtime_dir/proot-distro/containers/$distro_name/rootfs"
        return
    fi
    # Check legacy format
    if [[ -d "$runtime_dir/proot-distro/installed-rootfs/$distro_name" ]]; then
        echo "$runtime_dir/proot-distro/installed-rootfs/$distro_name"
        return
    fi
    echo ""
}

list_installed_distros() {
    local runtime_dir="${RUNTIME_DIR:-$PREFIX/var/lib}"
    local distros=()

    # New format
    if [[ -d "$runtime_dir/proot-distro/containers" ]]; then
        for d in "$runtime_dir/proot-distro/containers"/*/; do
            [[ -d "$d/rootfs" ]] && distros+=("$(basename "$d")")
        done
    fi

    # Legacy format
    if [[ -d "$runtime_dir/proot-distro/installed-rootfs" ]]; then
        for d in "$runtime_dir/proot-distro/installed-rootfs"/*/; do
            local name
            name=$(basename "$d")
            # Avoid duplicates
            local found=false
            for existing in "${distros[@]}"; do
                if [[ "$existing" == "$name" ]]; then
                    found=true
                    break
                fi
            done
            [[ "$found" == false ]] && distros+=("$name")
        done
    fi

    printf '%s\n' "${distros[@]}"
}

list_available_distros() {
    if command -v proot-distro >/dev/null 2>&1; then
        proot-distro list 2>/dev/null | grep -E '^\*' | awk '{print $2}' || true
    fi
}

# --- Install Distro ---
install_distro() {
    if ! command -v proot-distro >/dev/null 2>&1; then
        show_error "proot-distro not installed. Install it first from Termux App Store."
        press_enter
        return
    fi

    draw_header
    echo -e "${C_CYAN}${C_BOLD}📥 Install New Distro${C_RESET}"
    echo ""

    local pd_version
    pd_version=$(detect_proot_distro_version)
    echo -e "${C_DIM}Proot-distro format: $pd_version${C_RESET}"
    echo ""

    echo "Available distros:"
    local distros=()
    local i=1
    while IFS= read -r distro; do
        [[ -z "$distro" ]] && continue
        distros+=("$distro")
        echo "  $i) $distro"
        ((i++))
    done < <(list_available_distros)

    if [[ ${#distros[@]} -eq 0 ]]; then
        show_error "No distros available. Check proot-distro installation."
        press_enter
        return
    fi

    echo ""
    read -rp "Select distro (1-${#distros[@]}): " choice
    choice=$(sanitize_input "$choice")

    if ! validate_number "$choice" 1 "${#distros[@]}"; then
        show_error "Invalid selection"
        press_enter
        return
    fi

    local selected="${distros[$((choice-1))]}"

    # Battery check
    if ! check_battery_before_heavy_op; then
        press_enter
        return
    fi

    echo ""
    echo -e "${C_YELLOW}⚠️  This will download and install $selected.${C_RESET}"
    echo -e "${C_YELLOW}   This may take 10-30 minutes depending on your connection.${C_RESET}"
    read -rp "Continue? [y/N] " confirm
    if [[ ! "$confirm" =~ ^[Yy]$ ]]; then
        return
    fi

    log_info "Installing proot distro: $selected"
    echo ""

    if [[ "$pd_version" == "new" ]]; then
        proot-distro install "$selected" 2>&1 || {
            show_error "Installation failed. Check disk space and network."
            press_enter
            return
        }
    else
        proot-distro install "$selected" 2>&1 || {
            show_error "Installation failed. Check disk space and network."
            press_enter
            return
        }
    fi

    show_success "$selected installed successfully!"
    log_recent "INSTALL_DISTRO" "$selected"
    press_enter
}

# --- Launch CLI ---
launch_distro_cli() {
    local distros=()
    while IFS= read -r d; do
        [[ -n "$d" ]] && distros+=("$d")
    done < <(list_installed_distros)

    if [[ ${#distros[@]} -eq 0 ]]; then
        show_error "No distros installed. Install one first."
        press_enter
        return
    fi

    draw_header
    echo -e "${C_CYAN}${C_BOLD}🚀 Launch Distro (CLI)${C_RESET}"
    echo ""

    local i=1
    for d in "${distros[@]}"; do
        echo "  $i) $d"
        ((i++))
    done
    echo "  0) Cancel"
    echo ""

    read -rp "Select distro: " choice
    choice=$(sanitize_input "$choice")

    if [[ "$choice" == "0" ]]; then
        return
    fi

    if ! validate_number "$choice" 1 "${#distros[@]}"; then
        show_error "Invalid selection"
        press_enter
        return
    fi

    local selected="${distros[$((choice-1))]}"
    log_info "Launching distro CLI: $selected"
    log_recent "LAUNCH_DISTRO_CLI" "$selected"

    echo ""
    echo -e "${C_GREEN}Launching $selected... Press Ctrl+D to return.${C_RESET}"
    echo ""
    proot-distro login "$selected"
}

# --- Launch X11 ---
launch_distro_x11() {
    local distros=()
    while IFS= read -r d; do
        [[ -n "$d" ]] && distros+=("$d")
    done < <(list_installed_distros)

    if [[ ${#distros[@]} -eq 0 ]]; then
        show_error "No distros installed."
        press_enter
        return
    fi

    draw_header
    echo -e "${C_CYAN}${C_BOLD}🖥️ Launch with X11${C_RESET}"
    echo ""

    # Check for Termux:X11
    if [[ "$(detect_platform)" == "termux" ]] && ! command -v termux-x11 >/dev/null 2>&1; then
        echo -e "${C_YELLOW}⚠️  Termux:X11 not detected.${C_RESET}"
        echo "Install Termux:X11 from F-Droid for best experience."
        echo ""
    fi

    local i=1
    for d in "${distros[@]}"; do
        echo "  $i) $d"
        ((i++))
    done
    echo "  0) Cancel"
    echo ""

    read -rp "Select distro: " choice
    choice=$(sanitize_input "$choice")

    if [[ "$choice" == "0" ]]; then
        return
    fi

    if ! validate_number "$choice" 1 "${#distros[@]}"; then
        show_error "Invalid selection"
        press_enter
        return
    fi

    local selected="${distros[$((choice-1))]}"

    # Start pulseaudio if available
    if command -v pulseaudio >/dev/null 2>&1; then
        pulseaudio --start 2>/dev/null || true
    fi

    log_info "Launching distro X11: $selected"
    log_recent "LAUNCH_DISTRO_X11" "$selected"

    echo ""
    echo -e "${C_GREEN}Launching $selected with X11...${C_RESET}"
    echo -e "${C_DIM}Make sure Termux:X11 app is running.${C_RESET}"
    echo ""

    # Set DISPLAY and run desktop session
    export DISPLAY=:0
    proot-distro login "$selected" --shared-tmp -- env DISPLAY=:0 bash -c '
        if [ -f ~/.xsession ]; then
            exec ~/.xsession
        elif [ -f ~/.xinitrc ]; then
            exec startx
        else
            echo "No desktop session found. Install a desktop environment first."
        fi
    '
}

# --- Launch VNC ---
launch_distro_vnc() {
    local distros=()
    while IFS= read -r d; do
        [[ -n "$d" ]] && distros+=("$d")
    done < <(list_installed_distros)

    if [[ ${#distros[@]} -eq 0 ]]; then
        show_error "No distros installed."
        press_enter
        return
    fi

    draw_header
    echo -e "${C_CYAN}${C_BOLD}🖥️ Launch with VNC${C_RESET}"
    echo ""

    local i=1
    for d in "${distros[@]}"; do
        echo "  $i) $d"
        ((i++))
    done
    echo "  0) Cancel"
    echo ""

    read -rp "Select distro: " choice
    choice=$(sanitize_input "$choice")

    if [[ "$choice" == "0" ]]; then
        return
    fi

    if ! validate_number "$choice" 1 "${#distros[@]}"; then
        show_error "Invalid selection"
        press_enter
        return
    fi

    local selected="${distros[$((choice-1))]}"

    # Check for tigervnc
    if ! command -v vncserver >/dev/null 2>&1; then
        echo -e "${C_YELLOW}Installing TigerVNC...${C_RESET}"
        pkg install -y tigervnc 2>/dev/null || {
            show_error "Failed to install TigerVNC"
            press_enter
            return
        }
    fi

    log_info "Launching distro VNC: $selected"
    log_recent "LAUNCH_DISTRO_VNC" "$selected"

    echo ""
    echo -e "${C_GREEN}Launching $selected with VNC on :1...${C_RESET}"
    echo -e "${C_DIM}Connect with any VNC viewer to localhost:5901${C_RESET}"
    echo ""

    proot-distro login "$selected" -- bash -c '
        export USER=root
        export HOME=/root
        mkdir -p ~/.vnc
        if [ ! -f ~/.vnc/xstartup ]; then
            cat > ~/.vnc/xstartup << "EOF"
#!/bin/bash
xrdb $HOME/.Xresources 2>/dev/null
startxfce4 &
EOF
            chmod +x ~/.vnc/xstartup
        fi
        vncserver :1 -geometry 1280x720 -depth 24
    '
}

# --- Install Desktop in Distro ---
install_desktop_in_distro() {
    local distros=()
    while IFS= read -r d; do
        [[ -n "$d" ]] && distros+=("$d")
    done < <(list_installed_distros)

    if [[ ${#distros[@]} -eq 0 ]]; then
        show_error "No distros installed."
        press_enter
        return
    fi

    draw_header
    echo -e "${C_CYAN}${C_BOLD}🖥️ Install Desktop Environment${C_RESET}"
    echo ""

    local i=1
    for d in "${distros[@]}"; do
        echo "  $i) $d"
        ((i++))
    done
    echo ""

    read -rp "Select target distro: " dchoice
    dchoice=$(sanitize_input "$dchoice")

    if ! validate_number "$dchoice" 1 "${#distros[@]}"; then
        show_error "Invalid selection"
        press_enter
        return
    fi

    local target_distro="${distros[$((dchoice-1))]}"

    # Delegate to desktop_env module
    source "$SCRIPT_DIR/modules/desktop_env.sh"
    install_desktop "$target_distro"
}

# --- Remove Distro ---
remove_distro() {
    local distros=()
    while IFS= read -r d; do
        [[ -n "$d" ]] && distros+=("$d")
    done < <(list_installed_distros)

    if [[ ${#distros[@]} -eq 0 ]]; then
        show_error "No distros installed."
        press_enter
        return
    fi

    draw_header
    echo -e "${C_RED}${C_BOLD}🗑️ Remove Distro${C_RESET}"
    echo ""

    local i=1
    for d in "${distros[@]}"; do
        echo "  $i) $d"
        ((i++))
    done
    echo "  0) Cancel"
    echo ""

    read -rp "Select distro to remove: " choice
    choice=$(sanitize_input "$choice")

    if [[ "$choice" == "0" ]]; then
        return
    fi

    if ! validate_number "$choice" 1 "${#distros[@]}"; then
        show_error "Invalid selection"
        press_enter
        return
    fi

    local selected="${distros[$((choice-1))]}"

    echo ""
    echo -e "${C_RED}⚠️  This will PERMANENTLY DELETE all data in $selected.${C_RESET}"
    read -rp "Type the distro name to confirm [$selected]: " confirm

    if [[ "$confirm" != "$selected" ]]; then
        show_info "Removal cancelled."
        press_enter
        return
    fi

    log_info "Removing distro: $selected"

    if command -v proot-distro >/dev/null 2>&1; then
        proot-distro remove "$selected" 2>&1 || {
            show_error "Failed to remove $selected via proot-distro. Trying manual removal..."
            local path
            path=$(get_distro_rootfs_path "$selected")
            if [[ -n "$path" && -d "$path" ]]; then
                rm -rf "$path"
                show_success "$selected removed manually."
            else
                show_error "Could not find $selected installation."
            fi
        }
    else
        local path
        path=$(get_distro_rootfs_path "$selected")
        if [[ -n "$path" && -d "$path" ]]; then
            rm -rf "$path"
            show_success "$selected removed."
        fi
    fi

    log_recent "REMOVE_DISTRO" "$selected"
    press_enter
}

# --- Distro Info ---
distro_info() {
    local distros=()
    while IFS= read -r d; do
        [[ -n "$d" ]] && distros+=("$d")
    done < <(list_installed_distros)

    if [[ ${#distros[@]} -eq 0 ]]; then
        show_error "No distros installed."
        press_enter
        return
    fi

    draw_header
    echo -e "${C_CYAN}${C_BOLD}ℹ️ Distro Info${C_RESET}"
    echo ""

    local i=1
    for d in "${distros[@]}"; do
        echo "  $i) $d"
        ((i++))
    done
    echo "  0) Cancel"
    echo ""

    read -rp "Select distro: " choice
    choice=$(sanitize_input "$choice")

    if [[ "$choice" == "0" ]]; then
        return
    fi

    if ! validate_number "$choice" 1 "${#distros[@]}"; then
        show_error "Invalid selection"
        press_enter
        return
    fi

    local selected="${distros[$((choice-1))]}"
    local path
    path=$(get_distro_rootfs_path "$selected")

    draw_header
    echo -e "${C_CYAN}${C_BOLD}📊 $selected Information${C_RESET}"
    echo ""

    if [[ -n "$path" && -d "$path" ]]; then
        echo -e "${C_GREEN}Status:${C_RESET} Installed"
        echo -e "${C_GREEN}Path:${C_RESET} $path"

        local size
        size=$(du -sh "$path" 2>/dev/null | cut -f1 || echo "unknown")
        echo -e "${C_GREEN}Size:${C_RESET} $size"

        local pd_version
        pd_version=$(detect_proot_distro_version)
        echo -e "${C_GREEN}Proot-distro format:${C_RESET} $pd_version"
    else
        echo -e "${C_YELLOW}Status: Path not found${C_RESET}"
    fi

    echo ""
    press_enter
}

# --- Repair Distro ---
repair_distro() {
    local distros=()
    while IFS= read -r d; do
        [[ -n "$d" ]] && distros+=("$d")
    done < <(list_installed_distros)

    if [[ ${#distros[@]} -eq 0 ]]; then
        show_error "No distros installed."
        press_enter
        return
    fi

    draw_header
    echo -e "${C_CYAN}${C_BOLD}🔧 Repair Distro${C_RESET}"
    echo ""

    local i=1
    for d in "${distros[@]}"; do
        echo "  $i) $d"
        ((i++))
    done
    echo "  0) Cancel"
    echo ""

    read -rp "Select distro: " choice
    choice=$(sanitize_input "$choice")

    if [[ "$choice" == "0" ]]; then
        return
    fi

    if ! validate_number "$choice" 1 "${#distros[@]}"; then
        show_error "Invalid selection"
        press_enter
        return
    fi

    local selected="${distros[$((choice-1))]}"

    echo ""
    echo -e "${C_BLUE}Repairing $selected...${C_RESET}"
    echo "  1) Fix broken packages"
    echo "  2) Reinstall base system"
    echo "  3) Fix permissions"
    echo "  0) Cancel"
    echo ""

    read -rp "Select repair option: " repair_choice
    repair_choice=$(sanitize_input "$repair_choice")

    case "$repair_choice" in
        1)
            proot-distro login "$selected" -- bash -c '
                if command -v apt >/dev/null 2>&1; then
                    apt --fix-broken install -y
                elif command -v pacman >/dev/null 2>&1; then
                    pacman -Syu --noconfirm
                elif command -v dnf >/dev/null 2>&1; then
                    dnf distro-sync -y
                fi
            '
            show_success "Package repair attempted."
            ;;
        2)
            echo -e "${C_YELLOW}This will reinstall the base system packages.${C_RESET}"
            read -rp "Continue? [y/N] " confirm
            if [[ "$confirm" =~ ^[Yy]$ ]]; then
                proot-distro login "$selected" -- bash -c '
                    if command -v apt >/dev/null 2>&1; then
                        apt update && apt install --reinstall -y $(dpkg -l | grep ^ii | awk "{print \$2}")
                    fi
                '
            fi
            ;;
        3)
            local path
            path=$(get_distro_rootfs_path "$selected")
            if [[ -n "$path" ]]; then
                proot-distro login "$selected" -- bash -c 'chmod -R 755 /usr/bin /bin /usr/lib /lib 2>/dev/null || true'
                show_success "Permissions fixed."
            fi
            ;;
        0) return ;;
        *) show_error "Invalid choice" ;;
    esac

    log_recent "REPAIR_DISTRO" "$selected"
    press_enter
}

# --- Export/Import ---
export_import_distro() {
    draw_header
    echo -e "${C_CYAN}${C_BOLD}📦 Export / Import Distro${C_RESET}"
    echo ""
    echo "  1) Export distro to tar archive"
    echo "  2) Import distro from tar archive"
    echo "  0) Back"
    echo ""

    read -rp "Enter choice: " choice
    choice=$(sanitize_input "$choice")

    case "$choice" in
        1)
            local distros=()
            while IFS= read -r d; do
                [[ -n "$d" ]] && distros+=("$d")
            done < <(list_installed_distros)

            if [[ ${#distros[@]} -eq 0 ]]; then
                show_error "No distros to export."
                press_enter
                return
            fi

            echo ""
            local i=1
            for d in "${distros[@]}"; do
                echo "  $i) $d"
                ((i++))
            done
            echo ""

            read -rp "Select distro to export: " echoice
            echoice=$(sanitize_input "$echoice")

            if ! validate_number "$echoice" 1 "${#distros[@]}"; then
                show_error "Invalid selection"
                press_enter
                return
            fi

            local selected="${distros[$((echoice-1))]}"
            local export_path="$HOME/${selected}-backup-$(date +%Y%m%d).tar.gz"
            local path
            path=$(get_distro_rootfs_path "$selected")

            if [[ -n "$path" ]]; then
                echo ""
                echo -e "${C_BLUE}Exporting $selected to $export_path...${C_RESET}"
                tar -czf "$export_path" -C "$(dirname "$path")" "$(basename "$path")" 2>&1 || {
                    show_error "Export failed"
                    press_enter
                    return
                }
                show_success "Exported to $export_path"
                log_recent "EXPORT_DISTRO" "$selected -> $export_path"
            fi
            ;;
        2)
            echo ""
            read -rp "Enter path to tar.gz archive: " archive_path
            if [[ ! -f "$archive_path" ]]; then
                show_error "File not found: $archive_path"
                press_enter
                return
            fi

            read -rp "Enter name for imported distro: " import_name
            if [[ -z "$import_name" ]]; then
                show_error "Name cannot be empty"
                press_enter
                return
            fi

            local runtime_dir="${RUNTIME_DIR:-$PREFIX/var/lib}"
            local target="$runtime_dir/proot-distro/installed-rootfs/$import_name"

            echo ""
            echo -e "${C_BLUE}Importing to $target...${C_RESET}"
            mkdir -p "$target"
            tar -xzf "$archive_path" -C "$target" --strip-components=1 2>&1 || {
                show_error "Import failed"
                press_enter
                return
            }
            show_success "Imported as $import_name"
            log_recent "IMPORT_DISTRO" "$archive_path -> $import_name"
            ;;
        0) return ;;
        *) show_error "Invalid choice" ;;
    esac

    press_enter
}

# --- Clone Distro ---
clone_distro() {
    local distros=()
    while IFS= read -r d; do
        [[ -n "$d" ]] && distros+=("$d")
    done < <(list_installed_distros)

    if [[ ${#distros[@]} -eq 0 ]]; then
        show_error "No distros installed."
        press_enter
        return
    fi

    draw_header
    echo -e "${C_CYAN}${C_BOLD}📋 Clone Distro${C_RESET}"
    echo ""

    local i=1
    for d in "${distros[@]}"; do
        echo "  $i) $d"
        ((i++))
    done
    echo ""

    read -rp "Select distro to clone: " choice
    choice=$(sanitize_input "$choice")

    if ! validate_number "$choice" 1 "${#distros[@]}"; then
        show_error "Invalid selection"
        press_enter
        return
    fi

    local source_distro="${distros[$((choice-1))]}"

    read -rp "Enter name for clone: " clone_name
    if [[ -z "$clone_name" ]]; then
        show_error "Name cannot be empty"
        press_enter
        return
    fi

    local pd_version
    pd_version=$(detect_proot_distro_version)

    if [[ "$pd_version" == "new" ]]; then
        proot-distro copy --recursive "$source_distro" "$clone_name" 2>&1 || {
            show_error "Clone failed via proot-distro. Trying manual copy..."
            manual_clone "$source_distro" "$clone_name"
        }
    else
        manual_clone "$source_distro" "$clone_name"
    fi

    show_success "Cloned $source_distro to $clone_name"
    log_recent "CLONE_DISTRO" "$source_distro -> $clone_name"
    press_enter
}

manual_clone() {
    local source="$1"
    local target="$2"
    local source_path
    source_path=$(get_distro_rootfs_path "$source")
    local runtime_dir="${RUNTIME_DIR:-$PREFIX/var/lib}"
    local target_path="$runtime_dir/proot-distro/installed-rootfs/$target"

    if [[ -n "$source_path" && -d "$source_path" ]]; then
        mkdir -p "$target_path"
        cp -a "$source_path/"* "$target_path/" 2>/dev/null || {
            show_error "Manual copy failed. Check disk space."
            return 1
        }
    else
        show_error "Source distro path not found"
        return 1
    fi
}

# --- Backup/Restore ---
backup_restore_distro() {
    draw_header
    echo -e "${C_CYAN}${C_BOLD}💾 Backup / Restore${C_RESET}"
    echo ""
    echo "  1) Backup distro (proot-distro backup)"
    echo "  2) Restore distro (proot-distro restore)"
    echo "  0) Back"
    echo ""

    read -rp "Enter choice: " choice
    choice=$(sanitize_input "$choice")

    case "$choice" in
        1)
            local distros=()
            while IFS= read -r d; do
                [[ -n "$d" ]] && distros+=("$d")
            done < <(list_installed_distros)

            if [[ ${#distros[@]} -eq 0 ]]; then
                show_error "No distros to backup."
                press_enter
                return
            fi

            echo ""
            local i=1
            for d in "${distros[@]}"; do
                echo "  $i) $d"
                ((i++))
            done
            echo ""

            read -rp "Select distro to backup: " bchoice
            bchoice=$(sanitize_input "$bchoice")

            if ! validate_number "$bchoice" 1 "${#distros[@]}"; then
                show_error "Invalid selection"
                press_enter
                return
            fi

            local selected="${distros[$((bchoice-1))]}"
            local pd_version
            pd_version=$(detect_proot_distro_version)

            if [[ "$pd_version" == "new" ]]; then
                proot-distro backup "$selected" 2>&1 || {
                    show_error "Backup failed"
                    press_enter
                    return
                }
            else
                export_import_distro
                return
            fi

            show_success "Backup of $selected completed"
            log_recent "BACKUP_DISTRO" "$selected"
            ;;
        2)
            echo ""
            echo -e "${C_YELLOW}Restore using proot-distro restore <backup-file>${C_RESET}"
            read -rp "Enter backup file path: " backup_file
            if [[ ! -f "$backup_file" ]]; then
                show_error "File not found"
                press_enter
                return
            fi
            proot-distro restore "$backup_file" 2>&1 || {
                show_error "Restore failed"
                press_enter
                return
            }
            show_success "Restore completed"
            log_recent "RESTORE_DISTRO" "$backup_file"
            ;;
        0) return ;;
        *) show_error "Invalid choice" ;;
    esac

    press_enter
}
