#!/usr/bin/env bash
# =============================================================================
# Devil's Mini OS Launcher - recent_actions.sh
# Version: v1.1.0
# Purpose: Show recent user activity
# =============================================================================

recent_actions_menu() {
    draw_header
    echo -e "${C_CYAN}${C_BOLD}📋 Recent Actions${C_RESET}"
    echo ""

    local recent_log="$DMOL_CONFIG_DIR/recent.log"

    if [[ -f "$recent_log" ]]; then
        tail -n 20 "$recent_log"
    else
        echo -e "${C_DIM}No recent actions recorded${C_RESET}"
    fi

    echo ""
    press_enter
}
