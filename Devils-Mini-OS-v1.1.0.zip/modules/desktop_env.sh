#!/usr/bin/env bash
# =============================================================================
# Devil's Mini OS Launcher - desktop_env.sh
# Version: v1.1.0
# Purpose: Desktop environment installation in proot distros with tier system
# =============================================================================

# --- Desktop Database (14 core + 34 optional = 48 total) ---
declare -A ALL_DESKTOPS=(
    # Tier 1: Verified, lightweight, no systemd
    ["xfce4"]="XFCE4:Lightweight and fast:xfce4 xfce4-goodies:no-systemd:tier1"
    ["lxqt"]="LXQt:Qt-based lightweight:lxqt sddm:no-systemd:tier1"
    ["lxde"]="LXDE:Ultra-lightweight:lxde:no-systemd:tier1"
    ["mate"]="MATE:Classic GNOME 2 fork:mate-desktop-environment:no-systemd:tier1"
    ["i3wm"]="i3wm:Tiling window manager:i3:i3wm:no-systemd:tier1"
    ["openbox"]="Openbox:Minimal stacking WM:openbox obconf:no-systemd:tier1"
    ["fluxbox"]="Fluxbox:Lightweight stacking WM:fluxbox:no-systemd:tier1"
    ["jwm"]="JWM:Joe's Window Manager:jwm:no-systemd:tier1"

    # Tier 2: Community-tested, no systemd
    ["sway"]="Sway:Wayland i3 clone:sway:no-systemd:tier2"
    ["awesome"]="Awesome:Dynamic tiling WM:awesome:no-systemd:tier2"
    ["bspwm"]="BSPWM:Binary space partitioning WM:bspwm sxhkd:no-systemd:tier2"
    ["dwm"]="DWM:Dynamic window manager:dwm:no-systemd:tier2"
    ["xmonad"]="XMonad:Haskell tiling WM:xmonad:no-systemd:tier2"
    ["qtile"]="Qtile:Python tiling WM:qtile:no-systemd:tier2"
    ["herbstluftwm"]="Herbstluftwm:Manual tiling WM:herbstluftwm:no-systemd:tier2"
    ["spectrwm"]="SpectrWM:Dynamic tiling WM:spectrwm:no-systemd:tier2"
    ["ratpoison"]="Ratpoison:Keyboard-driven WM:ratpoison:no-systemd:tier2"
    ["stumpwm"]="StumpWM:Common Lisp tiling WM:stumpwm:no-systemd:tier2"
    ["icewm"]="IceWM:Lightweight stacking WM:icewm:no-systemd:tier2"
    ["pekwm"]="PekWM:Lightweight stacking WM:pekwm:no-systemd:tier2"
    ["blackbox"]="Blackbox:Minimal stacking WM:blackbox:no-systemd:tier2"
    ["windowmaker"]="Window Maker:NeXTSTEP-like WM:wmaker:no-systemd:tier2"
    ["enlightenment"]="Enlightenment:Beautiful WM:enlightenment:no-systemd:tier2"
    ["afterstep"]="AfterStep:NeXTSTEP-like WM:afterstep:no-systemd:tier2"
    ["fvwm"]="FVWM:Virtual window manager:fvwm:no-systemd:tier2"
    ["twm"]="TWM:Tab window manager:twm:no-systemd:tier2"
    ["cwm"]="CWM:Calm window manager:cwm:no-systemd:tier2"
    ["labwc"]="Labwc:Wayland stacking compositor:labwc:no-systemd:tier2"

    # Tier 3: Needs systemd or heavy resources
    ["kde-plasma"]="KDE Plasma:Full-featured desktop:plasma-desktop:kde:tier3"
    ["gnome"]="GNOME:Modern desktop:gnome-core:needs-systemd:tier3"
    ["cinnamon"]="Cinnamon:GNOME 3 fork:cinnamon:needs-systemd:tier3"
    ["deepin"]="Deepin:Beautiful Chinese desktop:deepin-desktop:needs-systemd:tier3"
    ["budgie"]="Budgie:Solus desktop:budgie-desktop:needs-systemd:tier3"
    ["pantheon"]="Pantheon:elementary OS desktop:pantheon-desktop:needs-systemd:tier3"
    ["cosmic"]="COSMIC:System76 desktop:cosmic-session:needs-systemd:tier3"
    ["hyprland"]="Hyprland:Dynamic Wayland compositor:hyprland:needs-systemd:tier3"
    ["river"]="River:Wayland tiling compositor:river:needs-systemd:tier3"
    ["niri"]="Niri:Scrollable Wayland compositor:niri:needs-systemd:tier3"
)

desktop_env_menu() {
    while true; do
        draw_header
        echo -e "${C_CYAN}${C_BOLD}🖥️ Desktop Environments${C_RESET}"
        echo ""

        echo -e "${C_YELLOW}⚠️  Proot Limitation Notice:${C_RESET}"
        echo "Some desktops require systemd which does NOT work in proot."
        echo "Tier 1/2 desktops are recommended for proot."
        echo ""

        echo "  1) Install Desktop Environment"
        echo "  2) List All Desktops (with tiers)"
        echo "  3) Search Desktops"
        echo "  0) Back to Main Menu"
        echo ""

        read -rp "Enter choice: " choice
        choice=$(sanitize_input "$choice")

        case "$choice" in
            1) install_desktop_menu ;;
            2) list_all_desktops ;;
            3) search_desktops ;;
            0) return ;;
            *) show_error "Invalid choice"; press_enter ;;
        esac
    done
}

install_desktop_menu() {
    # Select target distro first
    local distros=()
    while IFS= read -r d; do
        [[ -n "$d" ]] && distros+=("$d")
    done < <(source "$SCRIPT_DIR/modules/linux_env.sh" && list_installed_distros 2>/dev/null || true)

    # Fallback
    if [[ ${#distros[@]} -eq 0 ]]; then
        local runtime_dir="${RUNTIME_DIR:-$PREFIX/var/lib}"
        if [[ -d "$runtime_dir/proot-distro/installed-rootfs" ]]; then
            for d in "$runtime_dir/proot-distro/installed-rootfs"/*/; do
                [[ -d "$d" ]] && distros+=("$(basename "$d")")
            done
        fi
        if [[ -d "$runtime_dir/proot-distro/containers" ]]; then
            for d in "$runtime_dir/proot-distro/containers"/*/; do
                local name
                name=$(basename "$d")
                local found=false
                for existing in "${distros[@]}"; do
                    [[ "$existing" == "$name" ]] && found=true
                done
                [[ "$found" == false ]] && distros+=("$name")
            done
        fi
    fi

    if [[ ${#distros[@]} -eq 0 ]]; then
        show_error "No proot distros installed. Install one first."
        press_enter
        return
    fi

    draw_header
    echo -e "${C_CYAN}${C_BOLD}🖥️ Install Desktop Environment${C_RESET}"
    echo ""
    echo "Select target distro:"
    local i=1
    for d in "${distros[@]}"; do
        echo "  $i) $d"
        ((i++))
    done
    echo "  0) Cancel"
    echo ""

    read -rp "Select distro: " dchoice
    dchoice=$(sanitize_input "$dchoice")

    if [[ "$dchoice" == "0" ]]; then
        return
    fi

    if ! validate_number "$dchoice" 1 "${#distros[@]}"; then
        show_error "Invalid selection"
        press_enter
        return
    fi

    local target_distro="${distros[$((dchoice-1))]}"
    install_desktop "$target_distro"
}

install_desktop() {
    local target_distro="$1"

    while true; do
        draw_header
        echo -e "${C_CYAN}${C_BOLD}🖥️ Install Desktop in $target_distro${C_RESET}"
        echo ""

        echo -e "${C_GREEN}Tier 1 — Verified (recommended for proot)${C_RESET}"
        local tier1_keys=()
        for key in "${!ALL_DESKTOPS[@]}"; do
            local data="${ALL_DESKTOPS[$key]}"
            local tier
            tier=$(echo "$data" | rev | cut -d: -f1 | rev)
            if [[ "$tier" == "tier1" ]]; then
                tier1_keys+=("$key")
            fi
        done

        IFS=$'\n' sorted_tier1=($(sort <<<"${tier1_keys[*]}")); unset IFS
        local i=1
        for key in "${sorted_tier1[@]}"; do
            local data="${ALL_DESKTOPS[$key]}"
            local name desc
            name=$(echo "$data" | cut -d: -f1)
            desc=$(echo "$data" | cut -d: -f2)
            printf "  %2d) %-20s %s\n" "$i" "$name" "$desc"
            ((i++))
        done

        echo ""
        echo -e "${C_YELLOW}Tier 2 — Community-tested${C_RESET}"
        local tier2_keys=()
        for key in "${!ALL_DESKTOPS[@]}"; do
            local data="${ALL_DESKTOPS[$key]}"
            local tier
            tier=$(echo "$data" | rev | cut -d: -f1 | rev)
            if [[ "$tier" == "tier2" ]]; then
                tier2_keys+=("$key")
            fi
        done

        IFS=$'\n' sorted_tier2=($(sort <<<"${tier2_keys[*]}")); unset IFS
        for key in "${sorted_tier2[@]}"; do
            local data="${ALL_DESKTOPS[$key]}"
            local name desc
            name=$(echo "$data" | cut -d: -f1)
            desc=$(echo "$data" | cut -d: -f2)
            printf "  %2d) %-20s %s\n" "$i" "$name" "$desc"
            ((i++))
        done

        echo ""
        echo -e "${C_RED}Tier 3 — Experimental (may fail in proot)${C_RESET}"
        local tier3_keys=()
        for key in "${!ALL_DESKTOPS[@]}"; do
            local data="${ALL_DESKTOPS[$key]}"
            local tier
            tier=$(echo "$data" | rev | cut -d: -f1 | rev)
            if [[ "$tier" == "tier3" ]]; then
                tier3_keys+=("$key")
            fi
        done

        IFS=$'\n' sorted_tier3=($(sort <<<"${tier3_keys[*]}")); unset IFS
        for key in "${sorted_tier3[@]}"; do
            local data="${ALL_DESKTOPS[$key]}"
            local name desc
            name=$(echo "$data" | cut -d: -f1)
            desc=$(echo "$data" | cut -d: -f2)
            printf "  %2d) %-20s %s\n" "$i" "$name" "$desc"
            ((i++))
        done

        local total=$(( ${#sorted_tier1[@]} + ${#sorted_tier2[@]} + ${#sorted_tier3[@]} ))

        echo ""
        echo "Enter number to install"
        echo "  0) Cancel"
        echo ""

        read -rp "Select: " choice
        choice=$(sanitize_input "$choice")

        if [[ "$choice" == "0" ]]; then
            return
        fi

        if ! validate_number "$choice" 1 "$total"; then
            show_error "Invalid selection"
            press_enter
            continue
        fi

        # Find the selected desktop
        local selected_key=""
        local all_keys=("${sorted_tier1[@]}" "${sorted_tier2[@]}" "${sorted_tier3[@]}")
        selected_key="${all_keys[$((choice-1))]}"

        local data="${ALL_DESKTOPS[$selected_key]}"
        local name desc packages systemd_flag tier
        name=$(echo "$data" | cut -d: -f1)
        desc=$(echo "$data" | cut -d: -f2)
        packages=$(echo "$data" | cut -d: -f3)
        systemd_flag=$(echo "$data" | cut -d: -f4)
        tier=$(echo "$data" | rev | cut -d: -f1 | rev)

        # Warnings
        echo ""
        if [[ "$systemd_flag" == "needs-systemd" ]]; then
            echo -e "${C_RED}╔════════════════════════════════════════════════════════════╗${C_RESET}"
            echo -e "${C_RED}║  ⚠️  SYSTEMD WARNING                                      ║${C_RESET}"
            echo -e "${C_RED}║                                                            ║${C_RESET}"
            echo -e "${C_RED}║  $name requires systemd, which does NOT work in proot.  ║${C_RESET}"
            echo -e "${C_RED}║  It will likely fail to start or function correctly.     ║${C_RESET}"
            echo -e "${C_RED}╚════════════════════════════════════════════════════════════╝${C_RESET}"
            echo ""
            read -rp "Continue anyway? [y/N] " confirm
            if [[ ! "$confirm" =~ ^[Yy]$ ]]; then
                continue
            fi
        elif [[ "$tier" == "tier3" ]]; then
            echo -e "${C_YELLOW}⚠️  This desktop may not work correctly in proot. Continue at your own risk.${C_RESET}"
            read -rp "Continue? [y/N] " confirm
            if [[ ! "$confirm" =~ ^[Yy]$ ]]; then
                continue
            fi
        fi

        # Battery check for heavy installs
        if ! check_battery_before_heavy_op; then
            press_enter
            continue
        fi

        echo ""
        echo -e "${C_BLUE}Installing $name in $target_distro...${C_RESET}"
        echo -e "${C_DIM}Packages: $packages${C_RESET}"
        echo ""

        # Install via unified package manager
        if source "$SCRIPT_DIR/modules/proot_apps.sh" 2>/dev/null; then
            pkg_install "$target_distro" "$packages" 2>&1 || {
                show_error "Installation failed. The packages may not be available in this distro."
                press_enter
                continue
            }
        else
            # Fallback: try apt directly
            proot-distro login "$target_distro" -- bash -c "apt update && apt install -y $packages" 2>&1 || {
                show_error "Installation failed"
                press_enter
                continue
            }
        fi

        # Configure .xsession and .vnc/xstartup
        configure_desktop_session "$target_distro" "$selected_key" "$name"

        show_success "$name installed in $target_distro!"
        log_recent "INSTALL_DESKTOP" "$name in $target_distro"
        press_enter
        return
    done
}

configure_desktop_session() {
    local distro="$1"
    local key="$2"
    local desktop_name="$3"

    # Determine session command based on desktop
    local session_cmd=""
    case "$key" in
        xfce4) session_cmd="startxfce4" ;;
        lxqt) session_cmd="startlxqt" ;;
        lxde) session_cmd="startlxde" ;;
        mate) session_cmd="mate-session" ;;
        i3wm|i3) session_cmd="i3" ;;
        openbox) session_cmd="openbox-session" ;;
        fluxbox) session_cmd="startfluxbox" ;;
        jwm) session_cmd="jwm" ;;
        sway) session_cmd="sway" ;;
        awesome) session_cmd="awesome" ;;
        bspwm) session_cmd="bspwm" ;;
        dwm) session_cmd="dwm" ;;
        xmonad) session_cmd="xmonad" ;;
        qtile) session_cmd="qtile start" ;;
        herbstluftwm) session_cmd="herbstluftwm" ;;
        spectrwm) session_cmd="spectrwm" ;;
        ratpoison) session_cmd="ratpoison" ;;
        stumpwm) session_cmd="stumpwm" ;;
        icewm) session_cmd="icewm-session" ;;
        pekwm) session_cmd="pekwm" ;;
        blackbox) session_cmd="blackbox" ;;
        windowmaker) session_cmd="wmaker" ;;
        enlightenment) session_cmd="enlightenment_start" ;;
        afterstep) session_cmd="afterstep" ;;
        fvwm) session_cmd="fvwm" ;;
        twm) session_cmd="twm" ;;
        cwm) session_cmd="cwm" ;;
        labwc) session_cmd="labwc" ;;
        kde-plasma) session_cmd="startplasma-x11" ;;
        gnome) session_cmd="gnome-session" ;;
        cinnamon) session_cmd="cinnamon-session" ;;
        deepin) session_cmd="startdde" ;;
        budgie) session_cmd="budgie-desktop" ;;
        pantheon) session_cmd="pantheon-session" ;;
        cosmic) session_cmd="cosmic-session" ;;
        hyprland) session_cmd="Hyprland" ;;
        river) session_cmd="river" ;;
        niri) session_cmd="niri" ;;
    esac

    if [[ -n "$session_cmd" ]]; then
        proot-distro login "$distro" -- bash -c "
            mkdir -p ~/.vnc
            echo '#!/bin/bash' > ~/.vnc/xstartup
            echo 'export DISPLAY=:\1' >> ~/.vnc/xstartup
            echo 'xrdb ~/.Xresources 2>/dev/null' >> ~/.vnc/xstartup
            echo '$session_cmd &' >> ~/.vnc/xstartup
            chmod +x ~/.vnc/xstartup

            echo '#!/bin/bash' > ~/.xsession
            echo 'xrdb ~/.Xresources 2>/dev/null' >> ~/.xsession
            echo '$session_cmd' >> ~/.xsession
            chmod +x ~/.xsession
        " 2>/dev/null || true
    fi
}

list_all_desktops() {
    draw_header
    echo -e "${C_CYAN}${C_BOLD}🖥️ All Desktop Environments${C_RESET}"
    echo ""

    echo -e "${C_GREEN}${C_BOLD}=== Tier 1 — Verified (8 desktops) ===${C_RESET}"
    for key in "${!ALL_DESKTOPS[@]}"; do
        local data="${ALL_DESKTOPS[$key]}"
        local tier
        tier=$(echo "$data" | rev | cut -d: -f1 | rev)
        if [[ "$tier" == "tier1" ]]; then
            local name desc
            name=$(echo "$data" | cut -d: -f1)
            desc=$(echo "$data" | cut -d: -f2)
            echo "  ✅ $name — $desc"
        fi
    done

    echo ""
    echo -e "${C_YELLOW}${C_BOLD}=== Tier 2 — Community-tested (20 desktops) ===${C_RESET}"
    for key in "${!ALL_DESKTOPS[@]}"; do
        local data="${ALL_DESKTOPS[$key]}"
        local tier
        tier=$(echo "$data" | rev | cut -d: -f1 | rev)
        if [[ "$tier" == "tier2" ]]; then
            local name desc
            name=$(echo "$data" | cut -d: -f1)
            desc=$(echo "$data" | cut -d: -f2)
            echo "  ⚡ $name — $desc"
        fi
    done

    echo ""
    echo -e "${C_RED}${C_BOLD}=== Tier 3 — Experimental (20 desktops) ===${C_RESET}"
    for key in "${!ALL_DESKTOPS[@]}"; do
        local data="${ALL_DESKTOPS[$key]}"
        local tier
        tier=$(echo "$data" | rev | cut -d: -f1 | rev)
        if [[ "$tier" == "tier3" ]]; then
            local name desc
            name=$(echo "$data" | cut -d: -f1)
            desc=$(echo "$data" | cut -d: -f2)
            echo "  ⚠️ $name — $desc"
        fi
    done

    echo ""
    press_enter
}

search_desktops() {
    echo ""
    read -rp "Search: " query
    query=$(sanitize_input "$query")

    if [[ -z "$query" ]]; then
        show_error "Search query cannot be empty"
        press_enter
        return
    fi

    draw_header
    echo -e "${C_CYAN}${C_BOLD}🔍 Search Results: '$query'${C_RESET}"
    echo ""

    local found=false
    for key in "${!ALL_DESKTOPS[@]}"; do
        local data="${ALL_DESKTOPS[$key]}"
        local name desc
        name=$(echo "$data" | cut -d: -f1)
        desc=$(echo "$data" | cut -d: -f2)

        if [[ "$name" == *"$query"* || "$desc" == *"$query"* || "$key" == *"$query"* ]]; then
            local tier
            tier=$(echo "$data" | rev | cut -d: -f1 | rev)
            local icon="⚠️"
            [[ "$tier" == "tier1" ]] && icon="✅"
            [[ "$tier" == "tier2" ]] && icon="⚡"
            echo "  $icon $name — $desc"
            found=true
        fi
    done

    if [[ "$found" == false ]]; then
        echo -e "${C_DIM}No results found${C_RESET}"
    fi

    echo ""
    press_enter
}
