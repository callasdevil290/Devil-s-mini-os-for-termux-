#!/usr/bin/env bash
# =============================================================================
# Devil's Mini OS Launcher - update_all.sh
# Version: v1.1.0
# Purpose: Update all system components
# =============================================================================

update_all_menu() {
    while true; do
        draw_header
        echo -e "${C_CYAN}${C_BOLD}🔄 Update All${C_RESET}"
        echo ""
        echo "  1) Update Termux Native"
        echo "  2) Update Proot Distros"
        echo "  3) Update Nix Packages"
        echo "  4) Update Launcher (git pull)"
        echo "  5) Update All"
        echo "  6) Check for Updates (dry run)"
        echo "  0) Back to Main Menu"
        echo ""

        read -rp "Enter choice: " choice
        choice=$(sanitize_input "$choice")

        case "$choice" in
            1) update_termux_native ;;
            2) update_proot_distros ;;
            3) update_nix_packages ;;
            4) update_launcher ;;
            5) update_all ;;
            6) check_updates ;;
            0) return ;;
            *) show_error "Invalid choice"; press_enter ;;
        esac
    done
}

update_termux_native() {
    if [[ "$(detect_platform)" != "termux" ]]; then
        show_error "Not running in Termux"
        press_enter
        return
    fi

    echo ""
    echo -e "${C_BLUE}Updating Termux packages...${C_RESET}"
    pkg update -y 2>&1 || show_error "Update failed"
    echo ""
    echo -e "${C_BLUE}Upgrading Termux packages...${C_RESET}"
    pkg upgrade -y 2>&1 || show_error "Upgrade failed"

    show_success "Termux updated"
    log_recent "UPDATE_TERMUX" ""
    press_enter
}

update_proot_distros() {
    local distros=()
    while IFS= read -r d; do
        [[ -n "$d" ]] && distros+=("$d")
    done < <(source "$SCRIPT_DIR/modules/linux_env.sh" && list_installed_distros 2>/dev/null || true)

    if [[ ${#distros[@]} -eq 0 ]]; then
        show_error "No proot distros installed"
        press_enter
        return
    fi

    echo ""
    for d in "${distros[@]}"; do
        echo -e "${C_BLUE}Updating $d...${C_RESET}"
        if source "$SCRIPT_DIR/modules/proot_apps.sh" 2>/dev/null; then
            pkg_update "$d" 2>&1 || show_error "Update failed for $d"
            pkg_upgrade "$d" 2>&1 || show_error "Upgrade failed for $d"
        else
            proot-distro login "$d" -- bash -c "apt update && apt upgrade -y" 2>&1 || show_error "Update failed for $d"
        fi
        echo ""
    done

    show_success "Proot distros updated"
    log_recent "UPDATE_PROOT_DISTROS" "${distros[*]}"
    press_enter
}

update_nix_packages() {
    local distros=()
    while IFS= read -r d; do
        [[ -n "$d" ]] && distros+=("$d")
    done < <(source "$SCRIPT_DIR/modules/linux_env.sh" && list_installed_distros 2>/dev/null || true)

    if [[ ${#distros[@]} -eq 0 ]]; then
        show_error "No proot distros installed"
        press_enter
        return
    fi

    echo ""
    for d in "${distros[@]}"; do
        echo -e "${C_BLUE}Updating Nix in $d...${C_RESET}"
        proot-distro login "$d" -- bash -c "
            . ~/.nix-profile/etc/profile.d/nix.sh 2>/dev/null
            nix-channel --update 2>/dev/null
            nix-env -u 2>/dev/null
        " 2>/dev/null || echo "  Nix not installed in $d"
        echo ""
    done

    show_success "Nix packages updated"
    log_recent "UPDATE_NIX" ""
    press_enter
}

update_launcher() {
    echo ""
    if [[ -d "$SCRIPT_DIR/.git" ]]; then
        echo -e "${C_BLUE}Updating Devil's Mini OS...${C_RESET}"
        cd "$SCRIPT_DIR" && git pull --ff-only 2>&1 || {
            show_error "git pull failed. You may need to resolve conflicts manually."
            press_enter
            return
        }
        show_success "Launcher updated! Restart to apply changes."
        log_recent "UPDATE_LAUNCHER" "git pull"
    else
        show_error "Not a git repository. Cannot auto-update."
    fi
    press_enter
}

update_all() {
    update_termux_native
    update_proot_distros
    update_nix_packages
    show_success "All updates completed!"
}

check_updates() {
    echo ""
    echo -e "${C_CYAN}Checking for updates...${C_RESET}"
    echo ""

    if [[ "$(detect_platform)" == "termux" ]]; then
        echo "Termux packages:"
        pkg update --dry-run 2>/dev/null || apt list --upgradable 2>/dev/null | head -10 || echo "  (dry run not supported)"
    fi

    echo ""
    echo "Launcher:"
    if [[ -d "$SCRIPT_DIR/.git" ]]; then
        cd "$SCRIPT_DIR" && git fetch 2>/dev/null && git log HEAD..origin/HEAD --oneline 2>/dev/null | head -5 || echo "  No updates available or not connected"
    else
        echo "  Not a git repository"
    fi

    press_enter
}
