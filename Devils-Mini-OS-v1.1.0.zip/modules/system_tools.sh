#!/usr/bin/env bash
# =============================================================================
# Devil's Mini OS Launcher - system_tools.sh
# Version: v1.1.0
# Purpose: System maintenance with Linux service fallback
# =============================================================================

system_tools_menu() {
    while true; do
        draw_header
        echo -e "${C_CYAN}${C_BOLD}⚡ System Tools${C_RESET}"
        echo ""
        echo "  1) Backup & Restore"
        echo "  2) Boost Performance"
        echo "  3) Clean Cache & Temp"
        echo "  4) Network Info"
        echo "  5) Storage Analyzer"
        echo "  6) Process Manager"
        echo "  7) Service Manager"
        echo "  8) Kill All Services"
        echo "  0) Back to Main Menu"
        echo ""

        read -rp "Enter choice: " choice
        choice=$(sanitize_input "$choice")

        case "$choice" in
            1) backup_restore_menu ;;
            2) boost_performance ;;
            3) clean_cache ;;
            4) network_info ;;
            5) storage_analyzer ;;
            6) process_manager ;;
            7) service_manager ;;
            8) kill_all_services ;;
            0) return ;;
            *) show_error "Invalid choice"; press_enter ;;
        esac
    done
}

backup_restore_menu() {
    while true; do
        draw_header
        echo -e "${C_CYAN}${C_BOLD}💾 Backup & Restore${C_RESET}"
        echo ""
        echo "  1) Backup Termux config"
        echo "  2) Restore Termux config"
        echo "  0) Back"
        echo ""

        read -rp "Enter choice: " choice
        choice=$(sanitize_input "$choice")

        case "$choice" in
            1) backup_termux ;;
            2) restore_termux ;;
            0) return ;;
            *) show_error "Invalid choice"; press_enter ;;
        esac
    done
}

backup_termux() {
    echo ""
    local timestamp
    timestamp=$(date +%Y%m%d-%H%M%S)
    local backup_file="$HOME/devils-minios-backup-$timestamp.tar.gz"

    echo -e "${C_BLUE}Creating backup...${C_RESET}"
    tar -czf "$backup_file" \
        -C "$HOME" \
        .config/devils-minios \
        2>/dev/null && \
        show_success "Backup created: $backup_file" || \
        show_error "Backup failed"

    log_recent "BACKUP" "$backup_file"
    press_enter
}

restore_termux() {
    echo ""
    read -rp "Enter backup file path: " backup_file
    backup_file="${backup_file/#\~/$HOME}"

    if [[ ! -f "$backup_file" ]]; then
        show_error "File not found: $backup_file"
        press_enter
        return
    fi

    # Validate exec safety for restore destination
    if ! is_exec_safe "$HOME/.config/devils-minios"; then
        show_error "Restore path not safe for execution"
        press_enter
        return
    fi

    echo -e "${C_BLUE}Restoring from $backup_file...${C_RESET}"
    tar -xzf "$backup_file" -C "$HOME" 2>/dev/null && \
        show_success "Restore completed" || \
        show_error "Restore failed"

    log_recent "RESTORE" "$backup_file"
    press_enter
}

boost_performance() {
    echo ""
    echo -e "${C_CYAN}Performance Options:${C_RESET}"
    echo "  1) Create swap file"
    echo "  2) Show CPU info"
    echo "  0) Cancel"
    echo ""

    read -rp "Select: " choice

    case "$choice" in
        1)
            read -rp "Swap size in MB (default 512): " size
            size=${size:-512}
            if [[ "$size" =~ ^[0-9]+$ ]]; then
                if [[ ! -f "$HOME/swapfile" ]]; then
                    dd if=/dev/zero of="$HOME/swapfile" bs=1M count=$size 2>/dev/null && \
                        mkswap "$HOME/swapfile" 2>/dev/null && \
                        swapon "$HOME/swapfile" 2>/dev/null && \
                        show_success "Swap file created (${size}MB)" || \
                        show_error "Swap creation failed (may need root)"
                else
                    show_warning "Swap file already exists"
                fi
            fi
            ;;
        2)
            echo ""
            cat /proc/cpuinfo 2>/dev/null | grep -E "model name|processor|cpu cores" | head -10
            ;;
    esac
    press_enter
}

clean_cache() {
    echo ""
    echo -e "${C_BLUE}Cleaning cache...${C_RESET}"

    # Clean pkg cache
    if command -v pkg >/dev/null 2>&1; then
        pkg clean 2>/dev/null && echo "  ✓ pkg cache cleaned" || true
    fi

    # Clean apt cache in proot distros
    local runtime_dir="${RUNTIME_DIR:-$PREFIX/var/lib}"
    if [[ -d "$runtime_dir/proot-distro/installed-rootfs" ]]; then
        for d in "$runtime_dir/proot-distro/installed-rootfs"/*/; do
            local name
            name=$(basename "$d")
            proot-distro login "$name" -- bash -c "apt clean 2>/dev/null || true" 2>/dev/null || true
        done
    fi

    # Clean temp files
    rm -rf "$DMOL_CONFIG_DIR/tmp/"* 2>/dev/null || true

    show_success "Cache cleaned"
    log_recent "CLEAN_CACHE" ""
    press_enter
}

network_info() {
    echo ""
    echo -e "${C_CYAN}Network Information:${C_RESET}"
    echo ""

    if command -v ip >/dev/null 2>&1; then
        ip addr 2>/dev/null | grep -E "inet " | head -5
    elif command -v ifconfig >/dev/null 2>&1; then
        ifconfig 2>/dev/null | grep -E "inet " | head -5
    fi

    echo ""
    echo -e "${C_BLUE}Connectivity test:${C_RESET}"
    ping -c 1 8.8.8.8 2>/dev/null && echo "  ✓ Internet reachable" || echo "  ✗ No internet"

    press_enter
}

storage_analyzer() {
    echo ""
    echo -e "${C_CYAN}Storage Analysis:${C_RESET}"
    echo ""
    echo "Top 10 largest directories in $HOME:"
    du -sh "$HOME"/*/ 2>/dev/null | sort -rh | head -10
    echo ""
    echo "Disk usage:"
    df -h 2>/dev/null | head -5
    press_enter
}

process_manager() {
    while true; do
        echo ""
        echo -e "${C_CYAN}Process Manager:${C_RESET}"
        echo ""
        ps aux 2>/dev/null | head -15 || ps 2>/dev/null | head -15
        echo ""
        echo "  1) Kill by PID"
        echo "  2) Kill by name"
        echo "  0) Back"
        echo ""

        read -rp "Select: " choice

        case "$choice" in
            1)
                read -rp "Enter PID: " pid
                if [[ "$pid" =~ ^[0-9]+$ ]]; then
                    kill "$pid" 2>/dev/null && show_success "Process $pid killed" || show_error "Failed to kill $pid"
                fi
                ;;
            2)
                read -rp "Enter process name: " pname
                pkill -f "$pname" 2>/dev/null && show_success "Processes matching '$pname' killed" || show_error "No matching processes"
                ;;
            0) break ;;
        esac
    done
}

manage_service() {
    local action="$1"
    local service="$2"

    if [[ "$(detect_platform)" == "termux" ]]; then
        # Termux: no systemd, use pgrep/pkill
        case "$action" in
            start) nohup "$service" >/dev/null 2>&1 & ;;
            stop) pkill -f "$service" 2>/dev/null || true ;;
            status) pgrep -f "$service" >/dev/null 2>&1 && echo "running" || echo "stopped" ;;
        esac
    else
        # Linux: prefer systemctl, fallback to service
        if command -v systemctl >/dev/null 2>&1; then
            sudo systemctl "$action" "$service" 2>/dev/null || true
        elif command -v service >/dev/null 2>&1; then
            sudo service "$service" "$action" 2>/dev/null || true
        else
            case "$action" in
                start) nohup "$service" >/dev/null 2>&1 & ;;
                stop) pkill -f "$service" 2>/dev/null || true ;;
            esac
        fi
    fi
}

service_manager() {
    echo ""
    read -rp "Service name: " service
    read -rp "Action (start/stop/restart/status): " action

    manage_service "$action" "$service"
    show_success "Service $service $action completed"
    press_enter
}

kill_all_services() {
    echo ""
    echo -e "${C_RED}⚠️  WARNING: This will kill all user processes!${C_RESET}"
    read -rp "Type 'yes' to confirm: " confirm

    if [[ "$confirm" == "yes" ]]; then
        pkill -u "$(id -u)" 2>/dev/null || true
        show_success "All services stopped"
        log_recent "KILL_ALL_SERVICES" ""
    else
        show_info "Cancelled"
    fi
    press_enter
}
