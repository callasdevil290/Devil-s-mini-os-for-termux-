#!/usr/bin/env bash
# =============================================================================
# Devil's Mini OS Launcher - android_tools.sh
# Version: v1.1.0
# Purpose: Android developer tools with termux-api graceful degradation
# =============================================================================

android_tools_menu() {
    while true; do
        draw_header
        echo -e "${C_CYAN}${C_BOLD}📱 Android Tools${C_RESET}"
        echo ""

        if [[ "$(detect_platform)" != "termux" ]]; then
            echo -e "${C_YELLOW}⚠️  Android Tools are only available in Termux.${C_RESET}"
            echo ""
            echo "  0) Back to Main Menu"
            echo ""
            read -rp "Enter choice: " choice
            [[ "$choice" == "0" ]] && return
            show_error "Invalid choice"
            press_enter
            continue
        fi

        # Root check
        local root_status="No"
        if [[ "$(id -u)" == "0" ]] || su -c "id" 2>/dev/null | grep -q "uid=0"; then
            root_status="Yes"
        fi

        echo -e "${C_DIM}Root access: $root_status${C_RESET}"
        echo ""

        echo "  1) ADB devices"
        echo "  2) ADB shell"
        echo "  3) ADB install APK"
        echo "  4) ADB push/pull"
        echo "  5) Fastboot devices"
        echo "  6) Fastboot flash"
        echo "  7) Screenshot"
        echo "  8) Logcat (live)"
        echo "  9) Logcat (dump)"
        echo " 10) Device info"
        echo " 11) Storage info"
        echo ""

        # Termux:API features (only if available)
        if has_termux_api; then
            echo -e "${C_GREEN}── Termux:API Features ──${C_RESET}"
            echo " 12) Battery status"
            echo " 13) Clipboard read"
            echo " 14) Clipboard write"
            echo " 15) Torch toggle"
            echo " 16) Vibrate"
            echo " 17) TTS (text to speech)"
            echo " 18) WiFi toggle"
            echo " 19) Bluetooth toggle"
            echo " 20) Brightness"
            echo " 21) Volume"
            echo " 22) Camera info"
            echo " 23) Sensor readings"
            echo ""
        else
            echo -e "${C_DIM}── Termux:API not installed ──${C_RESET}"
            echo -e "${C_DIM}  Install Termux:API from the same source as Termux${C_RESET}"
            echo ""
        fi

        echo "  0) Back to Main Menu"
        echo ""

        read -rp "Enter choice: " choice
        choice=$(sanitize_input "$choice")

        case "$choice" in
            1) adb_devices ;;
            2) adb_shell ;;
            3) adb_install ;;
            4) adb_push_pull ;;
            5) fastboot_devices ;;
            6) fastboot_flash ;;
            7) take_screenshot ;;
            8) logcat_live ;;
            9) logcat_dump ;;
            10) device_info ;;
            11) storage_info ;;
            12) has_termux_api && battery_status || show_error "Termux:API not available" ;;
            13) has_termux_api && clipboard_read || show_error "Termux:API not available" ;;
            14) has_termux_api && clipboard_write || show_error "Termux:API not available" ;;
            15) has_termux_api && torch_toggle || show_error "Termux:API not available" ;;
            16) has_termux_api && vibrate || show_error "Termux:API not available" ;;
            17) has_termux_api && tts_speak || show_error "Termux:API not available" ;;
            18) has_termux_api && wifi_toggle || show_error "Termux:API not available" ;;
            19) has_termux_api && bluetooth_toggle || show_error "Termux:API not available" ;;
            20) has_termux_api && brightness_control || show_error "Termux:API not available" ;;
            21) has_termux_api && volume_control || show_error "Termux:API not available" ;;
            22) has_termux_api && camera_info || show_error "Termux:API not available" ;;
            23) has_termux_api && sensor_readings || show_error "Termux:API not available" ;;
            0) return ;;
            *) show_error "Invalid choice"; press_enter ;;
        esac
    done
}

# --- ADB Tools ---
adb_devices() {
    echo ""
    if command -v adb >/dev/null 2>&1; then
        adb devices
    else
        show_error "ADB not installed. Install from Termux App Store."
    fi
    press_enter
}

adb_shell() {
    echo ""
    if command -v adb >/dev/null 2>&1; then
        read -rp "Enter device serial (or press Enter for default): " serial
        if [[ -n "$serial" ]]; then
            adb -s "$serial" shell
        else
            adb shell
        fi
    else
        show_error "ADB not installed"
    fi
    press_enter
}

adb_install() {
    echo ""
    if ! command -v adb >/dev/null 2>&1; then
        show_error "ADB not installed"
        press_enter
        return
    fi

    read -rp "Enter APK path: " apk_path
    apk_path=$(sanitize_input "$apk_path")
    apk_path="${apk_path/#\~/$HOME}"

    if [[ ! -f "$apk_path" ]]; then
        show_error "APK not found: $apk_path"
        press_enter
        return
    fi

    adb install "$apk_path" 2>&1 || show_error "Install failed"
    log_recent "ADB_INSTALL" "$apk_path"
    press_enter
}

adb_push_pull() {
    echo ""
    if ! command -v adb >/dev/null 2>&1; then
        show_error "ADB not installed"
        press_enter
        return
    fi

    echo "  1) Push (to device)"
    echo "  2) Pull (from device)"
    echo "  0) Cancel"
    echo ""
    read -rp "Select: " action

    case "$action" in
        1)
            read -rp "Local file path: " local_path
            read -rp "Remote path (e.g., /sdcard/): " remote_path
            adb push "$local_path" "$remote_path" 2>&1 || show_error "Push failed"
            ;;
        2)
            read -rp "Remote path: " remote_path
            read -rp "Local destination: " local_path
            adb pull "$remote_path" "$local_path" 2>&1 || show_error "Pull failed"
            ;;
    esac
    press_enter
}

# --- Fastboot ---
fastboot_devices() {
    echo ""
    if command -v fastboot >/dev/null 2>&1; then
        fastboot devices
    else
        show_error "Fastboot not installed"
    fi
    press_enter
}

fastboot_flash() {
    echo ""
    if ! command -v fastboot >/dev/null 2>&1; then
        show_error "Fastboot not installed"
        press_enter
        return
    fi

    echo -e "${C_RED}⚠️  WARNING: Flashing can brick your device!${C_RESET}"
    read -rp "Partition (e.g., boot, recovery): " partition
    read -rp "Image file path: " img_path
    img_path="${img_path/#\~/$HOME}"

    if [[ ! -f "$img_path" ]]; then
        show_error "Image not found"
        press_enter
        return
    fi

    read -rp "CONFIRM FLASH? Type 'yes': " confirm
    if [[ "$confirm" == "yes" ]]; then
        fastboot flash "$partition" "$img_path" 2>&1 || show_error "Flash failed"
        log_recent "FASTBOOT_FLASH" "$partition"
    else
        show_info "Cancelled"
    fi
    press_enter
}

# --- Screenshot ---
take_screenshot() {
    echo ""
    local filename="screenshot-$(date +%Y%m%d-%H%M%S).png"
    local path="$HOME/$filename"

    if command -v screencap >/dev/null 2>&1; then
        screencap "$path" 2>/dev/null && show_success "Screenshot saved to $path" || show_error "Screenshot failed"
    elif command -v adb >/dev/null 2>&1; then
        adb shell screencap -p /sdcard/screen.png && adb pull /sdcard/screen.png "$path" && show_success "Screenshot saved to $path"
    else
        show_error "No screenshot method available"
    fi
    log_recent "SCREENSHOT" "$path"
    press_enter
}

# --- Logcat ---
logcat_live() {
    echo ""
    echo -e "${C_CYAN}Live logcat (press Ctrl+C to stop)...${C_RESET}"
    if command -v logcat >/dev/null 2>&1; then
        logcat 2>&1 | head -100
    elif command -v adb >/dev/null 2>&1; then
        adb logcat 2>&1 | head -100
    else
        show_error "logcat not available"
    fi
    press_enter
}

logcat_dump() {
    echo ""
    local filename="logcat-$(date +%Y%m%d-%H%M%S).txt"
    local path="$HOME/$filename"

    if command -v logcat >/dev/null 2>&1; then
        logcat -d > "$path" 2>/dev/null && show_success "Logcat dumped to $path" || show_error "Dump failed"
    elif command -v adb >/dev/null 2>&1; then
        adb logcat -d > "$path" 2>/dev/null && show_success "Logcat dumped to $path" || show_error "Dump failed"
    else
        show_error "logcat not available"
    fi
    log_recent "LOGCAT_DUMP" "$path"
    press_enter
}

# --- Device Info ---
device_info() {
    echo ""
    echo -e "${C_CYAN}=== Device Information ===${C_RESET}"
    echo ""
    echo -e "${C_GREEN}Model:${C_RESET} $(getprop ro.product.model 2>/dev/null || echo 'N/A')"
    echo -e "${C_GREEN}Manufacturer:${C_RESET} $(getprop ro.product.manufacturer 2>/dev/null || echo 'N/A')"
    echo -e "${C_GREEN}Android Version:${C_RESET} $(getprop ro.build.version.release 2>/dev/null || echo 'N/A')"
    echo -e "${C_GREEN}SDK:${C_RESET} $(getprop ro.build.version.sdk 2>/dev/null || echo 'N/A')"
    echo -e "${C_GREEN}Architecture:${C_RESET} $(getprop ro.product.cpu.abi 2>/dev/null || echo 'N/A')"
    echo -e "${C_GREEN}Kernel:${C_RESET} $(uname -r)"
    echo ""
    press_enter
}

storage_info() {
    echo ""
    echo -e "${C_CYAN}=== Storage Information ===${C_RESET}"
    echo ""
    df -h 2>/dev/null | head -10
    echo ""
    press_enter
}

# --- Termux:API Features ---
battery_status() {
    echo ""
    if command -v termux-battery-status >/dev/null 2>&1; then
        termux-battery-status 2>/dev/null || show_error "Failed to get battery status"
    else
        # Fallback: read from sysfs
        if [[ -f "/sys/class/power_supply/battery/capacity" ]]; then
            echo "Battery: $(cat /sys/class/power_supply/battery/capacity 2>/dev/null || echo 'N/A')%"
        else
            show_error "Battery info not available"
        fi
    fi
    press_enter
}

clipboard_read() {
    echo ""
    if command -v termux-clipboard-get >/dev/null 2>&1; then
        local content
        content=$(termux-clipboard-get 2>/dev/null)
        echo -e "${C_CYAN}Clipboard content:${C_RESET}"
        echo "$content"
    else
        show_error "Clipboard access not available"
    fi
    press_enter
}

clipboard_write() {
    echo ""
    read -rp "Enter text to copy to clipboard: " text
    if command -v termux-clipboard-set >/dev/null 2>&1; then
        echo -n "$text" | termux-clipboard-set 2>/dev/null && show_success "Copied to clipboard" || show_error "Failed"
    else
        show_error "Clipboard access not available"
    fi
    press_enter
}

torch_toggle() {
    echo ""
    if command -v termux-torch >/dev/null 2>&1; then
        read -rp "Turn torch ON or OFF? [on/off] " state
        termux-torch "$state" 2>/dev/null && show_success "Torch $state" || show_error "Failed"
    else
        show_error "Torch control not available"
    fi
    press_enter
}

vibrate() {
    echo ""
    if command -v termux-vibrate >/dev/null 2>&1; then
        read -rp "Duration in ms (default 1000): " duration
        duration=${duration:-1000}
        termux-vibrate -d "$duration" -f 2>/dev/null && show_success "Vibrated for ${duration}ms" || show_error "Failed"
    else
        show_error "Vibrate not available"
    fi
    press_enter
}

tts_speak() {
    echo ""
    if command -v termux-tts-speak >/dev/null 2>&1; then
        read -rp "Enter text to speak: " text
        termux-tts-speak "$text" 2>/dev/null && show_success "Speaking..." || show_error "Failed"
    else
        show_error "TTS not available"
    fi
    press_enter
}

wifi_toggle() {
    echo ""
    if command -v termux-wifi-enable >/dev/null 2>&1; then
        read -rp "Turn WiFi ON or OFF? [on/off] " state
        local bool_state="false"
        [[ "$state" == "on" ]] && bool_state="true"
        termux-wifi-enable "$bool_state" 2>/dev/null && show_success "WiFi $state" || show_error "Failed"
    else
        show_error "WiFi control not available"
    fi
    press_enter
}

bluetooth_toggle() {
    echo ""
    if command -v termux-bluetooth >/dev/null 2>&1; then
        read -rp "Turn Bluetooth ON or OFF? [on/off] " state
        local bool_state="false"
        [[ "$state" == "on" ]] && bool_state="true"
        termux-bluetooth -e "$bool_state" 2>/dev/null && show_success "Bluetooth $state" || show_error "Failed"
    else
        show_error "Bluetooth control not available"
    fi
    press_enter
}

brightness_control() {
    echo ""
    if command -v termux-brightness >/dev/null 2>&1; then
        read -rp "Enter brightness (0-255): " level
        if [[ "$level" =~ ^[0-9]+$ && "$level" -ge 0 && "$level" -le 255 ]]; then
            termux-brightness "$level" 2>/dev/null && show_success "Brightness set to $level" || show_error "Failed"
        else
            show_error "Invalid brightness level"
        fi
    else
        show_error "Brightness control not available"
    fi
    press_enter
}

volume_control() {
    echo ""
    if command -v termux-volume >/dev/null 2>&1; then
        read -rp "Stream (music/ring/alarm/notification): " stream
        read -rp "Volume (0-15): " level
        termux-volume "$stream" "$level" 2>/dev/null && show_success "Volume set" || show_error "Failed"
    else
        show_error "Volume control not available"
    fi
    press_enter
}

camera_info() {
    echo ""
    if command -v termux-camera-info >/dev/null 2>&1; then
        termux-camera-info 2>/dev/null || show_error "Failed to get camera info"
    else
        show_error "Camera info not available"
    fi
    press_enter
}

sensor_readings() {
    echo ""
    if command -v termux-sensor >/dev/null 2>&1; then
        echo -e "${C_CYAN}Available sensors:${C_RESET}"
        termux-sensor -l 2>/dev/null | head -20 || show_error "Failed to list sensors"
        echo ""
        read -rp "Enter sensor name to read (or press Enter to cancel): " sensor
        if [[ -n "$sensor" ]]; then
            termux-sensor -s "$sensor" -n 1 2>/dev/null || show_error "Failed to read sensor"
        fi
    else
        show_error "Sensor access not available"
    fi
    press_enter
}
