#!/usr/bin/env bash
# =============================================================================
# Devil's Mini OS Launcher - log_viewer.sh
# Version: v1.1.0
# Purpose: View and manage launcher logs
# =============================================================================

log_viewer_menu() {
    while true; do
        draw_header
        echo -e "${C_CYAN}${C_BOLD}📜 Log Viewer${C_RESET}"
        echo ""
        echo "  1) View Plain Text Log"
        echo "  2) View JSON Log"
        echo "  3) Filter by Level"
        echo "  4) Search Logs"
        echo "  5) Clear Old Logs"
        echo "  6) Log File Sizes"
        echo "  7) Live Tail"
        echo "  8) Export Logs"
        echo "  0) Back to Main Menu"
        echo ""

        read -rp "Enter choice: " choice
        choice=$(sanitize_input "$choice")

        case "$choice" in
            1) view_plain_log; press_enter ;;
            2) view_json_log; press_enter ;;
            3) filter_by_level; press_enter ;;
            4) search_logs; press_enter ;;
            5) clear_logs; press_enter ;;
            6) log_sizes; press_enter ;;
            7) live_tail ;;
            8) export_logs; press_enter ;;
            0) return ;;
            *) show_error "Invalid choice"; press_enter ;;
        esac
    done
}

view_plain_log() {
    draw_header
    echo -e "${C_CYAN}${C_BOLD}📄 Launcher Log${C_RESET}"
    echo ""

    local log_file="$DMOL_CONFIG_DIR/logs/launcher.log"
    if [[ -f "$log_file" ]]; then
        tail -n 50 "$log_file"
    else
        echo -e "${C_DIM}No log file found${C_RESET}"
    fi
}

view_json_log() {
    draw_header
    echo -e "${C_CYAN}${C_BOLD}📄 JSON Log${C_RESET}"
    echo ""

    local log_file="$DMOL_CONFIG_DIR/logs/launcher.json.log"
    if [[ -f "$log_file" ]]; then
        tail -n 30 "$log_file"
    else
        echo -e "${C_DIM}No JSON log file found${C_RESET}"
    fi
}

filter_by_level() {
    echo ""
    echo "Select level:"
    echo "  1) ERROR"
    echo "  2) WARN"
    echo "  3) INFO"
    echo "  4) DEBUG"
    echo ""
    read -rp "Level: " level_choice

    local level=""
    case "$level_choice" in
        1) level="ERROR" ;;
        2) level="WARN" ;;
        3) level="INFO" ;;
        4) level="DEBUG" ;;
        *) show_error "Invalid level"; return ;;
    esac

    echo ""
    local log_file="$DMOL_CONFIG_DIR/logs/launcher.log"
    if [[ -f "$log_file" ]]; then
        grep "\[$level\]" "$log_file" | tail -n 50
    else
        echo -e "${C_DIM}No log file found${C_RESET}"
    fi
}

search_logs() {
    echo ""
    read -rp "Search keyword: " keyword
    keyword=$(sanitize_input "$keyword")

    if [[ -z "$keyword" ]]; then
        show_error "Keyword cannot be empty"
        return
    fi

    echo ""
    local log_file="$DMOL_CONFIG_DIR/logs/launcher.log"
    if [[ -f "$log_file" ]]; then
        grep -i "$keyword" "$log_file" | tail -n 50 || echo -e "${C_DIM}No matches found${C_RESET}"
    else
        echo -e "${C_DIM}No log file found${C_RESET}"
    fi
}

clear_logs() {
    echo ""
    read -rp "Clear all logs? [y/N] " confirm
    if [[ "$confirm" =~ ^[Yy]$ ]]; then
        rm -f "$DMOL_CONFIG_DIR/logs/"*.log "$DMOL_CONFIG_DIR/logs/"*.log.* 2>/dev/null
        show_success "Logs cleared"
        log_info "Logs cleared by user"
    else
        show_info "Cancelled"
    fi
}

log_sizes() {
    echo ""
    echo -e "${C_CYAN}Log File Sizes:${C_RESET}"
    ls -lh "$DMOL_CONFIG_DIR/logs/" 2>/dev/null || echo -e "${C_DIM}No logs found${C_RESET}"
}

live_tail() {
    local log_file="$DMOL_CONFIG_DIR/logs/launcher.log"
    if [[ ! -f "$log_file" ]]; then
        show_error "No log file found"
        return
    fi

    echo ""
    echo -e "${C_CYAN}Live tail (press Ctrl+C to stop)...${C_RESET}"
    echo ""
    tail -f "$log_file" &
    local tail_pid=$!
    read -rp "Press Enter to stop..." </dev/tty
    kill $tail_pid 2>/dev/null
    wait $tail_pid 2>/dev/null
}

export_logs() {
    echo ""
    local timestamp
    timestamp=$(date +%Y%m%d-%H%M%S)
    local export_file="$HOME/devils-minios-logs-$timestamp.tar.gz"

    if [[ -d "$DMOL_CONFIG_DIR/logs" ]]; then
        tar -czf "$export_file" -C "$DMOL_CONFIG_DIR" logs/ 2>/dev/null && \
            show_success "Logs exported to $export_file" || \
            show_error "Export failed"
        log_recent "EXPORT_LOGS" "$export_file"
    else
        show_error "No logs to export"
    fi
}
