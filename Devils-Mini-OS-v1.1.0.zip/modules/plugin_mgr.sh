#!/usr/bin/env bash
# =============================================================================
# Devil's Mini OS Launcher - plugin_mgr.sh
# Version: v1.1.0
# Purpose: Third-party plugin support with whitelist security
# =============================================================================

PLUGIN_DIR="$DMOL_CONFIG_DIR/plugins"

plugin_mgr_menu() {
    while true; do
        draw_header
        echo -e "${C_CYAN}${C_BOLD}🔌 Plugin Manager${C_RESET}"
        echo ""
        echo "  1) List Plugins"
        echo "  2) Run Plugin"
        echo "  3) Enable/Disable Plugin"
        echo "  4) Install Plugin (from file)"
        echo "  5) Remove Plugin"
        echo "  6) Validate All Plugins"
        echo "  0) Back to Main Menu"
        echo ""

        read -rp "Enter choice: " choice
        choice=$(sanitize_input "$choice")

        case "$choice" in
            1) list_plugins; press_enter ;;
            2) run_plugin_menu ;;
            3) toggle_plugin; press_enter ;;
            4) install_plugin; press_enter ;;
            5) remove_plugin; press_enter ;;
            6) validate_all_plugins; press_enter ;;
            0) return ;;
            *) show_error "Invalid choice"; press_enter ;;
        esac
    done
}

list_plugins() {
    echo ""
    mkdir -p "$PLUGIN_DIR"

    local found=false
    for plugin_dir in "$PLUGIN_DIR"/*/; do
        [[ -d "$plugin_dir" ]] || continue

        local name
        name=$(basename "$plugin_dir")
        local manifest="$plugin_dir/manifest.json"
        local script="$plugin_dir/plugin.sh"
        local enabled="disabled"

        [[ -f "$script" && -x "$script" ]] && enabled="enabled"
        [[ -f "$plugin_dir/.disabled" ]] && enabled="disabled"

        if [[ -f "$manifest" ]]; then
            local version author
            version=$(grep -o '"version"[[:space:]]*:[[:space:]]*"[^"]*"' "$manifest" 2>/dev/null | cut -d'"' -f4 || echo "unknown")
            author=$(grep -o '"author"[[:space:]]*:[[:space:]]*"[^"]*"' "$manifest" 2>/dev/null | cut -d'"' -f4 || echo "unknown")
            printf "  %-20s v%-10s by %-15s [%s]\n" "$name" "$version" "$author" "$enabled"
        else
            printf "  %-20s (no manifest) [%s]\n" "$name" "$enabled"
        fi
        found=true
    done

    if [[ "$found" == false ]]; then
        echo -e "${C_DIM}No plugins installed${C_RESET}"
    fi
}

run_plugin_menu() {
    echo ""
    mkdir -p "$PLUGIN_DIR"

    local plugins=()
    local i=1
    for plugin_dir in "$PLUGIN_DIR"/*/; do
        [[ -d "$plugin_dir" ]] || continue
        local name
        name=$(basename "$plugin_dir")
        local script="$plugin_dir/plugin.sh"

        [[ -f "$script" && ! -f "$plugin_dir/.disabled" ]] || continue

        plugins+=("$name")
        echo "  $i) $name"
        ((i++))
    done

    if [[ ${#plugins[@]} -eq 0 ]]; then
        show_error "No enabled plugins found"
        return
    fi

    echo "  0) Cancel"
    echo ""

    read -rp "Select plugin to run: " choice
    choice=$(sanitize_input "$choice")

    if [[ "$choice" == "0" ]]; then
        return
    fi

    if ! validate_number "$choice" 1 "${#plugins[@]}"; then
        show_error "Invalid selection"
        return
    fi

    local selected="${plugins[$((choice-1))]}"
    local script="$PLUGIN_DIR/$selected/plugin.sh"

    # Validate before running
    if ! validate_plugin "$script"; then
        show_error "Plugin validation failed. Run 'Validate All Plugins' for details."
        return
    fi

    echo ""
    echo -e "${C_BLUE}Running plugin: $selected${C_RESET}"
    echo ""

    run_plugin "$script"
    local exit_code=$?

    echo ""
    if [[ $exit_code -eq 0 ]]; then
        show_success "Plugin completed successfully"
    else
        show_error "Plugin exited with code $exit_code"
    fi

    log_recent "RUN_PLUGIN" "$selected"
    press_enter
}

validate_plugin() {
    local script="$1"

    # Check shebang
    local shebang
    shebang=$(head -n 1 "$script")
    if [[ "$shebang" != "#!/usr/bin/env bash" && "$shebang" != "#!/bin/bash" ]]; then
        log_warn "Plugin $script: Invalid shebang"
        return 1
    fi

    # Check for dangerous patterns
    if grep -qE 'rm\s+-rf\s+/|mkfs\.|dd\s+if=/dev/zero|curl\s+.*\|\s*bash' "$script" 2>/dev/null; then
        log_warn "Plugin $script: Dangerous pattern detected"
        return 1
    fi

    # Check for external storage paths
    if grep -qE '~/storage/shared|/sdcard/|/storage/emulated' "$script" 2>/dev/null; then
        log_warn "Plugin $script: External storage path detected"
        return 1
    fi

    # Whitelist validation
    if ! validate_plugin_commands "$script"; then
        log_warn "Plugin $script: Command whitelist validation failed"
        return 1
    fi

    return 0
}

toggle_plugin() {
    echo ""
    read -rp "Plugin name: " name
    name=$(sanitize_input "$name")

    local plugin_dir="$PLUGIN_DIR/$name"
    if [[ ! -d "$plugin_dir" ]]; then
        show_error "Plugin not found: $name"
        return
    fi

    if [[ -f "$plugin_dir/.disabled" ]]; then
        rm -f "$plugin_dir/.disabled"
        show_success "Plugin '$name' enabled"
    else
        touch "$plugin_dir/.disabled"
        show_success "Plugin '$name' disabled"
    fi

    log_recent "TOGGLE_PLUGIN" "$name"
}

install_plugin() {
    echo ""
    read -rp "Enter path to plugin archive or directory: " path
    path="${path/#\~/$HOME}"

    if [[ -d "$path" ]]; then
        # Copy directory
        local name
        name=$(basename "$path")
        cp -r "$path" "$PLUGIN_DIR/$name"
        show_success "Plugin installed: $name"
    elif [[ -f "$path" ]]; then
        # Extract archive
        local name
        name=$(basename "$path" | sed 's/\.tar\.gz$//;s/\.zip$//;s/\.tar$//')
        mkdir -p "$PLUGIN_DIR/$name"

        if [[ "$path" == *.tar.gz || "$path" == *.tgz ]]; then
            tar -xzf "$path" -C "$PLUGIN_DIR/$name" --strip-components=1 2>/dev/null
        elif [[ "$path" == *.zip ]]; then
            unzip -o "$path" -d "$PLUGIN_DIR/$name" 2>/dev/null
        else
            show_error "Unsupported archive format"
            return
        fi

        show_success "Plugin installed: $name"
    else
        show_error "Path not found: $path"
        return
    fi

    # Validate after install
    local installed_name
    installed_name=$(basename "$path" | sed 's/\.tar\.gz$//;s/\.zip$//;s/\.tar$//')
    local script="$PLUGIN_DIR/$installed_name/plugin.sh"

    if [[ -f "$script" ]]; then
        if validate_plugin "$script"; then
            show_success "Plugin validation passed"
        else
            show_warning "Plugin validation failed — review before running"
        fi
    fi

    log_recent "INSTALL_PLUGIN" "$installed_name"
}

remove_plugin() {
    echo ""
    read -rp "Plugin name to remove: " name
    name=$(sanitize_input "$name")

    local plugin_dir="$PLUGIN_DIR/$name"
    if [[ ! -d "$plugin_dir" ]]; then
        show_error "Plugin not found: $name"
        return
    fi

    read -rp "Confirm removal? [y/N] " confirm
    if [[ "$confirm" =~ ^[Yy]$ ]]; then
        rm -rf "$plugin_dir"
        show_success "Plugin '$name' removed"
        log_recent "REMOVE_PLUGIN" "$name"
    else
        show_info "Cancelled"
    fi
}

validate_all_plugins() {
    echo ""
    echo -e "${C_CYAN}Validating all plugins...${C_RESET}"
    echo ""

    local passed=0
    local failed=0

    for plugin_dir in "$PLUGIN_DIR"/*/; do
        [[ -d "$plugin_dir" ]] || continue

        local name
        name=$(basename "$plugin_dir")
        local script="$plugin_dir/plugin.sh"

        if [[ ! -f "$script" ]]; then
            echo -e "  ${C_YELLOW}⚠️  $name: No plugin.sh found${C_RESET}"
            ((failed++))
            continue
        fi

        if validate_plugin "$script"; then
            echo -e "  ${C_GREEN}✓ $name: Valid${C_RESET}"
            ((passed++))
        else
            echo -e "  ${C_RED}✗ $name: Validation failed${C_RESET}"
            ((failed++))
        fi
    done

    echo ""
    echo -e "Results: ${C_GREEN}$passed passed${C_RESET}, ${C_RED}$failed failed${C_RESET}"
}
