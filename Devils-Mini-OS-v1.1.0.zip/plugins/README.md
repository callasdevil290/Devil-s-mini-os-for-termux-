# Devil's Mini OS Plugin Development Guide

## Structure

Each plugin is a directory containing:
- `plugin.sh` — Main script (must be bash)
- `manifest.json` — Metadata

## manifest.json

```json
{
  "name": "my-plugin",
  "version": "1.0.0",
  "author": "Your Name",
  "description": "What this plugin does",
  "entry_point": "plugin.sh"
}
```

## Security

Plugins run in a restricted subshell with:
- Limited PATH (`$PREFIX/bin:/system/bin:/bin:/usr/bin`)
- Command whitelist validation
- No external storage access
- No dangerous commands (`rm -rf /`, `mkfs`, etc.)

## Allowed Commands

- Package managers: `pkg`, `apt`, `pacman`, `dnf`, `zypper`, `xbps-install`, `emerge`
- Tools: `git`, `wget`, `curl`, `tar`, `unzip`
- File ops: `cp`, `mv`, `rm`, `mkdir`, `chmod`, `chown`, `ln`
- Text: `echo`, `cat`, `grep`, `sed`, `awk`, `head`, `tail`
- Shell: `bash`, `sh`, `source`, `exit`, `return`
- Android: `termux-*`, `am`, `pm`

## Example plugin.sh

```bash
#!/usr/bin/env bash
echo "Hello from my plugin!"
```

## Installation

Place your plugin directory in `~/.config/devils-minios/plugins/`
or use the Plugin Manager to install from file.
