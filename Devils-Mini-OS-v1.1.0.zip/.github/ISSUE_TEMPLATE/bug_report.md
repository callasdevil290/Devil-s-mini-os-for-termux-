---
name: Bug Report
about: Report a bug in Devil's Mini OS Launcher
title: '[BUG] '
labels: bug
assignees: ''

---

**Describe the bug**
A clear description of what the bug is.

**To Reproduce**
Steps to reproduce:
1. Go to '...'
2. Click on '...'
3. See error

**Expected behavior**
What you expected to happen.

**Environment:**
 - Device: [e.g. Samsung Galaxy S23]
 - Android Version: [e.g. 14]
 - Termux Source: [F-Droid/GitHub/Play Store]
 - Launcher Version: [e.g. v1.1.0]

**Additional context**
Add any other context about the problem here.
