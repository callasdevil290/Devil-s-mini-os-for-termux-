#!/usr/bin/env bash
# =============================================================================
# Devil's Mini OS Launcher - test_core.sh
# Version: v1.1.0
# Purpose: Core utilities tests including platform detection
# =============================================================================

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
source "$SCRIPT_DIR/modules/core.sh"

TESTS_PASSED=0
TESTS_FAILED=0

assert_true() {
    local cmd="$1"
    local test_name="$2"

    if eval "$cmd" >/dev/null 2>&1; then
        echo "  ✓ $test_name"
        ((TESTS_PASSED++))
    else
        echo "  ✗ $test_name"
        ((TESTS_FAILED++))
    fi
}

assert_false() {
    local cmd="$1"
    local test_name="$2"

    if ! eval "$cmd" >/dev/null 2>&1; then
        echo "  ✓ $test_name"
        ((TESTS_PASSED++))
    else
        echo "  ✗ $test_name"
        ((TESTS_FAILED++))
    fi
}

assert_equals() {
    local expected="$1"
    local actual="$2"
    local test_name="$3"

    if [[ "$expected" == "$actual" ]]; then
        echo "  ✓ $test_name"
        ((TESTS_PASSED++))
    else
        echo "  ✗ $test_name"
        echo "    Expected: $expected"
        echo "    Actual: $actual"
        ((TESTS_FAILED++))
    fi
}

echo "=== Testing core.sh ==="
echo ""

echo "Platform Detection:"
init_system >/dev/null 2>&1
assert_true "[[ -n '$(detect_platform)' ]]" "detect_platform returns non-empty"

echo ""
echo "Terminal Width:"
assert_true "[[ '$(detect_terminal_width)' =~ ^[0-9]+$ ]]" "detect_terminal_width returns number"
assert_true "[[ $(detect_terminal_width) -gt 0 ]]" "terminal width > 0"

echo ""
echo "Config/Cache Directories:"
assert_true "[[ -d '$DMOL_CONFIG_DIR' ]]" "config directory exists"
assert_true "[[ -d '$DMOL_CACHE_DIR' ]]" "cache directory exists"

echo ""
echo "Input Sanitization:"
assert_equals "hello" "$(sanitize_input "hello")" "sanitize normal text"
assert_equals "hello" "$(sanitize_input "hello"$'\n')" "sanitize with newline"

echo ""
echo "Number Validation:"
assert_true "validate_number 5 1 10" "valid number in range"
assert_false "validate_number 15 1 10" "number out of range"
assert_false "validate_number abc 1 10" "non-numeric input"

echo ""
echo "Exec Safety:"
assert_true "is_exec_safe '$HOME/test'" "HOME path is safe"
assert_false "is_exec_safe '$HOME/storage/shared/test'" "external storage not safe"

echo ""
echo "Logging:"
log_info "test message" >/dev/null 2>&1
assert_true "[[ -f '$DMOL_CONFIG_DIR/logs/launcher.log' ]]" "log file created"

echo ""
echo "XDG Compliance:"
assert_true "[[ -n '$(get_config_dir)' ]]" "get_config_dir returns path"
assert_true "[[ -n '$(get_cache_dir)' ]]" "get_cache_dir returns path"

echo ""
echo "=== Results ==="
echo "Passed: $TESTS_PASSED"
echo "Failed: $TESTS_FAILED"

if [[ $TESTS_FAILED -gt 0 ]]; then
    exit 1
fi
